# FSAE 耐力赛工况测试报告（V3）

上一版把「上电从 50% 起步」当成一个显示问题，修法是先给个占位值，再等 OCV 慢慢兜回来。这一版换了做法：把 50% 从代码里删掉，SOC 没有真值来源时就说不知道，同时用 EEPROM 把掉电前的电量记住。另外更正了上一版的两处结论误判。

电池组：亿纬 C33（IFR33140，LFP 3.2V/15Ah），2P4S，12.8 V / 30 Ah / 384 Wh，直流内阻 16 mΩ
BMS：BQ76920 AFE + STM32F103C8T6
仿真：MATLAB R2025b，纯 MATLAB 离线回路（与 Simulink 模型逐拍等价）

## 一、改动清单

| 改动 | 文件 |
|---|---|
| 删掉 `Soc_Init()` 里的 50% 占位，SOC 未确定时显式标记 UNKNOWN | `bms_firmware/Core/Src/bms_soc.c` |
| 新增 `Soc_State_t` 三级可信度（UNKNOWN / RESTORED / OCV_ALIGNED） | `bms_firmware/Core/Inc/bms_soc.h` |
| EEPROM 掉电记忆字段，版本升到 `0x02` | `bms_firmware/Core/Inc/bms_storage.h` |
| 未对齐时禁止显示数字：LED 跑马灯、串口 UNKNOWN、帧内哨兵值 | `bms_led.c` `bms_debug.c` `bms_can.c` |
| 待测电芯冷启动检测（一级判据） | `bms_config.h` `bms_app.c` `bms_app.h` |
| 新增上电对齐配置宏 | `bms_firmware/Core/Inc/bms_config.h` |
| App 层接上 EEPROM 恢复、OCV 对齐、SOC 落盘 | `bms_firmware/Core/Src/bms_app.c` |
| EEPROM 默认值、版本、打印 | `bms_firmware/Core/Src/bms_storage.c` |
| 同步移植到 MATLAB | `sim/bms_ctrl_model.m` |
| 新增 scen 15（静置对齐验证） | `sim/bms_profile_model.m` |
| 支持 `boot_soc` 入参 | `sim/run_bms_offline.m` |
| 新增 7 工况套件 | `sim/run_fsae_suite.m` |
| 修 AFE 窗口计时精度（改用整数毫秒） | `sim/bms_afe_model.m` |

## 二、上电 SOC 改用 EEPROM 掉电记忆

### 2.1 原来的问题

老固件 `Soc_Init()` 里是这么写的：

```c
s_remain_nah = s_cap_nah / 2;      /* 未知状态先按 50%，静置后由 OCV 修正 */
```

配合 `BMS_OCV_REST_MS = 1800000`（30 分钟）的静置门槛，就出了两个麻烦。满电待发的时候仪表显示 50%，车手会误判续航；而 LFP 平台极平，静置修正的权重只有 0.1，要很多轮才收敛得回来。

### 2.2 核心思路：没有真值来源就别报数

老思路是「先给个占位值，等条件成熟再修正」。问题是占位值本身是错的，而它又会被上层读走显示出去。

所以改成：SOC 拿不到真值的时候，明说自己不知道。EEPROM 就是它的真值来源。

```c
void Soc_Init(float capacity_ah)
{
    ...
    /* 这里不写 50% 之类的占位数字：真实电量未知就是未知。
       0 只是"还没开始积分"的内部起点，对外由 valid/state 标记为不可信。 */
    s_remain_nah = 0;
    s_aligned   = false;
    s_state     = SOC_STATE_UNKNOWN;
    g_soc.valid = false;
}
```

配套加了三级可信度枚举，把「知道多少」写进类型里：

| 状态 | 含义 | 何时进入 |
|---|---|---|
| `SOC_STATE_UNKNOWN` | 电量不可知，调用方禁止显示或上报具体数字 | 上电初始，直到对齐成功 |
| `SOC_STATE_RESTORED` | 由 EEPROM 掉电记录恢复，不受极化影响，最可信 | EEPROM 有有效记录 |
| `SOC_STATE_OCV_ALIGNED` | 由 OCV 对齐得到 | 冷启动静置稳定后 |

上位机侧也一起拒收假数字。未对齐时串口 `?` 打印 `SOC : UNKNOWN`；`$BMS` 帧的 SOC 字段发哨兵值 `65535`（正常值只会落在 0~1000），CAN 帧 6 同样发 `0xFFFF`。LED 进跑马灯模式，表示正在确定电量，不再停在任何固定档位上，免得固定档位被当成真实电量读走。

### 2.3 主路径：EEPROM 掉电记忆

只要板子正常跑过一轮，上电就是真值。

`BmsParam_t` 新增三个字段，`EEPROM_VERSION` 从 `0x01` 升到 `0x02`：

```c
uint16_t soc_permille;     /* SOC 千分比 0~1000（整数存储，避开 float 的字节序/精度问题） */
uint16_t soc_valid;        /* 该记录是否可信（0 = 从没存过，别用） */
uint32_t soc_saved_s;      /* 记录时的累计运行秒数 */
```

`BMS_Init()` 里，等 AFE 通信正常之后恢复：

```c
Soc_Init(g_param.capacity_ah);
if (g_param.soc_valid != 0U) {
    Soc_SetInitialSoc((float)g_param.soc_permille / 10.0f);   /* 上电第一拍就是真值 */
    /* → s_state = SOC_STATE_RESTORED */
}
```

落盘要顾着 AT24C02 的 100 万次擦写寿命，所以设了三处触发：

| 触发 | 条件 | 目的 |
|---|---|---|
| 变化落盘 | SOC 相对上次变化 ≥ 1%，且距上次 ≥ 60s | 跟上工况，又不至于频繁擦写 |
| 对齐瞬间 | 刚拿到真值立刻存一次 | 保证下次上电一定能恢复 |
| 周期落盘 | 复用原有 10 分钟周期 | 兜底 |

未对齐时不落盘。存下去的是无意义的数，反而会污染下次上电，所以 `soc_save_now()` 开头就是 `if (!Soc_IsAligned()) return;`。

### 2.4 冷启动检测（一级判据，取待测电芯）

EEPROM 之外，再从硬件上取一条独立证据，回答「本次上电是彻底断电后的冷启动，还是系统一直在电的热重启」。

取点在 R17（1mΩ 采样电阻）两端的开尔文取样线上：

| 情形 | 上电前该点状态 | 上电后读到 |
|---|---|---|
| 冷启动 | MCU 刚由 POR 释放，两脚上电前是高阻 | 0V 附近 |
| 热重启 | 系统一直在电，电流路径上带着真实差分电压 | 非零差分 |

读数落在零点死区（±48 LSB ≈ ±0.77mV）内就判冷启动。

为什么不能拿 MCU 引脚的状态寄存器代替？因为引脚配置在启动代码里会被重置，所有复位源看起来都一样。只有「先于配置就存在的物理量」才分得开。

时序上有个坑：必须在 `MX_ADC1_Init()` 之后、`BQ_Init()` 之前采样。

```c
MX_ADC1_Init();
HAL_ADCEx_Calibration_Start(&hadc1);   /* F1 系列需要 */
BMS_SampleStartupCell();               /* 就在这个位置 */
...
BMS_Init();                            /* 此时不会再重复采样 */
```

早于 ADC 初始化，`HAL_ADC_Start()` 会直接失败；晚于 AFE 初始化或任何 I2C 动作，采样电阻上可能已经流过电流，冷热就分不出来了。

如果硬件上这两个脚没接 ADC（比如只接了 INA 或比较器），把 `BMS_COLDSTART_DETECT` 置 0，代码会自动退回 EEPROM + OCV 两条路。采样失败或读数贴轨（引脚悬空）时按「无信息」处理，不产生假判据。

### 2.5 辅助路径：上电快速 OCV 对齐

这条路只在 EEPROM 没有有效记录时才用得上，比如首次上电、换板、数据损坏。

不必等 30 分钟，确认「静置 + 电压稳定」持续 15 秒就可以采信 OCV。三个条件同时满足，缺一不可：

| 条件 | 判据 | 为什么必须 |
|---|---|---|
| 电流接近 0 | `abs(i) < BMS_OCV_REST_A`（0.05A） | 带载时端电压含 I·R 压降，不是 OCV |
| 电压稳定 | 8 点窗口内极差 < `BMS_OCV_BOOT_STABLE_MV`（20mV），连续满足 3 次 | 刚跑完车立刻重启，端电压还带着极化（放电后偏低）。只看「电流小」会把极化电压误当 OCV，反而把 SOC 拉错 |
| 持续够久 | 静置累计 ≥ `BMS_OCV_BOOT_MS`（15s） | 让欧姆压降与快极化恢复完 |

`Soc_OnBootOcv()` 的采信规则：

```
从未对齐过            → 直接采信 OCV
OCV 与当前值差 > 8%   → 记录不可信（换过电池 / 长期搁置自放电），物理量优先，直接采信
否则                  → 按 0.5 权重融合（比 30min 慢修正的 0.1 激进得多）
```

权重能比慢修正大，是因为两者的前提不一样。慢修正是在运行中做的，电压随时被负载扰动；这个函数的前提是已经确认静置且电压稳定，此时端电压就是 OCV，可信度高得多。

`s_aligned` 在以下任一时机置真：EEPROM 恢复、上电 OCV 对齐、满充判定、放空判定、30min 静置修正。

### 2.6 实测效果

| 场景 | 上电 SOC 来源 | 上电显示 | 真值 | 偏差 |
|---|---|---|---|---|
| F1 FSAE 耐力赛 30 分钟 | EEPROM 恢复 100% | 100.0% | 100.00% | +0.00% |
| F2 FSAE 多圈脉动 | EEPROM 恢复 100% | 100.0% | 100.00% | +0.00% |
| F3 上电静置对齐验证 | 无记录 → OCV 对齐 | 100.0%（t=15.0s） | 100.00% | −0.01% |
| F7 对照 静置基线 | 无记录 → OCV 对齐 | 59.2%（t=15.0s） | 59.25% | −0.09% |
| F4 无记录且带载 | 无信息 → UNKNOWN | `--`（不显示数字） | 100.00% | 不适用 |

F1 和 F2 上电第一拍就是 100.0%，这是真实工况下要的结果。

F4 属于物理边界。无 EEPROM 记录，上电瞬间又直接带 30A 载，确实没有任何信息能用来判断电量，那就如实说不知道，比给一个会误导人的 50% 安全。本版的处理方式也从「显示 50%」变成了「显示未知」。实际用车只要上电后先静置十几秒（F3 就是模拟这个），15 秒就能对上。

## 三、两处结论更正

这两处都是上一版报告的错误。

### 3.1 「库仑计窗口对齐缺陷」不成立

上一版的判断是：固件 `cc_read` 只持续 1 拍，AFE 未及归零就重写 `cc_reg`，固件在电流阶跃点读到陈旧窗口值，由此判定为固件缺陷。

查真实固件 `bms_app.c` 的 `fast_task()` 之后发现，原代码本来就是对的：

```c
stat = BQ_GetSysStat();
if ((stat & BQ_STAT_CC_READY) != 0U) {     /* ← 用 AFE 的 CC_READY 触发 */
    BQ_ReadCc();                            /* 读走即复位 */
    Soc_OnCcSample(g_bq.cc_raw);
    BQ_ClearSysStat(BQ_STAT_CC_READY);
}
```

触发源是 AFE 的 `CC_READY` 位，而且在 10ms 快速任务里读。

问题出在我的 MATLAB 移植版上：我把这段逻辑简化成了「用固件自己的 250ms 计数器触发，放在 250ms 任务里」。两套独立时钟，相位一错开就会在阶跃点读到陈旧值。那个 +0.18% 的偏差是移植引入的，跟固件无关。

移植版已经改回 `bitand(uint8(sys_stat), uint8(128))` 判 `CC_READY`。修正后表 3 的第 ⑫ 条从「✗ 有缺陷」变成「✓ 有效」。

### 3.2 跟踪误差的基准要用电流积分，不能用真值 SOC

上一版把 +0.18% 的 SOC 跟踪误差判为偏大。

问题在于真值 SOC 里含自放电（本模型 2.5%/月），而这股电流不流过采样电阻，任何 BMS 的库仑计都物理上看不到它。拿真值作基准，就会把自放电整个算成固件的积分误差：

```
F1 场景账目：
  真值 dSOC          = 3.584 %
  电流真实积分折算    = 3.410 %
  ─────────────────────────────
  差额                = 0.174 %   ← 自放电
  自放电理论值（2.5%/月 × 0.5h）= 0.1736 %   ✓ 完全对上
```

所以基准应该用「电流的真实积分」，两项分开列：

```
算法误差%   = 固件 dSOC  − 电流积分折算 dSOC    ← 判据（合格线 0.05%）
自放电多掉% = 真值 dSOC  − 电流积分折算 dSOC    ← 物理必然，BMS 无解
```

长跑套件 `run_longrun_suite.m` 一直在做这个分列（`drift_act` / `drift_dis`），是我在 FSAE 报告里没用同一口径，才得出误判。

按正确口径重算：

| 工况 | 算法误差 | 自放电多掉 |
|---|---|---|
| F1 FSAE 耐力赛 30 分钟 | −0.0012%（−0.4 mAh） | 0.1744% |
| F2 FSAE 多圈脉动 | −0.0021%（−0.6 mAh） | 0.1745% |
| F3 上电静置对齐 | +0.0003%（+0.1 mAh） | 0.0274% |

固件的库仑计精度其实是 0.002% 量级，比旧报告 0.025% 的基准还好一个数量级。

### 3.3 顺带修掉的仿真模型精度问题

追查过程中还发现 `bms_afe_model.m` 的窗口计时不准：

```
窗口触发间隔分布（修正前，60s 场景）：
    25 拍：177 次
    26 拍： 59 次      ← 25% 的窗口变成 260ms
```

原因是 `adc_ms = adc_ms + DT*1000`，而 `DT` 是浮点减法结果（如 `0.009999999999999998`），乘 1000 后累加 25 次只有 `249.99999999999994`，够不到 250。真芯片的 250ms 来自硬件定时器，是严格均匀的。

改成 `adc_ms = adc_ms + round(DT*1000)`（整数毫秒累加）之后：

```
修正后：25 拍 × 7198 次（严格均匀）✓
```

`bms_ctrl_model.m` 的四个任务计数器同样处理。真实固件用的是 `HAL_GetTick()`，本来就是整数毫秒。

## 四、电池数据（FSAE 工况）

工况设定：满电起步，启动电机 30A/3s，之后常态 2A，共 30 分钟。

| 量 | F1（恒流） | F2（多圈脉动） | 理论值 |
|---|---|---|---|
| 总放电量 | 1.0233 Ah（占容量 3.41%） | 1.0233 Ah | —— |
| 单体电压范围 | 3306 ~ 3390 mV | 3243 ~ 3387 mV | —— |
| 组端电压范围 | 13.22 ~ 13.56 V | 12.97 ~ 13.55 V | —— |
| 30A 启动内阻压降 | 93 mV | 97 mV | `30A × R0(3mΩ) = 90 mV` |
| 2A 常态压降 | 9 mV | 12 mV | `2A × (R0+R1)(4mΩ) = 8 mV` |
| 最大压差 | 0 mV | 0 mV | 四组同源 |
| 温升 | 0.55℃ | 0.55℃ | 30A 只 3s，发热 10.8 J |
| 等效循环增量 | 0.017 次 | 0.017 次 | —— |

启动瞬间组端从 13.56 V 跌到 13.24 V（跌 320 mV），3 秒后切 2A 立刻回升，跟物理预期一致。

半小时耐力赛只消耗 3.4% 容量、0.017 个等效循环，对电池寿命没有影响。

## 五、BMS 有效性判定

| 判定 | 项目 | 结论 |
|---|---|---|
| ✓ | 保护未误触发 | 全程 DSG/CHG 未关断，故障码为空 |
| ✓ | 30A 启动未误判过流 | 30A < 放电限值 50A，余量 1.67 倍 |
| ✓ | 电压裕度充足 | 单体 3243~3390 mV，离 UV 2500 / OV 3650 都远 |
| ✓ | SOC 积分精度 | 算法误差 +0.0021%（0.6 mAh），优于 0.05% 合格线 |
| ✓ | EEPROM 掉电记忆 | 上电第一拍即 100.0%，50% 占位值已从代码中删除 |
| ✓ | 上电 OCV 对齐（无记录时） | 静置 15.0s 后对齐到 100.0%，偏差 −0.01% |
| ✓ | 冷启动检测（一级判据） | 待测电芯读数落在零点死区，正确判出冷启动 |
| ✓ | 未对齐时不报假数字 | LED、串口、帧内哨兵值三处同时拦住 |
| ✓ | 库仑计窗口对齐 | 固件用 CC_READY 作唯一触发源，无陈旧窗口（3.1 节） |
| ○ | 自放电（非缺陷） | 真值比库仑计多掉 0.174%/0.5h，物理必然 |
| ○ | 无信息时的边界 | 无记录 + 带载 → 保持 UNKNOWN，符合预期 |
| ○ | 容量学习 | 标定容量 30.000 Ah 全程未更新 |
| ○ | 均衡 | 压差 0 mV < 30 mV 门槛，正确地不动 |
| ✗ | 低压保护可达性 | 16 mΩ 内阻下 30A 只跌 120 mV，够不到 2.5V 门槛 |
| ✓ | 温度 | 温升 0.55℃，在正常范围 |
| ✓ | 采样回路自检 | 全程 `wire_ok=1`，无误报 |

### 关于 F6 的 +16.3%

F6 是均衡与压差对照，人为把 4 组做成 `[100 55 50 55]`，组间差 50%。它的 OCV 对齐结果是 81.3%，真值 65.0%，差了 +16.3%。

原因在 LFP 的 OCV 曲线非线性上。固件用「平均单体电压」去查 OCV 表，但「电压的平均」不等于「平均 SOC 对应的电压」。组间差越大，这个偏差越大。

组间一致时不存在这个问题，F3 和 F7 的偏差都 ≤ 0.1%。

想更准的话，可以改成逐节查表再取平均 SOC，或者干脆逐节维护 SOC。当前 2P4S 的 BMS 只维护一个组 SOC，这是个取舍。

## 六、仍然存在的隐患（按优先级）

| 优先级 | 问题 | 影响 | 建议 |
|---|---|---|---|
| P1 | 低压保护够不到 | 16 mΩ 内阻下 30A 只跌 120 mV，反推要 219A 才够 2.5V 门槛。防过放完全依赖库仑计 SOC | `BMS_EMPTY_DETECT_MV` 提到 3000~3050 mV |
| P1 | 充电侧无硬件过流 | BQ76920 不支持，60A 充电过流只能靠软件；MCU 死机则无保护 | 硬件改动 |
| P2 | 容量学习在深循环不触发 | 需「满充 + 放空」双事件，浅循环和耐力赛两头都够不到，电池衰减后固件不知道 | 放宽条件，或加 `CAP_STALE` 告警 |
| P2 | 均衡能力不足 | 被动均衡仅 1.6~3.3 mA，拉平 1% SOC 要 90~190 小时 | 原理图有 `U7 EXT_BALANCE` 抽头，配外部均衡 |
| P2 | OCV 查表用平均电压 | 组间不一致时偏差大（F6 实测 16%） | 改逐节查表，或逐节维护 SOC |
| P3 | 采样电阻 1mΩ/3W | 限制放电能力到 54.8 A | 换 0.5 mΩ/5W，同步改 `BMS_RSENSE_MOHM` |

## 七、固件改动清单（C 代码细节）

### 7.1 `bms_config.h` 新增宏

```c
/* 上电快速 OCV 对齐 */
#define BMS_OCV_BOOT_MS         15000U  /* 静置稳定至少持续此时长 */
#define BMS_OCV_BOOT_WIN        8U      /* 稳定性判据窗口点数（8 × 250ms = 2s） */
#define BMS_OCV_BOOT_STABLE_MV  20U     /* 窗口内极差 < 此值才认为"电压稳定" */
#define BMS_OCV_BOOT_HOLD       3U      /* 稳定判据需连续满足次数（3 × 2s = 6s） */
#define BMS_OCV_BOOT_WEIGHT     0.50f   /* 上电修正权重（比 30min 慢修正的 0.1 激进） */
#define BMS_OCV_BOOT_SNAP_PCT   8.0f    /* 差异 > 此值 → 直接采信 OCV */

/* EEPROM 掉电记忆 */
#define BMS_SOC_SAVE_DELTA_PCT  1.0f    /* SOC 变化超过此值才落盘 */
#define BMS_SOC_SAVE_MIN_MS     60000U  /* 两次落盘最小间隔 60s */
#define BMS_SOC_UNKNOWN_X10     65535U  /* $BMS 帧里表示"电量未知"的哨兵值 */

/* 待测电芯冷启动检测（一级判据） */
#define BMS_COLDSTART_DETECT     1U      /* 1=启用；0=退回 EEPROM+OCV 两条路 */
#define BMS_STARTUP_ADC_NEUTRAL  2048U   /* ADC 零点码（对应 0V 差分） */
#define BMS_STARTUP_ADC_DEADBAND 48U     /* 死区 ±48 LSB ≈ ±0.77mV */
#define BMS_STARTUP_ADC_MIN      16U     /* 有效读数下限（视为引脚悬空） */
#define BMS_STARTUP_ADC_MAX      4080U   /* 有效读数上限 */
#define BMS_STARTUP_ADC_HANDLE   hadc1   /* 该通道的 ADC 句柄，按 CubeMX 实际改 */
```

### 7.2 `bms_soc.h` 新增接口

```c
/* SOC 可信度分级：把"知道多少"写进类型，避免用 50% 冒充真实电量 */
typedef enum {
    SOC_STATE_UNKNOWN = 0,   /* 电量不可知，禁止显示具体数字 */
    SOC_STATE_RESTORED,      /* 由 EEPROM 掉电记录恢复（最可信） */
    SOC_STATE_OCV_ALIGNED    /* 由 OCV 对齐得到 */
} Soc_State_t;

void        Soc_SetInitialSoc(float soc_pct); /* 用 EEPROM 里存的电量设定上电初值 */
bool        Soc_OnBootOcv(uint16_t avg_cell_mv);/* 上电快速 OCV 对齐，返回 true=已对齐 */
bool        Soc_IsAligned(void);              /* SOC 是否已对齐真实值 */
Soc_State_t Soc_GetState(void);               /* 取可信度分级 */
bool        Soc_IsColdBoot(void);             /* 本次上电是否待测电芯确认的冷启动 */
void        Soc_NotifyColdBoot(bool cold);    /* 由 App 层告知冷启动判定结果 */
uint16_t    Soc_GetPermille(void);            /* 取千分比，供掉电保存 */
```

### 7.3 `bms_soc.c` 关键改动

```c
/* Soc_Init()：删掉 50% 占位，改为显式标记"未知" */
void Soc_Init(float capacity_ah)
{
    ...
    s_remain_nah = 0;              /* 0 只是"还没开始积分"的起点，不是电量 */
    s_aligned    = false;
    s_state      = SOC_STATE_UNKNOWN;
    g_soc.valid  = false;
}

/* Soc_SetInitialSoc()：EEPROM 恢复 → RESTORED */
s_aligned = true;
s_state   = SOC_STATE_RESTORED;

/* Soc_OnBootOcv()：OCV 对齐 → OCV_ALIGNED */
s_state = SOC_STATE_OCV_ALIGNED;

/* Soc_MarkFull() / Soc_MarkEmpty() / Soc_OnRest() 同样同步 s_state */
```

### 7.4 `bms_app.c` 关键改动

```c
void BMS_Init(void)
{
    /* 第 0 步：冷启动检测，必须最先做（早于任何外设初始化） */
    app_detect_cold_boot();

    ...
    Soc_Init(g_param.capacity_ah);
    Soc_NotifyColdBoot(s_cold_boot);

    if (g_param.soc_valid != 0U) {
        Soc_SetInitialSoc((float)g_param.soc_permille / 10.0f);
        BMS_Log("[SOC] 已从 EEPROM 恢复电量 %.1f %%\r\n", Soc_GetPercent());
    } else {
        BMS_Log("[SOC] %s：电量未知，等静置电压稳定后由 OCV 对齐\r\n",
                s_cold_boot ? "待测电芯判定为冷启动" : "无掉电电量记录（热重启）");
    }

    ...
    /* 只有电量已确定时才点亮电量条；未确定则跑马灯 */
    if (app_soc_displayable()) {
        Led_SetMode(LED_MODE_SOC);
        Led_ShowPercent(Soc_GetPercent());
    } else {
        Led_SetMode(LED_MODE_CALIBRATING);
    }
}

/* fast_task() 里 LED 优先级调整：故障 > 电量未确定 > 低电量 > 正常电量条 */
if (g_prot.fault != BMS_FLT_NONE || g_prot.locked) {
    Led_SetMode(LED_MODE_FAULT);
} else if (!app_soc_displayable()) {
    Led_SetMode(LED_MODE_CALIBRATING);   /* ← 新增：不知道电量就不冒充档位 */
} else if (Soc_GetPercent() < BMS_LOW_SOC_WARN_PCT) {
    ...
}

/* cell_task() 里新增：上电快速 OCV 对齐（本次上电只做一次） */
if (!s_boot_done) {
    if (fabsf(g_bq.current_a) < BMS_OCV_REST_A) {
        /* 推入窗口 → 判稳定性（极差 < 20mV 连续 3 次）→ 累计静置 ≥ 15s */
        ...
        if (满足) {
            Soc_OnBootOcv(g_bq.real_avg_mv);
            s_boot_done = true;
            soc_save_now();        /* 刚拿到真值，立刻备份 */
        }
    } else {
        /* 有电流：极化还在，窗口与计时全部作废 */
        s_boot_rest_ms = 0; s_boot_hold = 0; s_boot_cnt = 0; s_boot_idx = 0;
    }
}

/* BMS_Loop() 里：SOC 快照落盘（变化 ≥1% 且距上次 ≥60s） */
if ((now - s_t_param) >= BMS_PARAM_SAVE_MS) {
    s_t_param = now;
    soc_save_now();
    (void)Sto_Save(&g_param);
} else {
    soc_snapshot_task();
}
```

### 7.5 上层显示与上报的改造

三处同时拦住，任何一处漏掉都会让假数字流出去。

```c
/* bms_led.c —— 新增跑马灯模式，绝不停在固定档位 */
case LED_MODE_CALIBRATING:
    if (s_tick >= 30U) { s_tick = 0U; s_phase = (s_phase + 1U) % BMS_LED_COUNT; }
    write_mask((uint8_t)(1U << s_phase));
    break;

/* bms_debug.c —— 串口 ? 命令 */
if (Soc_IsAligned()) {
    BMS_Log("SOC : %5.1f %% ... [来源: %s]\r\n", ...);
} else {
    BMS_Log("SOC : UNKNOWN（电量未确定：%s，等静置电压稳定后由 OCV 对齐）\r\n", ...);
}

/* bms_debug.c —— $BMS 帧 / bms_can.c —— CAN 帧6 */
soc_x10 = Soc_IsAligned() ? (unsigned)(Soc_GetPercent() * 10.0f)
                          : (unsigned)BMS_SOC_UNKNOWN_X10;   /* 65535，正常值只会 0~1000 */
```

### 7.6 EEPROM 版本升级提醒

`BmsParam_t` 新增了 3 个字段，结构体长度变了，而长度参与 `hdr[5]` 校验，所以 `EEPROM_VERSION` 从 `0x01` 升到 `0x02`。

副作用是：升级后第一次上电，旧的掉电参数会被判为长度不符，全部回落到默认值（容量学习值、满充次数、累计运行时间都会丢），之后重新写入即可。

想保住参数的话，得写一个 V1 → V2 迁移函数（读旧结构、拷到新结构、补 `soc_valid = 0`）。当前是开发阶段，没做。

## 八、复现方法

```matlab
cd sim
run_fsae_suite          % 7 个场景，约 35 秒
run_offline_suite       % 10 个短场景回归（验证没破坏原有行为），约 40 秒
```

产出：

- `sim/fsae_results.mat` —— 全部原始数据
- `sim/figs_fsae/*.png` —— 8 张图（7 工况 + 1 张上电对齐过程专题图）
- 控制台 3 张判据表

单独跑一个工况：

```matlab
R = run_bms_offline('FSAE_耐力赛30分钟');     % EEPROM 恢复（boot_soc=100）
R = run_bms_offline('FSAE_静置对齐验证');     % 无记录 → OCV 对齐
R = run_bms_offline('FSAE_上电无记录对照');   % 无记录 + 带载 → 物理边界
```

自定义上电初值：

```matlab
opt = struct('scen',13,'T',1800,'dt',0.01,'soc0',[100 100 100 100], ...
             'boot_soc',80, ...     % 模拟 EEPROM 里存的是 80%
             'name','上电80%');
R = run_bms_offline(opt);
```

## 九、这套仿真的局限

1. 跑的是固件逻辑的 MATLAB 移植版，不是编译后的 C 代码。本次正因移植偏差导致了一处误判（3.1 节），说明这个局限是真实存在的。关键结论建议用真机验证，尤其上电 OCV 对齐，用示波器抓上电瞬间的电流与电压更直接。
2. 2P 组被等效成一只 30Ah / 4mΩ 电芯，BMS 看不到两只并联单体之间的差异。
3. 热模型是单节点集总的，不能用于散热设计。
4. 不在环的硬件：MOS 导通电阻与开关损耗、预充回路、I²C 时序与 CRC、CAN 通信、EEPROM 读写时序、看门狗。
5. 启动电机 30A @ 12V 是按给定值直接当负载电流，没有建模电机的启动特性（堵转电流、反电动势）。真实启动峰值可能远高于 30A。
6. AT24C02 的擦写寿命：SOC 变化 1% 落盘一次，按 FSAE 工况估算约每 9 分钟一次，一天跑 4 小时约 27 次，远低于 100 万次上限。但如果 SOC 在门槛附近反复跳变，`BMS_SOC_SAVE_MIN_MS` 的 60 秒限流就是必需的。
7. 冷启动检测未在仿真中建模，它依赖 MCU 上电瞬间的物理状态，纯算法回路复现不出来。本报告只覆盖了冷启动判定之后的分支行为，即 EEPROM 恢复与 OCV 对齐。硬件侧需要用示波器验证待测电芯的实际上电波形，并确认 `BMS_STARTUP_ADC_NEUTRAL` / `BMS_STARTUP_ADC_DEADBAND` 的取值与运放电路匹配。

## 附录：关键数据速查

| 项目 | 数值 |
|---|---|
| 上电 SOC（EEPROM 恢复） | 100.0%（偏差 +0.00%） |
| 上电 SOC（OCV 对齐，无记录时） | 100.0% @ t=15.0s（偏差 −0.01%） |
| 上电 SOC（无记录 + 带载） | UNKNOWN（不显示数字，非缺陷） |
| SOC 占位值 50% | 已从代码中删除 |
| 算法误差（库仑计） | −0.0012% ~ +0.0021%（≤0.6 mAh） |
| 自放电多掉 | 0.174%/0.5h（非缺陷） |
| 30A 启动内阻压降 | 93 mV/单体（理论 90 mV） |
| 常态 2A 压降 | 9 mV/单体（理论 8 mV） |
| 温升 | 0.55℃ |
| 全程故障码 | 无 |
| MOS 关断 | 无 |
| 等效循环增量 | 0.017 次 |
| 套件耗时 | 35.5 s（7 工况） |
