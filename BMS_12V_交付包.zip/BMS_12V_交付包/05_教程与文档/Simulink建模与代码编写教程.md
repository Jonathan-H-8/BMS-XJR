# Simulink 仿真从建模到写代码（完整详解）

> 以本项目的 BMS C33 2P4S 为例，从零讲一遍 Simulink 建模的完整方法。
> 每一步都对应 `sim/` 目录里的真实文件，可以对照着看。
>
> 配套文档
> - `Simulink手工搭建操作手册.md` ← 想动手在界面里搭，看这份（纯操作步骤，照做即可）
> - `sim/README.md`，模型结构与能力边界
> - `手把手跑仿真教程.md`，只想跑起来看结果，看这份
>
> 本文讲的是为什么这么做，手工搭建手册讲的是具体怎么点。

---

## 〇、先说结论：Simulink 建模的五个阶段

```
① 画信号流图     →  想清楚"谁给谁什么数据"
② 定接口         →  每个端口的 名字 / 尺寸 / 类型（最容易埋坑的一步）
③ 写块内代码     →  MATLAB Function 块的 .m 文件（有严格禁忌）
④ 脚本化装配     →  用代码生成 .slx，而不是手工拖块
⑤ 先单块后整机   →  逐个块编译通过，再整机
```

顺序不能颠倒，尤其是 ②③④ 的顺序。理由下面每一节都会说。

> 一个环境前提（本项目实测）：Simulink 在 MATLAB 桌面（GUI） 里跑是正常的，
> 但在无界面模式（命令行 `matlab -batch`）下首次初始化极慢，
> 本机实测 15 分钟都没跑完一次模型重建。所以跑 Simulink 请务必开 MATLAB 桌面。
> 纯 MATLAB 路线（`quickstart`）没有这个问题，命令行下几秒就跑完。

---

## 一、第 ① 步：画信号流图

### 核心设计原则：把"芯片"和"固件"分开

很多人做 BMS 仿真的第一反应是写一个大模型：把电池、芯片、固件都揉进一个块。
这是错的，而且错得很隐蔽，因为揉在一起之后，你会不知不觉地
「用理想化的芯片去测固件」，测出来全是假通过。

正确做法是在信道上切开：

```
                      ┌──────────────────┐
  工况 ──► i_cmd ────►│  Plant           │  8 只 C33 的等效电路 + 发热
                      │  电池组（被控对象）│
                      └──┬───────────┬───┘
        i_pack/v_true/t  │           │ v_pack_true
                         ▼           └──► [Memory] ──► 回到工况块
                  ┌──────────────┐
                  │  AFE         │  BQ76920 芯片本身：
                  │  BQ76920     │  寄存器、量化、延迟、硬件保护
                  └──────┬───────┘
        寄存器读数      │   cc_raw / sys_stat / v_meas / ts1_adc
                         ▼
                  ┌──────────────┐
                  │  Firmware    │  你要测的固件逻辑
                  │  bms_*.c移植 │
                  └──────┬───────┘
                         │ chg_en / dsg_en / bal_mask / cc_read
                         ▼
                    [Memory] ──► 回到 Plant（MOS 门控）
```

为什么这么切？因为真实的固件只能通过 I²C 读到寄存器。
一旦把 AFE 的量化、延迟、锁存行为都模拟出来，固件块能拿到的信息就和真板子一模一样：

| 固件"以为"自己拿到的 | 实际 AFE 给它的 |
|---|---|
| 单体电压 | 380 µV/LSB 量化过、250 ms 才更新一次的值 |
| 电流 | 库仑计每 250 ms 的积分结果，1 LSB = 8.44 mA |
| 温度 | TS1 通道的 ADC 码（还要自己查 NTC 表） |
| 保护状态 | SYS_STAT 的锁存位（不清位就一直置着） |

只有这样测得出来的问题才是真问题。

### 本项目分成四块

| 块 | 职责 | 对应源码 |
|---|---|---|
| `Profile` | 负载 + 充电机（工况、CC-CV） | `bms_profile_model.m` |
| `Plant_4Group_ECM` | 8 只 C33 组成的 2P4S + 热模型 | `bms_plant_model.m` |
| `AFE_BQ76920` | 芯片行为 | `bms_afe_model.m` |
| `BMS_Firmware` | 固件逻辑 | `bms_ctrl_model.m` |

注意 `Plant` 的建模口径：BMS 只能测到"并联组"的电压，测不到 2 只并联单体之间的差异。
所以把每个 2P 组等效成一只 30 Ah / 4 mΩ 的电芯，在端子特性上等价，
而且正好是 BMS 能观测的量。要看并联环流就得建完整 8 电芯模型（另一条路）。

---

## 二、第 ② 步：定接口（最容易埋坑的一步）

这一步比写代码更重要。 Simulink 的 MATLAB Function 块对端口尺寸/类型非常挑剔，
接口没定清楚，后面会以「无法确定模块的输出大小和/或类型」这种含糊报错的形式折磨你。

### 做法：先列一张端口表

以 AFE 块为例，写代码前先把这张表填好：

| 端口 | 方向 | 尺寸 | 类型 | 含义 |
|---|---|---|---|---|
| `i_pack` | 入 | 1 | double | 组电流 A |
| `v_true` | 入 | 4 | double | 4 组真实电压 mV |
| `t_cell` | 入 | 1 | double | 电芯温度 ℃ |
| `bal_mask` | 入 | 1 | double | 均衡掩码 |
| `cc_read` | 入 | 1 | double | 读库仑计脉冲 |
| `clr_mask` | 入 | 1 | double | SYS_STAT 清位掩码 |
| `inj_cell` | 入 | 4 | double | 单体故障注入 |
| `inj_ntc` | 入 | 1 | double | NTC 故障注入 |
| `t` | 入 | 1 | double | 仿真时间 s |
| `rst` | 入 | 1 | double | 复位脉冲 |
| `y` | 出 | 10 | double | 打包向量（见下） |

注意两点：

1. 尺寸写 `1` 不写 `[1 1]`。Stateflow 的写法里标量就是 `'1'`。
   写成 `'[1 1]'` 会变成二维，下游接标量端口时报「端口宽度或维度出错」。
2. 向量端口写 `4`，表示 1×4。

### 关键技巧：把多输出打包成"单一向量输出"

这是本项目的血泪经验。如果一个块有多个输出、且类型还混杂，尺寸推断很容易失败。

最初 `BMS_Firmware` 块有 12 个独立输出（`double` 和 `uint8` 混着），编译直接报：

```
Simulink 无法确定模块 'BMS_C33_2P4S/BMS_Firmware' 的输出大小和/或类型。
错误可能不准确。请修复指示的错误，或显式指定所有模块输出的大小和/或类型。
```

注意：即使我在装配脚本里已经把每个端口的尺寸和类型都显式指定了，它还是报。
这就是 Stateflow 内部推断器的限制，不是用法问题。

解法：把输出全部打包成一个向量。

```matlab
% 改前：7 个独立输出，类型还混着 uint8
function [cc_raw, cc_ready, sys_stat, v_meas, v_pack_meas, ts1_adc, bal_drop] = ...
         bms_afe_model(...)

% 改后：单一向量输出
function y = bms_afe_model(...)
...
y = zeros(1, 10);
y(1) = cc_raw;
y(2) = double(cc_ready);
y(3) = double(sys_stat);
for g = 1:4
    y(3+g) = v_meas(g);        % y(4)..y(7)
end
y(8)  = v_pack_meas;
y(9)  = ts1_adc;
y(10) = bal_drop;
```

外部用 Demux 拆开。代价是可读性差一点，换来的是能跑起来。

> 实测：`BMS_Firmware`（26 维）和 `AFE_BQ76920`（10 维）都改成向量输出后，
> 两个块的推断问题都解决了。`Profile`、`Plant` 输出少且类型统一，不需要改。

### 向量里的"子向量"要重新合成

`v_meas` 是 `y(4:7)` 这四个相邻标量。Demux 出来是 4 条独立的线，
而固件块要的是一个 1×4 向量，所以中间要加一个 Mux(4) 合回来：

```matlab
add_block(blkMux, [mdl '/Mux_vmeas'], 'Inputs', '4', 'Position', [...]);
L('Demux_afe/4', 'Mux_vmeas/1');
L('Demux_afe/5', 'Mux_vmeas/2');
L('Demux_afe/6', 'Mux_vmeas/3');
L('Demux_afe/7', 'Mux_vmeas/4');
L('Mux_vmeas/1', 'BMS_Firmware/3');      % 给固件的 v_meas
```

### 顺带一个类型陷阱

打包后 `sys_stat` 从 `uint8` 变成了 `double`（向量里不能混类型）。
所以 BMS 块的 `sys_stat` 输入端口规格必须一起改成 `double`，否则报类型不匹配：

```matlab
% 改前
'sys_stat','{1,''uint8''}'
% 改后
'sys_stat','{1,''double''}'
```

固件代码内部本来就有显式转换（`bitand(uint8(sys_stat), uint8(4))`），所以逻辑不用改。

---

## 三、第 ③ 步：写块内代码

### 3.1 代码放在独立 .m 文件里，不要手敲进块

推荐做法：模型代码写在 `.m` 文件里，用脚本注入到块中。好处：

- 能进版本管理，能 diff
- 能直接在 MATLAB 里单独调用调试（`y = bms_afe_model(...)` 直接跑）
- 重建模型时自动同步，不会出现"块里是旧代码"

注入的核心代码（`build_bms_model.m` 里的 `fillMFcn`）：

```matlab
txt = fileread(mfile);                                    % 读 .m 全文
rt  = sfroot;
ch  = rt.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/' blkName]);
ch(1).Script = txt;                                       % 写进块

% 再逐个端口设置尺寸与类型
d = ch(1).find('-isa', 'Stateflow.Data');
for k = 1:numel(d)
    nm = d(k).Name;
    if isfield(spec, nm)
        d(k).Props.Array.Size = num2str(spec.(nm){1});    % 必须传字符，不能传数字
        d(k).Props.Array.IsDynamic = false;               % 关掉动态尺寸
        d(k).DataType = spec.(nm){2};
    end
end
```

两个 `` 是踩过的坑：`Array.Size` 传数字会静默失败但 `catch` 到，
`IsDynamic` 不关掉会让推断器认为尺寸可变。

### 3.2 代码生成的六条禁忌（全部实际踩过）

MATLAB Function 块用的是代码生成器，不是解释器。下面这些写法在 MATLAB 里能跑，
但块里会报错或推断失败：

#### 禁忌 1：结构体动态添加字段

```matlab
% 错误：P.chg_ok 没在 struct() 里声明过
P = struct('soc', 50);
P.chg_ok = true;              % 直接让整个块报"无法确定输出大小"

% 正确：全部改成普通数组变量
soc = 50; chg_ok = true;
```

本项目为此把 88 个字段拆成了普通变量（见 `bms_ctrl_model.m` 的 persistent 列表）。

#### 禁忌 2：变尺寸切片

```matlab
% 错误：k 是变量，切片长度可变
s = sum(buf(1:k));

% 正确：固定次数循环 + 条件累加
s = 0;
for i = 1:MAXN
    if i <= k, s = s + buf(i); end
end
```

#### 禁忌 3：标量 + 向量的隐式扩展

```matlab
% 错误：0 是标量，v 是向量
v = max(0, v);

% 正确：逐元素循环
for g = 1:4
    if v(g) < 0, v(g) = 0; end
end
```

#### 禁忌 4：注释里的 ASCII 双引号

```matlab
% 错误：Stateflow 解析器报"解析时出错"（MATLAB 自己却没事）
x = 1;   % 这是"重要"的变量

% 正确：用中文引号，或者干脆不用
x = 1;   % 这是「重要」的变量
```

这条最阴，报错信息是"解析时出错"，完全看不出跟注释有关。

#### 禁忌 5：`persistent` 跨 `sim` 不清零

同一个 MATLAB 会话里连续跑两次 `sim`，`persistent` 变量不会自动清零。
后果：第二个场景会接着第一个场景的 SOC 继续跑，结果全错。

解法：每个块都加一个 `rst` 输入，开头显式复位：

```matlab
persistent soc vrc temp tprev
if isempty(soc)                    % 首次进入：给默认初值
    soc = [60 60 57 60]; vrc = zeros(1,4); temp = 25*ones(1,4); tprev = -1;
end
if tprev < 0 || rst > 0            % 复位脉冲
    for g = 1:4
        soc(g) = soc0(g); vrc(g) = 0; temp(g) = t_amb;
    end
    tprev = t;
end
```

`SCEN` 矩阵每一列都带 `rst`，头两拍给 1（见第五节）。

> 注意：给 persistent 数组赋值要逐元素写 `soc(g) = soc0(g)`，
> 不要写 `soc = soc0`。后者会让 Simulink 在推断 persistent 尺寸时
> 与输入端口尺寸互相牵扯。

#### 禁忌 6：局部常量要在使用前定义

```matlab
% 错误：ADC_MS 定义在 if 分支之后
if isempty(tick)
    adc_ms = ADC_MS;      % 这里 ADC_MS 还不存在 → 取到空值
end
ADC_MS = 250;

% 正确：常量提到 persistent 块之前
ADC_MS = 250;
if isempty(tick)
    adc_ms = ADC_MS;
end
```

#### 顺带：不要用 `mod(tick, N)` 做周期调度

```matlab
% 错误：只在步长恰好 10ms 时，25 拍才等于 250ms
if mod(tick, 25) == 0

% 正确：时间累加计数器
acc_c = acc_c + DT_MS;
if acc_c >= 250
    d_cell = 1;  acc_c = acc_c - 250;
end
```

前者一旦改步长就整片失效（0.2 s 步长会变成 5 s 才采一次），
后者在任何步长下都正确。这个缺陷在项目里真实存在过并已修复。

### 3.3 块的代码骨架

结合上面所有约束，一个块的 `.m` 大致长这样：

```matlab
function y = my_model(in1, in2, t, rst)
%%#codegen                       % ← 建议加，提示这是代码生成目标
%MY_MODEL  一句话说明
%   详细注释...

%% ---------- 常量 ----------
% 全部提到最前面（禁忌 6），且与 bms_config.h 一一对应
MY_THRESHOLD = 3650;

%% ---------- 持久状态 ----------
persistent s1 s2 prev_t
if isempty(s1)
    s1 = 0; s2 = 0; prev_t = -1;
end
if rst > 0                      % 必须有（禁忌 5）
    s1 = 0; s2 = 0; prev_t = -1;
end

%% ---------- 步长 ----------
% 用时间差算，不假设固定步长
if prev_t < 0
    DT = 0.01;
else
    DT = t - prev_t;
    if DT <= 0, DT = 0.01; end
end
prev_t = t;

%% ---------- 业务逻辑 ----------
% 普通数组、固定次数循环、逐元素操作（禁忌 1/2/3）

%% ---------- 输出打包 ----------
y = zeros(1, N);
y(1) = ...;
end
```

---

## 四、第 ④ 步：脚本化装配

不要手工拖块连线。用脚本生成模型，理由：

- 可重复：改一行重跑一次就行
- 可版本管理：`.slx` 是二进制，diff 不了；`.m` 可以
- 不会漏：手工连 60 条线一定会错

### 4.1 用标准库块的规范路径

```matlab
blkMFcn   = 'simulink/User-Defined Functions/MATLAB Function';
blkFromWS = 'simulink/Sources/From Workspace';
blkDemux  = 'simulink/Signal Routing/Demux';
blkMux    = 'simulink/Signal Routing/Mux';
blkToWS   = 'simulink/Sinks/To Workspace';
blkScope  = 'simulink/Sinks/Scope';
blkClock  = 'simulink/Sources/Clock';
blkMemory = 'simulink/Discrete/Memory';
load_system('simulink');       % 不加载的话 get_param 检查路径会失败
```

> 不要用 `find_system` 遍历整个 Simulink 库去找块，那要几分钟。
> 直接用上面的规范路径，`add_block` 秒过。

### 4.2 求解器设置（定步长离散）

```matlab
new_system(modelName);
set_param(mdl, 'SolverType', 'Fixed-step', ...
               'Solver', 'FixedStepDiscrete', ...
               'FixedStep', '0.01');        % 10 ms，与固件主循环一致
```

为什么必须 10 ms：固件的时间常数（250 ms 采样、100 ms 去抖、320 ms 过流延时）
都是按这个步长设计的。步长放大到 100 ms 就分辨不出保护动作的时序了。
（长跑时不得不放宽，但那时只看长期趋势，不看时序，见 `长时间仿真测试报告.md`。）

### 4.3 代数环与两处 Memory

`电流 → AFE → 固件 → MOS 门控 → 电流` 在 Simulink 里构成代数环，会直接报错。

解法：在合适的地方插 `Memory` 块（输出 = 上一拍的输入）。本项目插了两处：

```matlab
% ① MOS 状态 → Memory → Plant
%    物理上成立：MOS 状态本来就下一拍才影响电流
add_block(blkMux,    [mdl '/Mux_ctl'],   'Inputs', '3', ...);
add_block(blkMemory, [mdl '/Mem_ctl'],   ...);
add_block(blkDemux,  [mdl '/Demux_ctl'], 'Outputs', '3', ...);

% ② Plant 端电压 → Memory → 工况块
%    CC-CV 需要上一拍的电压来判断该恒流还是恒压
add_block(blkMemory, [mdl '/Mem_vpack'], ...);

% ③ 给 AFE 的控制量也要一拍延迟（bal_mask/cc_read/clr_mask）
add_block(blkMemory, [mdl '/Mem_afein'], ...);
```

强调一下：这些 Memory 的位置和数量由真实物理延迟决定，跟"让它能跑"无关，
因果关系顺序。如果加 Memory 只是为了消错，说明模型结构有问题。

### 4.4 日志与示波器

```matlab
add_block(blkToWS, [mdl '/LOG_PLANT'], 'VariableName', 'LOG_PLANT', ...
          'SaveFormat', 'Structure With Time', ...);
add_block(blkScope, [mdl '/Scope_V_I'], 'NumInputPorts', '4', ...);
```

跑完 `out.LOG_PLANT.signals.values` 就能取到数据，用 `Mux` 把要看的量拼成一列一列。

---

## 五、第 ⑤ 步：先单块，后整机

不要一上来就整机仿真。出错信息会含糊到无法定位。
按这个顺序排查，每步都能确定问题范围：

### 5.1 先直接调用函数（不经过 Simulink）

```matlab
y = bms_afe_model(-30, [3218 3218 3216 3218], 25, 0, 0, 0, [0 0 0 0], 0, 0.01, 1);
disp(y)      % 看数值对不对
```

这一步能排除"算法写错了"。如果不通过，问题在代码，不在 Simulink。

### 5.2 再逐个块单独编译

给每个块的输入接 `Constant` 源，编译一次：

```matlab
% 伪代码：为每个块建一个只含该块的临时模型，编译
for each block
    new_system(['t_' name]);
    add_block(blkMFcn, ...); fillMFcn(...);
    set_param(model, 'SimulationCommand', 'update');   % update 就会触发推断
    % 报错 → 问题在这个块
end
```

> `set_param(mdl,'SimulationCommand','update')` 是诊断利器，
> 它只做编译（尺寸/类型推断 + 块初始化），不真的跑仿真，几秒就出结果。

本项目的排查结论（`sim/_debug/diag_out.txt`）：
`Profile` 编译 OK 且仿真 OK，`Plant` 编译 OK，问题只出在输出多、类型杂的块。

### 5.3 最后整机

单块都通过了，整机若还报错，那一定是连线/接口层面的问题
（尺寸不匹配、类型不匹配、漏连），而不是块内部。

---

## 六、组装：完整的可复现流程

```matlab
cd sim

% ① 读固件阈值（保证仿真与固件用同一套参数）
cfg = load_bms_config();           % 解析 ../bms_firmware/Core/Inc/bms_config.h
P   = c33_2p4s_params(cfg);        % C33 2P4S 电池参数

% ② 生成模型（含四块装配、代码注入、端口尺寸声明、连线）
build_bms_model(cfg, P);           % 产出 BMS_C33_2P4S.slx

% ③ 跑
run_bms_scenarios;                 % Simulink 路线
% 或（推荐，快一个量级）
run_offline_suite;                 % 纯 MATLAB 路线，执行顺序完全等价
```

### 工况怎么喂：`SCEN` 矩阵

Simulink 侧用 `From Workspace` 读一个叫 `SCEN` 的矩阵，列定义固定：

```
t | scen | chgLim | dsgLim | clr | inj1 | inj2 | inj3 | inj4 | injNTC | t_amb | rst | soc0(1..4)
```

| 列 | 含义 |
|---|---|
| `scen` | 工况编号（1 静置 / 2 放电 1C / 3 CC-CV 充电 / 4 过流放电 / 5 过流充电 / 6 循环 / 7 短路 / 8 低温 / 9 高温） |
| `chgLim`/`dsgLim` | 运行时可下发的限流值（模拟串口 SET 命令） |
| `clr` | 清故障脉冲 |
| `inj1..4` | 单体注入（0 正常 / 3 采样线开路 / 4 接反） |
| `injNTC` | NTC 注入（0 正常 / 5 短路 / 6 开路） |
| `t_amb` | 环境温度 ℃ |
| `rst` | 复位脉冲，头两拍必须给 1（见禁忌 5） |
| `soc0(1..4)` | 复位后的各组初始 SOC（故意做得不一致，用来触发均衡） |

构造示例：

```matlab
dt = 0.05; tt = (0:dt:60)'; n = numel(tt);
rst = zeros(n,1); rst(1:2) = 1;
SCEN = [tt, 4*ones(n,1), 30*ones(n,1), 50*ones(n,1), zeros(n,1), ...
        zeros(n,4), zeros(n,1), 25*ones(n,1), rst, repmat([60 60 57 60],n,1)];
assignin('base','SCEN',SCEN);      % From Workspace 从 base 工作区取
set_param('BMS_C33_2P4S','StopTime','60');
out = sim('BMS_C33_2P4S');
```

---

## 七、踩坑速查表

| 报错 / 现象 | 真正的原因 | 解法 |
|---|---|---|
| `Simulink 无法确定模块的输出大小和/或类型` | 输出端口多 + 类型混杂 | 打包成单一向量输出（见 2.2） |
| `端口宽度或维度出错…是有 1 个元素的一维向量` | 尺寸写了 `[1 1]` 或未关 `IsDynamic` | 规格写 `'1'`，`IsDynamic = false` |
| `解析时出错`（完全看不出原因） | 注释里有 ASCII 双引号 | 改中文引号 |
| 第二个场景接着第一个场景跑 | `persistent` 跨 `sim` 不清零 | 加 `rst` 输入显式复位 |
| `代数环` 报错 | 电流↔MOS 反馈 | 插 `Memory`（要有物理依据） |
| `new_system` 报错 | 模型名含中文 | 用纯 ASCII 名 |
| 类型不匹配 | 上游改成 double 后下游还是 uint8 | 同步改端口规格 |
| 块里数值是 0 / 空的 | 局部常量定义在使用之后 | 常量提到最前面 |
| 编译卡几分钟 | `find_system` 遍历库 | 改用规范路径 |
| 仿真慢得离谱 | 用了变步长求解器 | 改 `FixedStepDiscrete` |

---

## 八、这套方法能推广到哪里

上面的六个禁忌、Memory 打断代数环、单一向量输出、脚本化装配，
不限于 BMS。任何"数字控制器 + 被控对象"的 Simulink 仿真都是同一套：

- 电机控制（FOC：电流环 → 逆变器 → 电机）
- 电源（DC-DC：PWM → 开关 → 电感电容）
- 热管理、液压、飞控……

记两条就够：
1. 把"传感器/执行器硬件"单独建块，让控制器只能看到真实硬件会给它的信息
2. 接口先行，且输出尽量打包成单一向量

---

## 九、下一步：真 C 代码在环（可选）

现在跑的是固件逻辑的 MATLAB 移植版，不是编译后的 C 代码。
要做到"真 C 代码在环"（SIL/PIL）：

1. 装 MathWorks 的 MinGW-w64 支持包（本机目前 `mex` 一个编译器都没有）
2. 用 S-Function Builder 把 `bms_soc.c` / `bms_protect.c` / `bms_cells.c`
   包一层 HAL 桩函数
3. 本项目的块接口就是照这个目标设计的：
   `cc_raw` / `sys_stat` / `v_meas` / `ts1_adc` 四个输入，正好对应固件读 I²C 拿到的东西

迁过去之后，"仿真通过"与"板上通过"之间就只剩硬件差异了。

---

## 十、本项目的验证状态（如实说明）

写教程最忌讳把"没验证的"说成"已验证"。所以这一节把边界讲清楚。

### 已经实测通过的

| 项目 | 结果 |
|---|---|
| 纯 MATLAB 路线（`quickstart`） | 12 个短场景全部通过；结果与改造前逐项一致（0.33 s / 0.00 s / 4.10 s 等保护时序、−9.25% 初始偏差全部复现） |
| AFE 块单向量输出改造的打包逻辑 | 单独调用验证：向量长度 10、`v_pack_meas` 等于 4 节之和、`-30 A` 时 `cc_raw ≈ −3697 LSB`、25℃ 时 NTC 分压算得 1.65 V  |
| `Profile` / `Plant` 两块 | 编译通过（历史记录 `sim/_debug/diag_out.txt`） |

### 已完成但未能在本环境实跑验证的

| 项目 | 状态 |
|---|---|
| Simulink 整机编译与仿真 | 代码改造已完成（AFE 打包 + 装配脚本同步改好），但没能实跑验证，原因是无界面模式下 Simulink 初始化超时（实测 15 分钟无输出），不是代码问题 |

为什么说"代码上应该没问题"：
AFE 块的改法与 `BMS_Firmware` 块完全相同，而 BMS 块正是当初报同一个错、
改成向量输出后通过了。两者是同一个病、同一个药。

你在 MATLAB 桌面里跑时，按这个顺序确认：

```matlab
cd sim
cfg = load_bms_config();  P = c33_2p4s_params(cfg);
build_bms_model(cfg, P);                    % ① 重建（GUI 下几分钟内完成）

load_system('BMS_C33_2P4S');
set_param('BMS_C33_2P4S','SimulationCommand','update');   % ② 编译：这一步验证尺寸推断

% ③ 若 ② 过了，跑一个短场景与纯 MATLAB 结果对照
```

第 ② 步就是"验收关卡"。如果它通过，说明 2.2 节讲的问题确实解决了；
如果还报「无法确定输出大小和/或类型」，那说明我对根因的判断只对了一半，
需要继续二分定位（方法见 5.2 节）。

### 排查时最有用的三个工具

```matlab
% ① 只编译不仿真，几秒出结果，专门验证尺寸/类型推断
set_param(mdl, 'SimulationCommand', 'update');

% ② 直接调用函数，排除"算法写错"的可能
y = bms_afe_model(-30, [3218 3218 3216 3218], 25, 0, 0, 0, [0 0 0 0], 0, 0.01, 1);

% ③ 看块的端口被推断成什么（尺寸/类型不对时最直观）
chs = sfroot().find('-isa','Stateflow.EMChart','Path',[mdl '/AFE_BQ76920']);
for d = chs(1).find('-isa','Stateflow.Data')'
    fprintf('%-14s size=%-8s type=%s\n', d.Name, d.Props.Array.Size, d.DataType);
end
```

`sim/_debug/` 目录里留着本项目所有的排查脚本（`diag_speed.m` 测各步骤耗时、
`check_afe_pack.m` 验打包、`diag_blocks.m` 逐块编译），下次遇到类似问题可以直接改用。
