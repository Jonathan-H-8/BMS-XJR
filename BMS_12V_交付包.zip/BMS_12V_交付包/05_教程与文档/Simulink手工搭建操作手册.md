# Simulink 手工搭建操作手册（照着做就行）

> 目标：在 Simulink 界面里一步一步手工搭出 BMS 仿真模型 `BMS_Manual.slx`。
> 全手工、不跑脚本。每个步骤都写了「怎么操作」和「怎么确认这步对了」。
>
> 配套文档：`Simulink建模与代码编写教程.md`（讲原理和禁忌，本手册只讲操作）

---

## 〇、中文界面术语对照（用中文版 MATLAB 的先看这节）

本手册里的界面术语按 英文写，但你的 MATLAB 是中文界面，所以先对一下表。
（下面带  的是我从你机器上的语言包 `resources/Simulink/zh_CN/` 里确认过的官方翻译，
其余是通行译名。）

| 我手册里写的 | 中文界面显示 | 在哪儿找 |
|---|---|---|
| Modeling | 建模 | 顶部选项卡 |
| Model Settings | 模型设置 | 「建模」选项卡里，快捷键 `Ctrl+E` |
| Solver | 求解器 | 模型设置对话框左侧列表 |
| Type | 类型 | 求解器面板顶部 |
| Fixed-step | 定步长 | 「类型」下拉框里（不是"固定步长"） |
| Variable-step | 变步长 | 同上 |
| discrete (no continuous states) | 离散（无连续状态） | 「求解器」下拉框 |
| Fixed-step size | 定步长 | 面板中部，填 `0.01` 那一栏 |
| Block | 模块 | 中文版把 Block 译为「模块」不是「块」 |
| Edit Data | 编辑数据 | MATLAB Function 块编辑器工具栏 |
| Size / Type / Scope | 大小 / 类型 / 作用域 | 「编辑数据」面板的列名 |
| Number of outputs | 输出数目 | Demux 的块参数 |
| Number of inputs | 输入数目 | Mux 的块参数 |
| Number of input ports | 输入端口数目 | 示波器的块参数 |
| Variable name | 变量名称 | From / To Workspace |
| Save format | 保存格式 | To Workspace |
| Structure With Time | 带时间的结构体 | 「保存格式」下拉选项 |
| Output after final value | 最终值之后的输出 | From Workspace |
| Holding final value | 保持最终值 | 该下拉里的选项 |

### 块名对照（双击画布输入任一种都能搜到）

| 英文 | 中文界面 |
|---|---|
| MATLAB Function | MATLAB Function（这个不翻译） |
| Scope | 示波器 |
| Memory | 存储器 |
| Demux | 多路分解器 |
| Mux | 多路复用器 |
| Terminator | 终止符 |
| Clock | 时钟 |
| From Workspace | 来自工作区 |
| To Workspace | 到工作区 |
| Constant | 常量 |

### 三个能绕开语言问题的技巧

技巧 1：双击画布直接搜英文块名。
在模型画布空白处双击，输入 `memory`、`scope`、`demux`，
Simulink 会列出匹配的块，中文版也认英文关键词（块的内部类型名是英文的）。
比在 Library Browser 里按中文一层层翻快得多。

技巧 2：菜单找不到就用快捷键。
`Ctrl+E` 直接打开模型设置，不用管菜单位置。

技巧 3：不想在界面里翻，就用命令设。
所有块参数和求解器都能用命令行设置，完全不受界面语言影响：

```matlab
% 求解器（不用翻模型设置对话框）
set_param('BMS_Manual', 'SolverType', 'Fixed-step', ...
                       'Solver', 'FixedStepDiscrete', ...
                       'FixedStep', '0.01');

% 块参数（不用双击块找对话框）
set_param('BMS_Manual/Demux_afe',  'Outputs', '10');
set_param('BMS_Manual/Mux_vmeas',  'Inputs',  '4');
set_param('BMS_Manual/SCEN',       'VariableName', 'SCEN');
set_param('BMS_Manual/LOG_PLANT',  'VariableName', 'LOG_PLANT', ...
                                   'SaveFormat', 'Structure With Time');
set_param('BMS_Manual/Scope_V_I',  'NumInputPorts', '4');
```

> 界面和命令改的是同一份东西，用哪种都行。界面操作更直观，命令更快更准。

---

## 〇之二、先打个招呼：这是个体力活

说清楚预期，免得你中途怀疑自己：

| | 数量 |
|---|---|
| MATLAB Function 块 | 4 个（每个要粘 100~700 行代码） |
| 辅助块（Memory/Demux/Mux/...） | 20 个 |
| 连线 | 60+ 条 |
| 端口尺寸要手工填 | 40+ 个 |

全手工大约 1~2 小时。但搭一遍之后，这个模型的每根线你都清楚了，
之后想改结构、加块、做硬件在环，都是在这个基础上动。

> 搭完记得 `Ctrl+S` 保存。以后想重建，直接用
> `build_bms_model(cfg,P)` 一条命令，不必再手工来一遍。

### 手工搭建的三个效率技巧

1. 双击画布空白处直接搜索块：不用去 Library Browser（库浏览器）一层层翻。
   双击 → 输入 `memory` → 回车，块就下来了。
   中文版也认英文关键词（块的内部类型名是英文），所以直接打英文最快；
   打中文如"存储器"也能搜到。
2. 复制粘贴代替重复拖拽：先摆一个 Memory，`Ctrl+C`/`Ctrl+V` 复制出另外两个，
   位置再拖一下。
3. 代码用外部编辑器写好再整段粘贴：不要在小窗口里敲。

---

## 一、准备工作

### 1.1 打开 MATLAB，切目录

```matlab
cd('C:\Users\admin\WorkBuddy\2026-09-14-22-07-51\sim')
```

### 1.2 新建模型

在命令行敲：

```matlab
new_system('BMS_Manual');      % 建一个新模型
open_system('BMS_Manual');     % 打开它
```

或者点 MATLAB 工具栏的 Simulink 按钮 → Blank Model → `Ctrl+S` 存成 `BMS_Manual.slx`。

> 模型名不要用中文，`new_system` 会直接报错。

### 1.3 第一件事：设置求解器（别跳过）

菜单 Modeling → Model Settings（中文：建模 → 模型设置，快捷键 `Ctrl+E`）：

| 选项（中文界面） | 设成 |
|---|---|
| 类型（Solver → Type） | 定步长（Fixed-step） |
| 求解器（Solver） | 离散（无连续状态）（discrete (no continuous states)） |
| 定步长（Fixed-step size） | 0.01 |

> 或者干脆用命令，不用翻对话框：
> ```matlab
> set_param('BMS_Manual','SolverType','Fixed-step', ...
>                        'Solver','FixedStepDiscrete', ...
>                        'FixedStep','0.01');
> ```

为什么必须 10 毫秒：固件的时间常数（250 ms 采样、100 ms 去抖、320 ms 过流延时）
都是按这个步长设计的。设成变步长会慢一个量级，而且保护时序对不上。

> 确认：点确定后，模型右下角状态栏应显示 `FixedStepDiscrete`。

---

## 二、放 4 个 MATLAB Function 块

### 2.1 放块

双击画布空白处，输入 `MATLAB Function`，回车。重复 4 次，
然后双击块名改成：

| 块名 | 位置建议（画布坐标） |
|---|---|
| `Profile` | 左中 |
| `Plant_4Group_ECM` | 中上 |
| `AFE_BQ76920` | 中下 |
| `BMS_Firmware` | 右侧 |

双击块名可以改名。名字要和后续连线对应，别改错。

### 2.2 写入代码

双击 `Profile` 块 → 打开代码编辑器 → `Ctrl+A` 全选 → `Delete` 清空 →
把 `sim/bms_profile_model.m` 的全文粘进去。

重复这个动作，把四个块都填上：

| 块 | 代码文件 |
|---|---|
| `Profile` | `sim/bms_profile_model.m` |
| `Plant_4Group_ECM` | `sim/bms_plant_model.m` |
| `AFE_BQ76920` | `sim/bms_afe_model.m` |
| `BMS_Firmware` | `sim/bms_ctrl_model.m` |

> 原样粘贴，不要改任何字符。特别是：
> - 文件第一行的 `%%#codegen` 要留着
> - 注释里的引号是中文引号，不要"顺手改成英文的"
>   （英文双引号会让 Stateflow 解析器报"解析时出错"，这个错完全看不出跟注释有关）

### 2.3 设置端口尺寸（最容易卡住的一步，务必做完）

这是整个手工搭建最关键的一步。不做的话，后面整机编译一定会报：

```
Simulink 无法确定模块 'BMS_Manual/AFE_BQ76920' 的输出大小和/或类型
```

操作：双击块打开代码编辑器，工具栏上找 Edit Data（中文：编辑数据，
一个表格样子的图标），点开会列出所有变量的表。

> 找不到的话：块编辑器里 Modeling（建模） 选项卡里也有 Edit Data（编辑数据）。

然后逐个把下面表里的变量，按 Size（大小） 和 Type（类型） 两列改好。
默认大小是 `-1`（表示"让 Simulink 自己推"），这正是推断失败的原因，必须改掉。

> 这个面板里三列的含义：
> Scope（作用域） 区分输入/输出，Size（大小） 填元素个数，
> Type（类型） 统一填 `double`。

#### 嫌手点太多次？用命令批量设（推荐）

40 多个变量的尺寸一个个点很费事。这段命令能一次把某个块的全部端口设好，
而且不受界面语言影响，不用再满界面找按钮：

```matlab
% 用法：改 setPorts('块名', {'变量名','大小', ...})，一次设完一个块
setPorts('Profile',          {'scen','1','v_pack','1','t','1', ...
                              'i_cmd','1','scen_name','1'});
setPorts('Plant_4Group_ECM', {'soc0','4','v_true','4','soc_true','4', ...
                              'age_fac','2', 'i_cmd','1'});
setPorts('AFE_BQ76920',      {'v_true','4','inj_cell','4', 'y','10'});
setPorts('BMS_Firmware',     {'v_meas','4','cmd','3', 'y','26'});
```

这个辅助函数我已经建好了：`sim/setPorts.m`（已通过语法检查）。
搭模型时直接用即可，不用自己敲。源码如下，供你了解它做了什么：

```matlab
function setPorts(blkName, pairs)
%SETPORTS  批量设置 MATLAB Function 块的端口尺寸与类型
%   setPorts('AFE_BQ76920', {'y','10','v_true','4'})
%   未在 pairs 里列出的端口，一律设为标量 double
    mdl = 'BMS_Manual';
    ch  = sfroot().find('-isa','Stateflow.EMChart','Path',[mdl '/' blkName]);
    if isempty(ch), error('找不到块: %s', blkName); end
    d = ch(1).find('-isa','Stateflow.Data');
    n = 0;
    for k = 1:numel(d)
        nm = d(k).Name; sz = '1';
        for j = 1:2:numel(pairs)
            if strcmp(pairs{j}, nm), sz = pairs{j+1}; break; end
        end
        d(k).Props.Array.Size = sz;        % 必须是字符，不能传数字
        d(k).Props.Array.IsDynamic = false;
        d(k).DataType = 'double';
        n = n + 1;
    end
    fprintf('%s: 设好 %d 个端口\n', blkName, n);
end
```

> 注意：`setPorts` 只处理"大小"，类型统一给 `double`，这正好是本项目的口径
> （`sys_stat` 也是 double，理由见下面的表）。
> 界面和命令改的是同一份数据，用命令设完，再双击块打开「编辑数据」能看到结果。
> 想全部手工点也行，下面的表就是照着填的内容。

#### `Profile` 块

| 变量 | Scope | Size | Type |
|---|---|---|---|
| `scen` | Input | `1` | `double` |
| `v_pack` | Input | `1` | `double` |
| `t` | Input | `1` | `double` |
| `i_cmd` | Output | `1` | `double` |
| `scen_name` | Output | `1` | `double` |

#### `Plant_4Group_ECM` 块

| 变量 | Scope | Size | Type |
|---|---|---|---|
| `i_cmd` | Input | `1` | `double` |
| `chg_en` | Input | `1` | `double` |
| `dsg_en` | Input | `1` | `double` |
| `bal_mask` | Input | `1` | `double` |
| `t_amb` | Input | `1` | `double` |
| `t` | Input | `1` | `double` |
| `rst` | Input | `1` | `double` |
| `soc0` | Input | `4` | `double` |
| `i_pack` | Output | `1` | `double` |
| `v_true` | Output | `4` | `double` |
| `v_pack_true` | Output | `1` | `double` |
| `t_cell` | Output | `1` | `double` |
| `soc_true` | Output | `4` | `double` |
| `p_loss` | Output | `1` | `double` |
| `age_fac` | Output | `2` | `double` |

#### `AFE_BQ76920` 块

| 变量 | Scope | Size | Type |
|---|---|---|---|
| `i_pack` | Input | `1` | `double` |
| `v_true` | Input | `4` | `double` |
| `t_cell` | Input | `1` | `double` |
| `bal_mask` | Input | `1` | `double` |
| `cc_read` | Input | `1` | `double` |
| `clr_mask` | Input | `1` | `double` |
| `inj_cell` | Input | `4` | `double` |
| `inj_ntc` | Input | `1` | `double` |
| `t` | Input | `1` | `double` |
| `rst` | Input | `1` | `double` |
| `y` | Output | `10` | `double` |

#### `BMS_Firmware` 块

| 变量 | Scope | Size | Type |
|---|---|---|---|
| `cc_raw` | Input | `1` | `double` |
| `sys_stat` | Input | `1` | `double` |
| `v_meas` | Input | `4` | `double` |
| `v_pack_meas` | Input | `1` | `double` |
| `ts1_adc` | Input | `1` | `double` |
| `cmd` | Input | `3` | `double` |
| `t` | Input | `1` | `double` |
| `rst` | Input | `1` | `double` |
| `y` | Output | `26` | `double` |

> 两个容易填错的地方：
> 1. `sys_stat` 是 `double`，不是 `uint8`。因为 AFE 块的输出被打包成向量后，
>    Demux 出来的必然是 double。这里若写 uint8，会报类型不匹配。
>    固件代码内部本来就有 `uint8(sys_stat)` 显式转换，不影响逻辑。
> 2. `Size` 填 `1`（标量），不要填 `[1 1]`。填成二维向量会报
>    「端口宽度或维度出错…是有 1 个元素的一维向量」。

### 2.4 这一步的验证

点块编辑器的 Run（或"编译"）按钮编译单个块。四个块都不该报错。

如果报「无法确定输出大小」，回去检查 2.3 的尺寸有没有漏填。

---

## 三、放 Memory 块（打断代数环）

### 3.1 为什么需要

`电流 → AFE → 固件 → MOS 门控 → 电流` 在 Simulink 里构成代数环，
直接连线会报 `Algebraic loop` 错误。

物理上 MOS 状态本来就下一拍才影响电流，所以插一个 Memory 块
（输出 = 上一拍输入）是符合物理的，不是为了消错凑的。

### 3.2 放 3 个 Memory

双击空白处搜 `Memory`，放三次，改名：

| 块名 | 作用 | 接在哪 |
|---|---|---|
| `Mem_ctl` | 延迟 MOS 状态 | 固件输出 → Plant 的 chg/dsg/bal 输入 |
| `Mem_afein` | 延迟给 AFE 的控制量 | 固件输出 → AFE 的 bal/cc_read/clr 输入 |
| `Mem_vpack` | 延迟组端电压 | Plant 输出 → Profile 输入（CC-CV 要用上一拍电压） |

---

## 四、放 Demux / Mux（拆包与合成）

因为 `AFE` 和 `BMS_Firmware` 的输出都是打包向量，必须拆开才能用。

### 4.1 放这些块

| 块名 | 类型 | 参数（中文界面：输出数目 / 输入数目） | 作用 |
|---|---|---|---|
| `Demux_afe` | Demux | `10` | 拆 AFE 的 y |
| `Mux_vmeas` | Mux | `4` | 把 v_meas 的 4 个标量合回 1×4 向量 |
| `Demux_bms` | Demux | `26` | 拆固件的 y |
| `Mux_ctl` | Mux | `3` | chg/dsg/bal 打包进 Memory |
| `Demux_ctl` | Demux | `3` | 拆开给 Plant |
| `Mux_afein` | Mux | `3` | bal/cc_read/clr 打包进 Memory |
| `Demux_afein` | Demux | `3` | 拆开给 AFE |

操作：双击 Demux（多路分解器）块，在 Number of outputs（输出数目）
里填数字（如 `10`），确定。Mux 块同理，参数是 Number of inputs（输入数目）。

> 照上表逐个设也行，或者一次设完：
> ```matlab
> set_param('BMS_Manual/Demux_afe', 'Outputs', '10');
> set_param('BMS_Manual/Demux_bms', 'Outputs', '26');
> set_param('BMS_Manual/Mux_vmeas', 'Inputs',  '4');
> set_param('BMS_Manual/Mux_ctl',   'Inputs',  '3');
> set_param('BMS_Manual/Demux_ctl', 'Outputs', '3');
> set_param('BMS_Manual/Mux_afein', 'Inputs',  '3');
> set_param('BMS_Manual/Demux_afein','Outputs','3');
> ```

> 如果只想填 `1` 个数字，就填总的端口数；想按宽度分组，可以填 `[1 3 4 1 1 1 4]`
> 这种形式。本手册为了简单统一用单数字。

### 4.2 `Mux_vmeas` 为什么必须存在

AFE 打包向量里 `y(4:7)` 是 4 个相邻标量。Demux 拆出来是 4 条独立的线，
而固件的 `v_meas` 端口要的是一个 1×4 向量。

所以必须用 `Mux`（4 输入）把 4 根线合回一根带 4 元素的线。

> 这是个很容易漏的点：漏了会报「端口宽度或维度出错」。

---

## 五、放信号源与观测块

### 5.1 工况注入（信号源）

| 块名 | 类型 | 参数 |
|---|---|---|
| `SCEN` | From Workspace（来自工作区） | 变量名称填 `SCEN`；最终值之后的输出选 保持最终值 |
| `Demux_in` | Demux | `[1 3 4 1 1 1 4]` ← 这一个必须用分组写法 |
| `t` | Clock | 默认 |

`Demux_in` 的 `[1 3 4 1 1 1 4]` 意思是把 SCEN 的 13 列拆成 7 组：
1 列 / 3 列 / 4 列 / 1 列 / 1 列 / 1 列 / 4 列。对应：

```
t | scen | chgLim | dsgLim | clr | inj1..4 | injNTC | t_amb | rst | soc0(1..4)
        ↑       └─── 3 列 ───┘   └─ 4 列 ─┘
```

### 5.2 终结器（别漏）

| 块名 | 类型 | 接什么 |
|---|---|---|
| `Term_plan` | Terminator | `Profile` 的第 2 个输出 `scen_name` |
| `Term_age` | Terminator | `Plant` 的第 7 个输出 `age_fac` |

Simulink 不允许输出端口悬空，不接会报「输出端口未连接」。
这两个输出确实没人用（一个是工况编号的日志编码，一个是老化系数），接终结器即可。

### 5.3 观测

| 块名 | 类型 | 参数 |
|---|---|---|
| `MuxPlant` | Mux | `[1 1 1 4 1 4 1]` |
| `MuxAfe` | Mux | `[4 1 1 1 1 1 1]` |
| `MuxBms` | Mux | `9` |
| `LOG_PLANT` `LOG_AFE` `LOG_BMS` | To Workspace（到工作区） | 变量名称填同名；保存格式选 带时间的结构体 |
| `Scope_V_I` | Scope | 4 个输入端口 |
| `Scope_Cells` | Scope | 4 个输入端口 |
| `Scope_SOC` | Scope | 3 个输入端口 |
| `Scope_FET` | Scope | 4 个输入端口 |

> Scope（示波器）的端口数：双击块 → 齿轮图标 → Number of input ports（输入端口数目） 改。
> 或者命令：`set_param('BMS_Manual/Scope_V_I','NumInputPorts','4');`

---

## 六、连线（60+ 条，照单点菜）

连线方法：鼠标移到输出端口（块右侧的小三角），按住拖到目标输入端口松手。

### 6.1 时间与工况注入

```
t/1              → Profile/3                  （时间）
t/1              → Plant_4Group_ECM/6
t/1              → AFE_BQ76920/9
t/1              → BMS_Firmware/7

SCEN/1           → Demux_in/1
Demux_in/1       → Profile/1                  （scen）
Demux_in/2       → BMS_Firmware/6             （cmd 3 列）
Demux_in/3       → AFE_BQ76920/7              （inj_cell 4 列）
Demux_in/4       → AFE_BQ76920/8              （inj_ntc）
Demux_in/5       → Plant_4Group_ECM/5         （t_amb）
Demux_in/6       → Plant_4Group_ECM/7         （rst）
Demux_in/6       → AFE_BQ76920/10             （rst）
Demux_in/6       → BMS_Firmware/8             （rst）
Demux_in/7       → Plant_4Group_ECM/8         （soc0 4 列）
```

> `rst` 要接三处（Plant / AFE / Firmware）。漏了会出大问题：
> MATLAB Function 块里的 `persistent` 状态跨 `sim` 不会自动清零，
> 第二个场景会接着第一个场景跑，结果全错。

### 6.2 主回路

```
Profile/1            → Plant_4Group_ECM/1     （i_cmd）
Profile/2            → Term_plan/1            （scen_name，终结）

Plant_4Group_ECM/1   → AFE_BQ76920/1          （i_pack）
Plant_4Group_ECM/2   → AFE_BQ76920/2          （v_true 4 列）
Plant_4Group_ECM/4   → AFE_BQ76920/3          （t_cell）
Plant_4Group_ECM/3   → Mem_vpack/1            （组端电压）
Mem_vpack/1          → Profile/2              （上一拍电压给 CC-CV）
Plant_4Group_ECM/7   → Term_age/1             （age_fac，终结）

AFE_BQ76920/1        → Demux_afe/1            （打包向量 y）
```

### 6.3 AFE 输出拆包 → 固件

```
Demux_afe/1   → BMS_Firmware/1                （cc_raw）
Demux_afe/3   → BMS_Firmware/2                （sys_stat）
Demux_afe/8   → BMS_Firmware/4                （v_pack_meas）
Demux_afe/9   → BMS_Firmware/5                （ts1_adc）

Demux_afe/4   → Mux_vmeas/1                   （v_meas 的 4 个标量）
Demux_afe/5   → Mux_vmeas/2
Demux_afe/6   → Mux_vmeas/3
Demux_afe/7   → Mux_vmeas/4
Mux_vmeas/1   → BMS_Firmware/3                （合回 1×4 向量）
```

### 6.4 固件输出拆包 → 回灌

```
BMS_Firmware/1 → Demux_bms/1                  （打包向量 y）

% ① MOS 状态 → Memory → Plant
Demux_bms/1    → Mux_ctl/1                    （chg_en）
Demux_bms/2    → Mux_ctl/2                    （dsg_en）
Demux_bms/3    → Mux_ctl/3                    （bal_mask）
Mux_ctl/1      → Mem_ctl/1
Mem_ctl/1      → Demux_ctl/1
Demux_ctl/1    → Plant_4Group_ECM/2           （chg_en）
Demux_ctl/2    → Plant_4Group_ECM/3           （dsg_en）
Demux_ctl/3    → Plant_4Group_ECM/4           （bal_mask）

% ② 给 AFE 的控制量 → Memory
Demux_bms/3    → Mux_afein/1                  （bal_mask）
Demux_bms/4    → Mux_afein/2                  （cc_read）
Demux_bms/5    → Mux_afein/3                  （clr_mask）
Mux_afein/1    → Mem_afein/1
Mem_afein/1    → Demux_afein/1
Demux_afein/1  → AFE_BQ76920/4                （bal_mask）
Demux_afein/2  → AFE_BQ76920/5                （cc_read）
Demux_afein/3  → AFE_BQ76920/6                （clr_mask）
```

### 6.5 日志与示波器

```
Profile/1            → MuxPlant/1
Plant_4Group_ECM/1   → MuxPlant/2
Plant_4Group_ECM/3   → MuxPlant/3
Plant_4Group_ECM/2   → MuxPlant/4             （v_true 4 列）
Plant_4Group_ECM/4   → MuxPlant/5
Plant_4Group_ECM/5   → MuxPlant/6             （soc_true 4 列）
Plant_4Group_ECM/6   → MuxPlant/7
MuxPlant/1           → LOG_PLANT/1

Mux_vmeas/1          → MuxAfe/1               （v_meas 4 列）
Demux_afe/8          → MuxAfe/2
Demux_afe/1          → MuxAfe/3
Demux_afe/2          → MuxAfe/4
Demux_afe/3          → MuxAfe/5
Demux_afe/9          → MuxAfe/6
Demux_afe/10         → MuxAfe/7
MuxAfe/1             → LOG_AFE/1

Demux_bms/1   → MuxBms/1
Demux_bms/2   → MuxBms/2
Demux_bms/3   → MuxBms/3
Demux_bms/6   → MuxBms/4                      （soc）
Demux_bms/7   → MuxBms/5                      （remain）
Demux_bms/8   → MuxBms/6                      （cap）
Demux_bms/9   → MuxBms/7                      （fault）
Demux_bms/10  → MuxBms/8                      （led）
Demux_bms/11  → MuxBms/9                      （temp）
MuxBms/1      → LOG_BMS/1

（示波器，可选，手搭时先不接也行）
Plant_4Group_ECM/1 → Scope_V_I/1
Plant_4Group_ECM/3 → Scope_V_I/2
Mux_vmeas/1        → Scope_V_I/3
Demux_afe/8        → Scope_V_I/4
```

> 注意 一根线可以分叉接多处（比如 `Mux_vmeas/1` 同时给 `BMS_Firmware/3`、`MuxAfe/1`、`Scope_V_I/3`）。
> 直接从已有的线上拖一条分支出来即可。

---

## 七、准备 SCEN 工况数据

在 MATLAB 命令行里造一个矩阵（必须叫 `SCEN`，且在工作区 `base` 里）：

```matlab
dt = 0.05; tt = (0:dt:60)'; n = numel(tt);
rst = zeros(n,1); rst(1:2) = 1;          % 头两拍给复位脉冲

SCEN = [tt, ...                           % 1  时间
        4*ones(n,1), ...                  % 2  工况编号（4 = 过流放电 60A）
        30*ones(n,1), ...                 % 3  chgLim
        50*ones(n,1), ...                 % 4  dsgLim
        zeros(n,1), ...                   % 5  clr
        zeros(n,4), ...                   % 6-9  inj_cell(1..4)
        zeros(n,1), ...                   % 10 injNTC
        25*ones(n,1), ...                 % 11 t_amb
        rst, ...                          % 12 rst   
        repmat([60 60 57 60],n,1)];       % 13-16 soc0(1..4)
```

每列的含义（顺序不能错）：

| 列 | 含义 | 常用值 |
|---|---|---|
| 1 | 时间 s | 0:0.05:60 |
| 2 | 工况编号 | 1 静置、2 放电 1C、3 充电、4 过流放电、5 过流充电、6 循环、7 短路、8 低温、9 高温 |
| 3-4 | chgLim / dsgLim | 30 / 50 |
| 5 | 清故障脉冲 | 0 |
| 6-9 | 单体故障注入 | 0 正常、3 采样线开路、4 接反 |
| 10 | NTC 注入 | 0 正常、5 短路、6 开路 |
| 11 | 环境温度 ℃ | 25 |
| 12 | rst | 头两拍 1，其余 0 |
| 13-16 | 各节初始 SOC % | [60 60 57 60] |

---

## 八、跑起来

```matlab
set_param('BMS_Manual','StopTime','60');   % 跑 60 秒
out = sim('BMS_Manual');
```

如果想先只编译不跑（诊断利器，几秒出结果）：

```matlab
set_param('BMS_Manual','SimulationCommand','update');
```

### 看结果

```matlab
% 从 LOG_BMS 里取数据（列序见第五节 MuxBms 的接法）
B = out.LOG_BMS.signals.values;
figure;
subplot(3,1,1); plot(out.tout, B(:,4)); grid on; ylabel('SOC %');
subplot(3,1,2); plot(out.tout, B(:,1), out.tout, B(:,2)); grid on;
                legend('CHG','DSG'); ylabel('MOS');
subplot(3,1,3); plot(out.tout, B(:,7)); grid on; ylabel('故障码');
```

或者双击 `Scope_V_I` 等示波器直接看波形。

---

## 九、搭完的自检清单

对照着逐条确认，任何一条不过都会导致编译报错：

- [ ] 求解器是 Fixed-step / discrete / 0.01
- [ ] 4 个 MATLAB Function 块都填了代码
- [ ] 40+ 个端口尺寸都显式填了（`-1` 要全部改掉）最容易漏
- [ ] `BMS_Firmware` 的 `sys_stat` 类型是 `double`
- [ ] `AFE_BQ76920` 的 `y` 尺寸是 `10`，`BMS_Firmware` 的 `y` 是 `26`
- [ ] 3 个 Memory 都在（`Mem_ctl` / `Mem_afein` / `Mem_vpack`）
- [ ] `Mux_vmeas` 把 4 个 v_meas 标量合成了向量
- [ ] `Term_plan` / `Term_age` 接住了两个不用的输出
- [ ] `rst` 接到了 Plant / AFE / Firmware 三处
- [ ] 工作区里有 `SCEN` 变量，12 列顺序正确，头部有 rst 脉冲

---

## 十、常见报错对照表

| 报错 | 原因 | 怎么修 |
|---|---|---|
| `Simulink 无法确定模块的输出大小和/或类型` | 端口 Size 还是 `-1` | 回 2.3 逐个填尺寸 |
| `端口宽度或维度出错…是有 1 个元素的一维向量` | Size 填成了 `[1 1]` | 改成 `1` |
| `输出端口未连接` | 有输出没人接 | 接 Terminator（`scen_name` / `age_fac`） |
| `Algebraic loop` | 忘了 Memory | 补 3 个 Memory |
| `解析时出错` | 代码注释里有 ASCII 双引号 | 换中文引号 |
| 类型不匹配 | `sys_stat` 写成 uint8 | 改成 `double` |
| 第二个场景接着第一个跑 | `rst` 没接 | 把 `Demux_in/6` 接到三个块的 rst |
| `new_system` 报错 | 模型名含中文 | 换纯英文名 |
| 仿真慢得离谱 | 求解器是变步长 | 改 Fixed-step discrete |
| 编译卡很久 | 用 `find_system` 遍历库 | 手工搭不涉及；脚本里要避免 |

---

## 十一、手工搭 vs 脚本搭

搭完这一遍，你就理解脚本 `build_bms_model.m` 在干什么了，
它就是把上面的手工操作逐条写成了代码。

| | 手工 | 脚本 |
|---|---|---|
| 耗时 | 1~2 小时 | 一条命令 |
| 适合 | 第一次理解结构、临时改结构做实验 | 重复重建、版本管理 |
| 改一个阈值 | 双击块改 | 改 `.m` 重跑 |

建议的工作方式：
1. 手工搭一遍（就现在这次）：建立直观理解
2. 之后想改结构，先在手工模型上试
3. 定型了，同步改到 `build_bms_model.m`，用脚本重建
4. 日常测固件逻辑，直接用 `quickstart`（纯 MATLAB 路线，快一个量级）

---

## 十二、搭不通怎么办

按这个顺序排查，能快速定位问题范围：

```matlab
% ① 先直接调用函数（排除"代码写错了"）
y = bms_afe_model(-30,[3218 3218 3216 3218],25,0,0,0,[0 0 0 0],0,0.01,1);
disp(y)        % 应该输出 10 个合理数值

% ② 再只编译不仿真（定位块的问题）
set_param('BMS_Manual','SimulationCommand','update');

% ③ 看每个端口被推断成什么（尺寸/类型不对时最直观）
chs = sfroot().find('-isa','Stateflow.EMChart','Path','BMS_Manual/AFE_BQ76920');
for d = chs(1).find('-isa','Stateflow.Data')'
    fprintf('%-14s size=%-6s type=%s\n', d.Name, d.Props.Array.Size, d.DataType);
end
```

第 ③ 步的输出应该和 2.3 的表完全一致。不一致就改回去。

还搞不定的话，直接跟我要，我这边有能跑的模型，可以逐块对照差异。
