# 01 固件代码（C 语言）

**目标平台**：STM32F103C8T6 + HAL 库，Keil5 编译
**AFE**：TI BQ76920（BQ7692003PWR），I²C 接口
**代码量**：13 个 `.h` + 12 个 `.c`

---

## 一、接入步骤（摘要）

完整步骤见同目录 **`固件接入与配置说明.md`**（含 CubeMX 每个外设怎么配、引脚表、时钟树）。

```
1) STM32CubeMX 新建工程，芯片选 STM32F103C8Tx
2) 配外设：I2C1(400k) / USART1(115200) / CAN1(Remap PB8/PB9, 500k) / IWDG(2.0s)
3) 配 GPIO：LED1~5 + ALERT(PA1 EXTI 上升沿)
4) 把 Core/Inc/*.h 与 Core/Src/*.c 拷进工程同名目录
5) Keil 里把这 12 个 .c 加入 Application/User/Core 分组
6) main.c 里插 BMS_Init() 和 while(1){ BMS_Loop(); }
```

---

## 二、文件清单

### 头文件 `Core/Inc/`

| 文件 | 说明 |
|---|---|
| `bms_config.h` | ★ **唯一的配置入口**（阈值、电流限值、引脚、容量） |
| `bq76920.h` | AFE 寄存器定义与 API |
| `bms_soc.h` | 电量估算接口（三级可信度 `Soc_State_t` + 上电 EEPROM/OCV 恢复） |
| `bms_cells.h` | ★ 单体电压检测接口 |
| `bms_temp.h` | ★ 温度检测接口 |
| `bms_protect.h` | 保护与限流接口 |
| `bms_balance.h` | 均衡接口 |
| `bms_storage.h` | ★ AT24C02 参数掉电保存 |
| `bms_can.h` | ★ CAN 通信（兼容厂家上位机协议） |
| `bms_led.h` | LED 电量条接口 |
| `bms_wdg.h` | ★ 看门狗 |
| `bms_debug.h` | 串口日志接口 |
| `bms_app.h` | 顶层初始化 / 主循环接口 |

### 源文件 `Core/Src/`

| 文件 | 说明 |
|---|---|
| `bq76920.c` | I²C 读写、电压/温度/电流换算、保护寄存器配置、FET 与均衡控制 |
| `bms_soc.c` | 库仑计积分 + OCV 静置修正 + 满充满放学习容量 + **EEPROM 掉电记忆恢复（主路径）/ 上电快速 OCV 对齐（辅助）**；`Soc_Init()` 不再写 50% 占位 |
| `bms_cells.c` | ★ 单体电压检测：滤波/校验/两级判定/压差/开路自检 |
| `bms_temp.c` | ★ 温度检测：NTC 换算/传感器诊断/分区限值 |
| `bms_protect.c` | 过压/欠压/过流/过温 + 自动恢复重试 + 锁定 |
| `bms_balance.c` | 均衡策略 + 测量窗口相位控制（Bal_Task） |
| `bms_storage.c` | ★ AT24C02 读写 + CRC16 校验 + 参数结构体 |
| `bms_can.c` | ★ 7 帧上传 + 下行控制命令 |
| `bms_wdg.c` | ★ IWDG 喂狗与健康判定 |
| `bms_led.c` | 5 灯电量条 + 非阻塞闪烁 |
| `bms_debug.c` | 状态打印（不依赖 printf 重定向） |
| `bms_app.c` | 10ms/250ms/1s/5s 调度 + 串口命令行 |

---

## 三、任务调度表

```
每 10ms : SYS_STAT → CC_READY? → 读 CC（读走即复位）→ SOC 积分 → 上报传感器健康标志
          → 保护评估 → LED 动画 → 均衡相位控制（开 5s / 停 900ms 测量窗口）
每 250ms: 读 VC1..VC5（一次 10 字节保证同帧）→ 映射成 4 节真值
          → Cells_Update（滤波/总和校验/逐节两级/压差）→ 满充/放空/静置判定
每 1s   : Temp_Update（TS1→NTC 阻值→开路短路诊断→跳变剔除→滑动平均→分区）
每 5s   : 均衡策略重算
每 20ms : CAN 收发 + 看门狗喂狗（通信健康才喂）
每 1s   : 若 MON 打开，往串口推一帧 $BMS 数据
```

---

## 四、★ 上板前必须改的参数（`bms_config.h`）

| 宏 | 默认值 | 说明 |
|---|---|---|
| `BMS_CAPACITY_AH` | 10.0 | **电池真实容量**，SOC 的分母，必须改（本项目 2P4S = 30.0） |
| `BMS_CELL_OV_MV` / `UV_MV` | 3650 / 2500 | LiFePO4 4S（三元 4S 改 4200 / 2800） |
| `BMS_DISCHARGE_MAX_A` | 50.0 | 最大放电电流 |
| `BMS_CHARGE_MAX_A` | 20.0 | 最大充电电流 |
| `BMS_OCD_THRESH_CODE` | 0x06 | 硬件放电过流阈值，**要与上一条对齐** |
| `BMS_RSENSE_MOHM` | 1.0 | 与 R17 一致 |
| `BMS_NTC_B` | 3435 | 按 CN3 上实际 NTC 的 B 值改 |

电流阈值改后 OCD 只能取离散值（@1mΩ，A）：
`17 / 22 / 28 / 33 / 39 / 44 / 50 / 56 / 61 / 67 / 72 / 78 / 83 / 89 / 94 / 100`

---

## 五、串口命令（115200 8N1）

| 命令 | 作用 |
|---|---|
| `?` | 打印完整状态 |
| `SET CHG 15` / `SET DSG 40` | 改充/放电限值（立即生效，掉电丢失） |
| `CAP 30` | 设置电池容量 |
| `CELL` / `TEMP` / `CELLDIAG` | 单体电压详情 / 温度详情 / 采样线开路自检 |
| `MON 1` / `MON 0` | 开关 1Hz 机器可读数据推送 |
| `PARAM` / `SAVE` | 打印 / 保存掉电参数 |
| `CLR` | 清除故障并解除过流锁定 |
| `SHIP` | 进入低功耗模式 |

---

## 六、数据帧格式（配合 `02_仿真模型_MATLAB/上位机工具/soc_monitor.py`）

```
$BMS,时间ms,组端mV,节1,节2,节3,节4,电流mA,温度C,SOC×10,剩余mAh,容量mAh,CHG,DSG,均衡,故障*XOR
$BMS,123456,12840,3210,3205,3212,3213,-1520,25,785,7846,10000,1,1,0,0*3F
```

- 电流**充电为正、放电为负**；SOC 放大 10 倍、容量放大 1000 倍，全整数发送
- 末尾 `*XX` 是异或校验（`$` 与 `*` 之间逐字节异或）
