/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_wdg.c
 * 描述    ：看门狗实现：通信异常时不喂狗 → MCU 复位 → 重新初始化 AFE 自恢复
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 无（芯片内部 IWDG）
 * 参考手册: STM32F10x 参考手册
 * 超时计算: IWDG 时钟 40kHz，预分频 64、重装 1250 → 64×1250/40000 = 2.0s
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_wdg.h"
#include "bms_debug.h"

#define WDG_PRESCALER   IWDG_PRESCALER_64U
#define WDG_RELOAD      1250U          /* 64 × 1250 / 40000Hz = 2.0s */
#define WDG_MAX_FAIL    20U            /* 连续通信失败上限（10ms×20 = 200ms） */

static IWDG_HandleTypeDef s_iwdg;
static uint8_t s_fail = 0U;
static bool    s_inited = false;
 /**
  * @file   Bms_WdgInit
  * @brief  看门狗初始化：IWDG 预分频 64、重装 1250 → 超时 2.0s
  * @param  无
  * @retval 无
  */
void Bms_WdgInit(void)
{
    s_iwdg.Instance = IWDG;
    s_iwdg.Init.Prescaler = WDG_PRESCALER;
    s_iwdg.Init.Reload = WDG_RELOAD;
    if (HAL_IWDG_Init(&s_iwdg) != HAL_OK) {
        /* 初始化失败也不阻塞业务，只是没有看门狗保护 */
        BMS_Log("[WDG] IWDG 初始化失败\r\n");
        return;
    }
    s_inited = true;
}
 /**
  * @file   Bms_WdgReportI2c
  * @brief  上报一次 AFE 通信结果（成功清零失败计数，失败累加）
  * @param  ok true=本次通信成功
  * @retval 无
  */
void Bms_WdgReportI2c(bool ok)
{
    if (ok) {
        s_fail = 0U;
    } else if (s_fail < 255U) {
        s_fail++;
    }
}
 /**
  * @file   Bms_WdgGetFailCount
  * @brief  取连续通信失败次数
  * @param  无
  * @retval 失败次数
  */
uint8_t Bms_WdgGetFailCount(void) { return s_fail; }
 /**
  * @file   Bms_WdgFeed
  * @brief  喂狗。「注意：连续通信失败超过阈值时故意不喂」，让 MCU 复位后重新初始化 AFE，
  *         实现自恢复；AFE 的硬件保护在复位期间照常工作
  * @param  无
  * @retval 无
  */
void Bms_WdgFeed(void)
{
    if (!s_inited) {
        return;
    }
    if (s_fail > WDG_MAX_FAIL) {
        /* 故意不喂狗：让 MCU 复位并重新初始化 AFE，实现自恢复 */
        return;
    }
    HAL_IWDG_Refresh(&s_iwdg);
}
