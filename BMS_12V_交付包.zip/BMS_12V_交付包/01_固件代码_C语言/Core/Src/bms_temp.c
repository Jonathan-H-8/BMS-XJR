/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_temp.c
 * 描述    ：温度检测实现：TS1 采集 → NTC 阻值换算 → 开路/短路/超范围诊断 →
 *           跳变剔除（按键干扰）→ 滑动平均 → 温度分区（决定允许充放电）
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: CN3 外接 NTC(10k@25℃,B=3435)：一端接 U9.TS1、一端接 GND；
 *           TS1 引脚内部 10k 上拉到约 3.3V，所以 V(TS1) 越小代表温度越高
 *           换算：R(NTC) = 10k × V / (3.3V − V)，V = ADC × 382µV
 *           温度：1/T = 1/T0 + ln(R/R0)/B   （T0 = 298.15K）
 * 参考手册: TI SLUSBK2I（TS1 = 0x2C；SYS_CTRL1.TEMP_SEL 选择外部 NTC / 内部温度）
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_temp.h"
#include "bq76920.h"
#include "bms_debug.h"
#include <math.h>

Temp_Info_t g_temp;

/* 滑动平均缓冲 */
static int8_t   s_buf[BMS_TEMP_FILTER_N];
static uint8_t  s_idx;
static uint8_t  s_cnt;
static int8_t   s_last_c;          /* 最近一次可信温度（用于跳变比较与故障兜底） */
static uint8_t  s_reject_run;      /* 连续被丢弃的次数 */
static uint32_t s_boot_ms;         /* 模块初始化时刻（用于开机宽限） */

 /**
  * @file   temp_bq2sens
  * @brief  （内部函数）把驱动层 TS1 状态码翻译成本模块的传感器状态
  * @param  st 驱动层状态（BQ_TS_xxx）
  * @retval 传感器状态
  */
static Temp_Sens_t temp_bq2sens(uint8_t st)
{
    switch (st) {
    case BQ_TS_OK:    return TEMP_SENS_OK;
    case BQ_TS_OPEN:  return TEMP_SENS_OPEN;
    case BQ_TS_SHORT: return TEMP_SENS_SHORT;
    case BQ_TS_RANGE: return TEMP_SENS_RANGE;
    default:          return TEMP_SENS_STALE;
    }
}
 /**
  * @file   temp_zone_eval
  * @brief  （内部函数）按温度算分区，带 2℃ 回差：
  *         上一次不在正常区时，要回到更保守的值才重新放行，避免在阈值上下反复跳
  * @param  t 当前温度 ℃; prev 上一次的分区
  * @retval 温度分区
  */
static Temp_Zone_t temp_zone_eval(int8_t t, Temp_Zone_t prev)
{
    int8_t hyst = (prev == TEMP_ZONE_NORMAL) ? 0 : 2;

    if (t < (int8_t)(BMS_TEMP_DSG_MIN - hyst)) { return TEMP_ZONE_CRIT_LOW; }
    if (t < (int8_t)(BMS_TEMP_CHG_MIN - hyst)) { return TEMP_ZONE_LOW; }
    if (t >= (int8_t)(BMS_TEMP_DSG_MAX + hyst)) { return TEMP_ZONE_HIGH_BOTH; }
    if (t >= (int8_t)(BMS_TEMP_CHG_MAX + hyst)) { return TEMP_ZONE_HIGH_CHG; }
    return TEMP_ZONE_NORMAL;
}
 /**
  * @file   Temp_Init
  * @brief  温度模块初始化：
  *         1) 清空滑动平均缓冲与连续丢弃计数；
  *         2) 初始分区取「正常」，但 valid=false —— 上电第一次读数出来之前，
  *            保护模块不应拿一个未采样的温度做判据
  * @param  无
  * @retval 无
  */
void Temp_Init(void)
{
    uint8_t i;

    for (i = 0U; i < BMS_TEMP_FILTER_N; i++) {
        s_buf[i] = 0;
    }
    s_idx = 0U;
    s_cnt = 0U;
    s_last_c = 25;                  /* 兜底值：传感器一直没读出来时用它，避免 0℃ 误判 */
    s_reject_run = 0U;
    s_boot_ms = HAL_GetTick();

    g_temp.cell_c = 25;
    g_temp.raw_c = 25;
    g_temp.ntc_ohm = BMS_NTC_R0_OHM;
    g_temp.ts1_adc = 0;
    g_temp.ts1_mv = 0U;
    g_temp.sens = TEMP_SENS_OK;
    g_temp.zone = TEMP_ZONE_NORMAL;
    g_temp.valid = false;
    g_temp.die_c = 0;
    g_temp.die_valid = false;
    g_temp.samples = 0U;
    g_temp.rejects = 0U;
    g_temp.key_mask = false;
}
 /**
  * @file   Temp_Update
  * @brief  温度检测主函数（App 每 1s 调用一次）：
  *         1) 读 TS1 → 电压 → NTC 阻值，同时得到开路/短路/超范围诊断结果；
  *         2) 开路/短路等硬故障：直接判 sensor fault（不把 3.3V 读成 -40℃ 那种假温度
  *            当真实温度用），valid=false，分区置 FAULT；
  *         3) 跳变剔除：与上次可信值相差超过 BMS_TEMP_RATE_MAX ℃ 的样本判为干扰
  *            （本板 TS1 兼作 SHIP 唤醒键，按键期间电压被抬高，读数会瞬间跳到极低温）；
  *         4) 连续丢弃达到 BMS_TEMP_REJECT_MAX 次 → 判传感器不稳定；
  *         5) 正常样本进滑动平均，更新温度与分区
  * @param  无
  * @retval 无（结果写入 g_temp）
  */
void Temp_Update(void)
{
    int16_t  adc = 0;
    float    volt = 0.0f;
    float    r = 0.0f;
    uint8_t  st = 0U;
    int8_t   t;
    int32_t  sum = 0;
    uint8_t  i;

    g_temp.samples++;
    g_temp.key_mask = false;

    /* 1) 采 TS1 */
    if (BQ_ReadTs1(&adc, &volt, &r, &st) != HAL_OK) {
        g_temp.sens = TEMP_SENS_STALE;
        g_temp.valid = false;
        g_temp.zone = TEMP_ZONE_FAULT;
        return;
    }
    g_temp.ts1_adc = adc;
    g_temp.ts1_mv = (uint16_t)(volt * 1000.0f);
    g_temp.ntc_ohm = r;

    /* 2) 硬故障：开路 / 短路 / 阻值超范围 */
    if (st != BQ_TS_OK) {
        if (g_temp.valid) {
            /* 已经有过可信读数 → 保留旧温度值供显示，但标记不可信 */
            g_temp.cell_c = s_last_c;
        }
        g_temp.sens = temp_bq2sens(st);
        g_temp.valid = false;
        g_temp.zone = TEMP_ZONE_FAULT;
        g_temp.rejects++;
        BMS_Log("[TEMP] 传感器异常：%s (R=%.0f Ω, V=%u mV)\r\n",
                Temp_SensName(g_temp.sens), r, g_temp.ts1_mv);
        return;
    }

    /* 3) 换算温度 */
    t = BQ_TempFromNtcR(r);

    /* 4) 跳变剔除：多半是按压 SHIP 唤醒键（TS1 被 KEY1+D3+R7 抬高） */
    if (g_temp.valid && ((t - s_last_c) > BMS_TEMP_RATE_MAX || (s_last_c - t) > BMS_TEMP_RATE_MAX)) {
        s_reject_run++;
        g_temp.key_mask = true;
        g_temp.rejects++;
        if (s_reject_run >= BMS_TEMP_REJECT_MAX) {
            g_temp.sens = TEMP_SENS_UNSTABLE;
            g_temp.valid = false;
            g_temp.zone = TEMP_ZONE_FAULT;
            BMS_Log("[TEMP] 读数连续跳变 %u 次，判为不可信（按 SHIP 键或接触不良？）\r\n",
                    (unsigned)s_reject_run);
        }
        return;                     /* 丢弃这一个样本 */
    }

    /* 5) 正常样本：滑动平均 */
    s_reject_run = 0U;
    g_temp.raw_c = t;
    s_last_c = t;

    s_buf[s_idx] = t;
    s_idx = (uint8_t)((s_idx + 1U) % BMS_TEMP_FILTER_N);
    if (s_cnt < BMS_TEMP_FILTER_N) {
        s_cnt++;
    }
    for (i = 0U; i < s_cnt; i++) {
        sum += s_buf[i];
    }
    g_temp.cell_c = (int8_t)(sum / (int32_t)s_cnt);

    g_temp.valid = true;
    g_temp.sens = TEMP_SENS_OK;
    g_temp.zone = temp_zone_eval(g_temp.cell_c, g_temp.zone);
}
 /**
  * @file   Temp_Valid
  * @brief  温度是否可信
  * @param  无
  * @retval true = 可信（可作为保护判据）
  */
bool Temp_Valid(void)
{
    return g_temp.valid;
}
 /**
  * @file   Temp_GetCellC
  * @brief  取电芯温度
  * @param  无
  * @retval 温度 ℃（不可信时返回最近一次可信值）
  */
int8_t Temp_GetCellC(void)
{
    return g_temp.valid ? g_temp.cell_c : s_last_c;
}
 /**
  * @file   Temp_GetWorstC
  * @brief  取用于保护的「最保守」温度。
  *         当前硬件只有一路 NTC（CN3），所以等价于 GetCellC；
  *         以后如果加第二路 NTC（如 BQ76930/40 的 TS2），在这里取更危险的那一路即可。
  * @param  无
  * @retval 温度 ℃
  */
int8_t Temp_GetWorstC(void)
{
    return Temp_GetCellC();
}
 /**
  * @file   Temp_GetZone
  * @brief  取当前温度分区
  * @param  无
  * @retval 温度分区
  */
Temp_Zone_t Temp_GetZone(void)
{
    return g_temp.zone;
}
 /**
  * @file   Temp_ChgAllowed
  * @brief  按温度分区判断是否允许充电：
  *         只有 NORMAL 区允许；低温禁充（析锂）、高温禁充、传感器故障按 fail-safe 处理
  * @param  无
  * @retval true = 允许充电
  */
bool Temp_ChgAllowed(void)
{
    if (g_temp.zone == TEMP_ZONE_FAULT) {
        return (BMS_TEMP_SENSOR_FAILSAFE == 0U);
    }
    return (g_temp.zone == TEMP_ZONE_NORMAL);
}
 /**
  * @file   Temp_DsgAllowed
  * @brief  按温度分区判断是否允许放电：低温区允许放电（只是容量下降），
  *         高温 45~60℃ 允许放电并告警，过温与极低温禁止放电
  * @param  无
  * @retval true = 允许放电
  */
bool Temp_DsgAllowed(void)
{
    if (g_temp.zone == TEMP_ZONE_FAULT) {
        return (BMS_TEMP_SENSOR_FAILSAFE == 0U);
    }
    return (g_temp.zone == TEMP_ZONE_NORMAL
            || g_temp.zone == TEMP_ZONE_LOW
            || g_temp.zone == TEMP_ZONE_HIGH_CHG);
}
 /**
  * @file   Temp_SensorFault
  * @brief  温度传感器是否存在故障（供保护模块决定是否闭锁充放电）
  * @param  无
  * @retval true = 故障
  */
bool Temp_SensorFault(void)
{
    /* 开机宽限：初始化后 3s 内第一次采样还没完成，这时不能判故障，
     * 否则上电瞬间就会把充放电全锁掉（第一次 Temp_Update 要等 1s） */
    if ((HAL_GetTick() - s_boot_ms) < BMS_TEMP_BOOT_GRACE_MS) {
        return false;
    }
    return (g_temp.zone == TEMP_ZONE_FAULT) || (!g_temp.valid);
}
 /**
  * @file   Temp_SensName
  * @brief  传感器状态码 → 字符串（打印用）
  * @param  s 状态码
  * @retval 字符串
  */
const char *Temp_SensName(Temp_Sens_t s)
{
    switch (s) {
    case TEMP_SENS_OK:       return "OK";
    case TEMP_SENS_OPEN:     return "OPEN(NTC 开路/未接)";
    case TEMP_SENS_SHORT:    return "SHORT(NTC 短路到地)";
    case TEMP_SENS_RANGE:    return "RANGE(阻值超出合理范围)";
    case TEMP_SENS_UNSTABLE: return "UNSTABLE(读数连续跳变)";
    case TEMP_SENS_STALE:    return "STALE(I2C 读取失败)";
    default:                 return "UNKNOWN";
    }
}
 /**
  * @file   Temp_ZoneName
  * @brief  温度分区 → 字符串（打印用）
  * @param  z 分区
  * @retval 字符串
  */
const char *Temp_ZoneName(Temp_Zone_t z)
{
    switch (z) {
    case TEMP_ZONE_NORMAL:    return "NORMAL(可充可放)";
    case TEMP_ZONE_LOW:       return "LOW(禁充)";
    case TEMP_ZONE_CRIT_LOW:  return "CRIT_LOW(禁充放)";
    case TEMP_ZONE_HIGH_CHG:  return "HIGH(禁充/可放)";
    case TEMP_ZONE_HIGH_BOTH: return "OVER_TEMP(禁充放)";
    case TEMP_ZONE_FAULT:     return "SENSOR_FAULT(传感器故障)";
    default:                  return "?";
    }
}
 /**
  * @file   Temp_Print
  * @brief  打印一页温度检测结果：TS1 原始码与电压、NTC 阻值、原始温度、滤波温度、
  *         分区、允许状态、传感器状态、阈值与丢弃统计
  * @param  无
  * @retval 无
  */
void Temp_Print(void)
{
    BMS_Log("\r\n===== 温度检测 =====\r\n");
    BMS_Log("TS1      : adc=%d  V=%u mV  R(NTC)=%.0f Ω\r\n",
            g_temp.ts1_adc, g_temp.ts1_mv, g_temp.ntc_ohm);
    BMS_Log("温度     : %d C  (原始 %d C，%u 点滑动平均)\r\n",
            g_temp.cell_c, g_temp.raw_c, (unsigned)s_cnt);
    BMS_Log("分区     : %s\r\n", Temp_ZoneName(g_temp.zone));
    BMS_Log("允许     : CHG=%s  DSG=%s\r\n",
            Temp_ChgAllowed() ? "是" : "否", Temp_DsgAllowed() ? "是" : "否");
    BMS_Log("传感器   : %s   valid=%d  %s\r\n",
            Temp_SensName(g_temp.sens), (int)g_temp.valid,
            g_temp.key_mask ? "（本次样本被当作干扰丢弃）" : "");
    if (g_temp.die_valid) {
        BMS_Log("芯片温度 : %d C（仅参考，非电芯温度）\r\n", g_temp.die_c);
    }
    BMS_Log("阈值     : 禁充 <%d / >=%d C   禁放 <%d / >=%d C   高温告警 >=%d C\r\n",
            BMS_TEMP_CHG_MIN, BMS_TEMP_CHG_MAX,
            BMS_TEMP_DSG_MIN, BMS_TEMP_DSG_MAX, BMS_TEMP_OT_HIGH);
    BMS_Log("NTC 参数 : R0=%.0f Ω  B=%.0f  上拉=%.0f Ω  VREF=%.1f V\r\n",
            BMS_NTC_R0_OHM, BMS_NTC_B, BMS_NTC_PULLUP_OHM, BMS_NTC_VREF);
    BMS_Log("统计     : 采样 %lu 次，丢弃 %lu 次\r\n",
            (unsigned long)g_temp.samples, (unsigned long)g_temp.rejects);
    BMS_Log("====================\r\n");
}
 /**
  * @file   Temp_ReadDie
  * @brief  读一次芯片内部温度（TEMP DIE 命令调用）：
  *         0x2C(TS1) 是「外部 NTC」与「内部温度传感器」共用的 ADC 通道，
  *         由 SYS_CTRL1.TEMP_SEL 选择。本板 TEMP_SEL=1（用外部 NTC），
  *         所以必须临时切到内部传感器、等一个 ADC 转换周期、读完再切回来。
  *         用途只是看板级温升趋势，不能代替电芯温度做保护判据。
  * @param  无
  * @retval 无
  */
void Temp_ReadDie(void)
{
    BMS_Log("[TEMP] 正在读取芯片内部温度（切换 TS1 通道，约 %u ms）...\r\n",
            BMS_TEMP_DIE_SETTLE_MS);

    g_temp.die_c = BQ_ReadDieTempOnce();
    g_temp.die_valid = true;

    BMS_Log("[TEMP] 芯片内部温度 = %d C（仅供看板级温升，不用于保护）\r\n", g_temp.die_c);
}
