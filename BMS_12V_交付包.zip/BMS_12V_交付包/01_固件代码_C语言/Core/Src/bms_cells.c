/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_cells.c
 * 描述    ：单体电压检测实现：中值滤波 → 合理性检查 → 逐节过压/欠压两级判定 →
 *           总和校验（Σ单节 vs 组端）→ 压差统计 → 采样线开路自检
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 电芯抽头 → R22~R25(1kΩ) → U9.VC1..VC5；各脚对 AGND 挂 C12~C15(100nF)
 *           4S 映射：电芯1/2/3/4 → AFE 槽 1/2/3/5（VC4-VC3 短接，第 4 槽是空槽）
 * 参考手册: TI SLUSBK2I（VC1..VC5 = 0x0C~0x15；BAT = 0x2A）
 * 重要说明: AFE 内部均衡电流会流过 R22~R25 采样电阻，被均衡那一节的 AFE 读数
 *           会被压低（不是电芯真的掉了电压）。因此本模块：
 *           1) 被均衡的电芯不参与判定/统计，沿用上次可信值（最多 30s）；
 *           2) 均衡掩码变化后 300ms 内的读数一律不用（AFE 250ms 才更新一次）；
 *           3) 有均衡在动作时不做总和校验（否则会误报采样异常）；
 *           4) 配合 bms_balance.c 的「测量窗口」周期性地关掉均衡拿准确读数。
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_cells.h"
#include "bq76920.h"
#include "bms_balance.h"
#include "bms_protect.h"
#include "bms_debug.h"
#include "bms_wdg.h"
#include <math.h>

Cells_Info_t g_cells;
bool         g_cells_diag_active = false;

/* 电芯编号 → AFE 槽位编号（0 = VC1 ... 4 = VC5），与本板 4S 接法一致 */
static const uint8_t s_slot[BMS_CELL_COUNT] = {
    BMS_CELL_SLOT_0, BMS_CELL_SLOT_1, BMS_CELL_SLOT_2, BMS_CELL_SLOT_3
};

/* ---------------- 中值滤波历史（每节 3 个点，[0] 最新） ---------------- */
static uint16_t s_hist[3][BMS_CELL_COUNT];
static uint8_t  s_hist_n[BMS_CELL_COUNT];

/* ---------------- 去抖计数与锁存状态 ---------------- */
static uint8_t s_trip_hi_cnt[BMS_CELL_COUNT];   /* 过压越限计数 */
static uint8_t s_trip_lo_cnt[BMS_CELL_COUNT];   /* 欠压越限计数 */
static uint8_t s_warn_hi_cnt[BMS_CELL_COUNT];   /* 过压预警计数 */
static uint8_t s_warn_lo_cnt[BMS_CELL_COUNT];   /* 欠压预警计数 */
static bool    s_ov_state[BMS_CELL_COUNT];      /* 过压越限已成立（带回差解除） */
static bool    s_uv_state[BMS_CELL_COUNT];      /* 欠压越限已成立 */

/* ---------------- 均衡干扰屏蔽 ---------------- */
static uint16_t s_hold_mv[BMS_CELL_COUNT];      /* 上次可信读数（被均衡期间沿用） */
static uint32_t s_hold_ms[BMS_CELL_COUNT];      /* 已沿用时长 */
static uint8_t  s_applied_prev;                 /* 上一次看到的均衡掩码 */
static uint8_t  s_untrust_mask;                 /* 当前不可信的 AFE 槽位掩码 */
static uint32_t s_untrust_until_ms;             /* 屏蔽窗口结束时刻 */

/* ---------------- 统计与计时 ---------------- */
static uint32_t s_sum_bad_cnt;                  /* Σ 校验连续不符次数 */
static uint32_t s_unbal_ms;                     /* 压差超标累计时长 */
static bool     s_sum_ok;                       /* 上一次总和校验是否通过 */
static uint8_t  s_i2c_fail_cnt;                 /* I2C 连续失败次数（判断数据是否过期） */

 /**
  * @file   median3
  * @brief  （内部函数）三数取中值：用来滤掉单次脉冲干扰（例如均衡切换瞬间的毛刺）
  * @param  a,b,c 三个采样值
  * @retval 中位数
  */
static uint16_t median3(uint16_t a, uint16_t b, uint16_t c)
{
    if (a > b) { uint16_t t = a; a = b; b = t; }
    if (b > c) { b = c; }
    return (a > b) ? a : b;
}
 /**
  * @file   is_elapsed
  * @brief  （内部函数）判断当前时刻是否已过某时刻（用无符号差避免 49 天翻转问题）
  * @param  now 当前 tick; t 目标时刻
  * @retval true = now 已到达或超过 t
  */
static bool is_elapsed(uint32_t now, uint32_t t)
{
    return ((now - t) < 0x80000000U);
}
 /**
  * @file   abs_i32
  * @brief  （内部函数）32 位绝对值
  * @param  v 输入值
  * @retval |v|
  */
static int32_t abs_i32(int32_t v)
{
    return (v < 0) ? -v : v;
}
 /**
  * @file   Cells_Init
  * @brief  单体电压检测初始化：
  *         1) 清空滤波历史、去抖计数、锁存状态与统计量；
  *         2) 阈值直接取 bms_config.h 的配置值；
  *         3) 上电第一次读数直接采信（不等滤波填满），避免开机后 1s 内误判
  * @param  无
  * @retval 无
  */
void Cells_Init(void)
{
    uint8_t i, j;

    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        g_cells.raw_mv[i] = 0U;
        g_cells.mv[i] = 0U;
        g_cells.level[i] = CELL_LVL_NORMAL;
        g_cells.trusted[i] = false;
        s_hold_mv[i] = 0U;
        s_hold_ms[i] = 0U;
        s_hist_n[i] = 0U;
        s_trip_hi_cnt[i] = s_trip_lo_cnt[i] = 0U;
        s_warn_hi_cnt[i] = s_warn_lo_cnt[i] = 0U;
        s_ov_state[i] = false;
        s_uv_state[i] = false;
        for (j = 0U; j < 3U; j++) { s_hist[j][i] = 0U; }
    }

    g_cells.min_mv = 0U;
    g_cells.max_mv = 0U;
    g_cells.avg_mv = 0U;
    g_cells.delta_mv = 0U;
    g_cells.idx_max = 0U;
    g_cells.idx_min = 0U;
    g_cells.ov_warn_mv = BMS_CELL_OV_WARN_MV;
    g_cells.uv_warn_mv = BMS_CELL_UV_WARN_MV;
    g_cells.sum_err_mv = 0;
    g_cells.sum_checked = false;
    g_cells.err = CELLS_OK;
    g_cells.wire_ok = true;
    g_cells.unbalance = false;
    g_cells.samples = 0U;

    s_sum_bad_cnt = 0U;
    s_unbal_ms = 0U;
    s_sum_ok = true;
    s_i2c_fail_cnt = 0U;
    s_applied_prev = 0U;
    s_untrust_mask = 0U;
    s_untrust_until_ms = 0U;
    g_cells_diag_active = false;
}
 /**
  * @file   Cells_Update
  * @brief  单体电压检测主函数（App 每 250ms 调用一次，与 AFE 的 ADC 更新周期对齐）：
  *         1) 维护均衡干扰屏蔽窗口：均衡掩码一变，前后受影响的电芯都先列为不可信，
  *            等 BMS_CELL_BAL_SETTLE_MS 之后再看（AFE 250ms 才更新一次数据）；
  *         2) 逐节处理：被均衡的节沿用上次可信值（最多 30s，超时判为盲区）；
  *            其余节做合理性检查（1.2V~4.3V）+ 3 点中值滤波；
  *         3) 统计可信电芯的最低/最高/平均/压差，并记录最高最低电芯编号；
  *         4) 总和校验： |Σ(单节) − V(BAT)| 连续超差 → 判定采样回路异常（均衡中跳过）；
  *         5) 逐节两级判定：越限级（AFE 跳闸阈值，带 100mV 回差 + 去抖）
  *            与预警级（提前 100~200mV 告警）；
  *         6) 压差超标持续 60s → 判定真的不均衡（只告警，不闭锁充放电）
  * @param  real_mv 已按 4S 槽位映射好的 4 节电压（mV，数组长度 = BMS_CELL_COUNT）
  *         pack_mv 组端电压 mV（BAT 寄存器读数），用于总和校验
  * @retval 无（结果写入 g_cells）
  */
void Cells_Update(const uint16_t *real_mv, uint16_t pack_mv)
{
    uint32_t now = HAL_GetTick();
    uint8_t  i;
    uint8_t  n_trust = 0U;
    uint32_t sum = 0U;
    uint16_t min_mv = 0xFFFFU;
    uint16_t max_mv = 0U;
    uint8_t  idx_max = 0U;
    uint8_t  idx_min = 0U;
    bool     low_found = false;
    bool     high_found = false;
    bool     blind = false;
    bool     stale = false;

    if (real_mv == NULL) {
        return;
    }

    /* ---------- 0) 数据新鲜度：I2C 连续失败 → 读到的还是上次的旧值 ---------- */
    if (g_bq_i2c_ok) {
        s_i2c_fail_cnt = 0U;
    } else if (s_i2c_fail_cnt < 255U) {
        s_i2c_fail_cnt++;
    }
    /* 每 250ms 一次，连续 (BMS_CELL_STALE_MS / 250) 次失败就算数据过期 */
    if (((uint32_t)s_i2c_fail_cnt * BMS_TASK_CELL_MS) >= BMS_CELL_STALE_MS) {
        stale = true;
    }

    /* ---------- 1) 均衡干扰屏蔽窗口 ---------- */
    if (g_bal.applied_mask != s_applied_prev) {
        /* 掩码变化：新开的和刚关掉的都要等一个转换周期，读数才可信 */
        s_untrust_mask = (uint8_t)(g_bal.applied_mask | s_applied_prev);
        s_untrust_until_ms = now + BMS_CELL_BAL_SETTLE_MS;
        s_applied_prev = g_bal.applied_mask;
    }
    if (is_elapsed(now, s_untrust_until_ms)) {
        s_untrust_mask = g_bal.applied_mask;
    }

    /* ---------- 2) 逐节处理 ---------- */
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        uint16_t raw = real_mv[i];
        bool     pert = ((s_untrust_mask >> s_slot[i]) & 0x01U) != 0U;

        g_cells.raw_mv[i] = raw;

        /* 2.1 读数被均衡电流污染（或刚切换未稳定）→ 不参与跳闸判定，
         *     但★要保持值参与 min/max/压差统计★。
         *     原因：均衡策略要靠压差决定"要不要继续均衡"。如果被均衡那一节被
         *     排除在统计外，压差会立刻塌下来（本板实测从 104mV 掉到 4mV），
         *     均衡条件就不成立了 → 停 → 压差恢复 → 又启动，来回抖。
         *     保持值本身就是这一节最近一次的真实测量，用它做统计是正确的。 */
        if (pert) {
            uint16_t held = s_hold_mv[i];   /* 这一节最近一次的真实测量 */

            s_hold_ms[i] += BMS_TASK_CELL_MS;
            if (s_hold_ms[i] > BMS_CELL_HOLD_MAX_MS) {
                blind = true;               /* 沿用超过 30s：判定为盲区，报警 */
                held = raw;                 /* 太久没真值：退回原始读数，至少统计别停 */
            }
            g_cells.mv[i] = held;
            g_cells.trusted[i] = false;     /* 不可信 → 不参与 OV/UV 跳闸 */
            g_cells.level[i] = CELL_LVL_HOLD;

            n_trust++;                      /* 统计口径：保持值算一份 */
            sum += held;
            if (held < min_mv) { min_mv = held; idx_min = i; }
            if (held > max_mv) { max_mv = held; idx_max = i; }
            continue;
        }

        /* 2.2 合理性检查：真实电芯不可能落在这个区间之外 */
        if (raw < BMS_CELL_PLAUSIBLE_MIN_MV) {
            low_found = true;
            g_cells.mv[i] = raw;
            g_cells.trusted[i] = false;
            g_cells.level[i] = CELL_LVL_TRIP;
            continue;
        }
        if (raw > BMS_CELL_PLAUSIBLE_MAX_MV) {
            high_found = true;
            g_cells.mv[i] = raw;
            g_cells.trusted[i] = false;
            g_cells.level[i] = CELL_LVL_TRIP;
            continue;
        }

        /* 2.3 3 点中值滤波：只为滤掉单次毛刺，不影响真实变化 */
        s_hist[2][i] = s_hist[1][i];
        s_hist[1][i] = s_hist[0][i];
        s_hist[0][i] = raw;
        if (s_hist_n[i] < 3U) {
            s_hist_n[i]++;
        }
        uint16_t v = (s_hist_n[i] >= 3U) ? median3(s_hist[0][i], s_hist[1][i], s_hist[2][i]) : raw;

        g_cells.mv[i] = v;
        g_cells.trusted[i] = true;
        s_hold_mv[i] = v;                   /* 记住可信值，供均衡期间沿用 */
        s_hold_ms[i] = 0U;

        n_trust++;
        sum += v;
        if (v < min_mv) { min_mv = v; idx_min = i; }
        if (v > max_mv) { max_mv = v; idx_max = i; }
    }

    /* ---------- 3) 统计（只统计可信电芯） ---------- */
    if (n_trust > 0U) {
        g_cells.min_mv = min_mv;
        g_cells.max_mv = max_mv;
        g_cells.avg_mv = (uint16_t)(sum / (uint32_t)n_trust);
        g_cells.sum_mv = sum;
        g_cells.delta_mv = (uint16_t)(max_mv - min_mv);
        g_cells.idx_max = idx_max;
        g_cells.idx_min = idx_min;
        g_cells.samples++;
    }

    /* ---------- 4) 总和校验：Σ(单节) 应等于组端电压 ---------- */
    g_cells.sum_checked = false;
    if (n_trust == BMS_CELL_COUNT && g_bal.applied_mask == 0U && pack_mv > 0U) {
        int32_t err = (int32_t)sum - (int32_t)pack_mv;
        g_cells.sum_err_mv = (int16_t)err;
        g_cells.sum_checked = true;
        if (abs_i32(err) > (int32_t)BMS_CELL_SUM_TOL_MV) {
            s_sum_bad_cnt++;
        } else {
            s_sum_bad_cnt = 0U;
        }
    } else {
        /* 均衡期间被均衡节的读数被压低，做这个校验必然误报 → 直接跳过 */
        s_sum_bad_cnt = 0U;
    }
    s_sum_ok = (s_sum_bad_cnt < BMS_CELL_SUM_BAD_CNT);

    /* ---------- 5) 逐节两级判定 ---------- */
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        uint16_t v;

        if (!g_cells.trusted[i]) {
            continue;                       /* 级别已在第 2 步定好（HOLD / TRIP） */
        }
        v = g_cells.mv[i];

        /* 5.1 过压：触发 ≥ OV 阈值，解除 < OV 阈值 − 回差 */
        if (!s_ov_state[i]) {
            if (v >= BMS_CELL_OV_MV) {
                if (s_trip_hi_cnt[i] < 255U) { s_trip_hi_cnt[i]++; }
                if (s_trip_hi_cnt[i] >= BMS_CELL_OV_DEBOUNCE) {
                    s_ov_state[i] = true;
                    s_trip_hi_cnt[i] = 0U;
                    BMS_Log("[CELL] 第 %u 节过压越限 %u mV\r\n", (unsigned)(i + 1U), v);
                }
            } else {
                s_trip_hi_cnt[i] = 0U;
            }
        } else if (v < (uint16_t)(BMS_CELL_OV_MV - BMS_CELL_HYST_MV)) {
            s_ov_state[i] = false;
            s_trip_hi_cnt[i] = 0U;
            BMS_Log("[CELL] 第 %u 节过压解除 %u mV\r\n", (unsigned)(i + 1U), v);
        }

        /* 5.2 欠压：触发 ≤ UV 阈值，解除 > UV 阈值 + 回差 */
        if (!s_uv_state[i]) {
            if (v <= BMS_CELL_UV_MV) {
                if (s_trip_lo_cnt[i] < 255U) { s_trip_lo_cnt[i]++; }
                if (s_trip_lo_cnt[i] >= BMS_CELL_UV_DEBOUNCE) {
                    s_uv_state[i] = true;
                    s_trip_lo_cnt[i] = 0U;
                    BMS_Log("[CELL] 第 %u 节欠压越限 %u mV\r\n", (unsigned)(i + 1U), v);
                }
            } else {
                s_trip_lo_cnt[i] = 0U;
            }
        } else if (v > (uint16_t)(BMS_CELL_UV_MV + BMS_CELL_HYST_MV)) {
            s_uv_state[i] = false;
            s_trip_lo_cnt[i] = 0U;
            BMS_Log("[CELL] 第 %u 节欠压解除 %u mV\r\n", (unsigned)(i + 1U), v);
        }

        /* 5.3 定级：越限 > 预警 > 正常 */
        if (s_ov_state[i] || s_uv_state[i]) {
            g_cells.level[i] = CELL_LVL_TRIP;
            s_warn_hi_cnt[i] = 0U;
            s_warn_lo_cnt[i] = 0U;
        } else {
            bool warn_hi = (v >= g_cells.ov_warn_mv);
            bool warn_lo = (v <= g_cells.uv_warn_mv);

            s_warn_hi_cnt[i] = warn_hi ? (uint8_t)(s_warn_hi_cnt[i] + 1U) : 0U;
            s_warn_lo_cnt[i] = warn_lo ? (uint8_t)(s_warn_lo_cnt[i] + 1U) : 0U;

            if (s_warn_hi_cnt[i] >= BMS_CELL_WARN_DEBOUNCE
                || s_warn_lo_cnt[i] >= BMS_CELL_WARN_DEBOUNCE) {
                g_cells.level[i] = CELL_LVL_WARN;
            } else {
                g_cells.level[i] = CELL_LVL_NORMAL;
            }
        }
    }

    /* ---------- 6) 压差（不均衡）判定 ---------- */
    if (n_trust == BMS_CELL_COUNT && g_cells.delta_mv > BMS_CELL_DELTA_WARN_MV) {
        s_unbal_ms += BMS_TASK_CELL_MS;
        if (s_unbal_ms >= BMS_CELL_DELTA_HOLD_MS) {
            g_cells.unbalance = true;
        }
    } else if (n_trust == BMS_CELL_COUNT && g_cells.delta_mv < BMS_CELL_DELTA_WARN_MV) {
        s_unbal_ms = 0U;
        g_cells.unbalance = false;
    } else {
        /* 有电芯不可信：计时保留（不累加也不清零），避免误判 */
    }

    /* ---------- 7) 汇总采样回路状态 ---------- */
    if (stale) {
        g_cells.err = CELLS_ERR_STALE;
        g_cells.wire_ok = false;
    } else if (low_found) {
        g_cells.err = CELLS_ERR_LOW;
        g_cells.wire_ok = false;
    } else if (high_found) {
        g_cells.err = CELLS_ERR_HIGH;
        g_cells.wire_ok = false;
    } else if (!s_sum_ok) {
        g_cells.err = CELLS_ERR_SUM;
        g_cells.wire_ok = false;
    } else if (blind) {
        g_cells.err = CELLS_ERR_BLIND;
        g_cells.wire_ok = false;
    } else {
        g_cells.err = CELLS_OK;
        g_cells.wire_ok = true;
    }
}
 /**
  * @file   Cells_WireOk
  * @brief  取采样回路是否可信（保护模块用它决定要不要闭锁充放电）
  * @param  无
  * @retval true = 采样回路正常
  */
bool Cells_WireOk(void)
{
    return g_cells.wire_ok;
}
 /**
  * @file   Cells_Unbalanced
  * @brief  取压差是否长时间超标（只做告警，不闭锁充放电）
  * @param  无
  * @retval true = 判定为不均衡
  */
bool Cells_Unbalanced(void)
{
    return g_cells.unbalance;
}
 /**
  * @file   Cells_Level
  * @brief  取第 idx 节的判定级别
  * @param  idx 电芯编号（0 起）
  * @retval 判定级别（越界返回 CELL_LVL_NORMAL）
  */
Cell_Level_t Cells_Level(uint8_t idx)
{
    if (idx >= BMS_CELL_COUNT) {
        return CELL_LVL_NORMAL;
    }
    return g_cells.level[idx];
}
 /**
  * @file   Cells_ErrName
  * @brief  采样回路状态码 → 字符串（打印用）
  * @param  e 状态码
  * @retval 字符串
  */
const char *Cells_ErrName(Cells_Err_t e)
{
    switch (e) {
    case CELLS_OK:        return "OK";
    case CELLS_ERR_SUM:   return "SUM_MISMATCH(单节之和与组端电压不符)";
    case CELLS_ERR_LOW:   return "CELL_TOO_LOW(疑采样线开路/电芯失效)";
    case CELLS_ERR_HIGH:  return "CELL_TOO_HIGH(疑采样线接错/串入高压)";
    case CELLS_ERR_BLIND: return "BLIND(长期拿不到可信读数)";
    case CELLS_ERR_STALE: return "STALE(采样数据过期/AFE通信异常)";
    default:              return "UNKNOWN";
    }
}
 /**
  * @file   Cells_LevelName
  * @brief  判定级别 → 字符串（打印用）
  * @param  l 级别
  * @retval 字符串
  */
const char *Cells_LevelName(Cell_Level_t l)
{
    switch (l) {
    case CELL_LVL_NORMAL: return "NORMAL";
    case CELL_LVL_WARN:   return "WARN";
    case CELL_LVL_TRIP:   return "TRIP";
    case CELL_LVL_HOLD:   return "HOLD(均衡中)";
    default:              return "?";
    }
}
 /**
  * @file   Cells_Print
  * @brief  打印一页单体电压检测结果：逐节原始值/采用值/级别/是否可信、
  *         最高最低平均压差、总和校验、采样回路结论、当前阈值
  * @param  无
  * @retval 无
  */
void Cells_Print(void)
{
    uint8_t i;

    BMS_Log("\r\n===== 单体电压检测 =====\r\n");
    BMS_Log("电芯  AFE槽  原始mV  采用mV  级别\r\n");
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        BMS_Log("  %u    VC%u   %5u   %5u  %s\r\n",
                (unsigned)(i + 1U), (unsigned)(s_slot[i] + 1U),
                g_cells.raw_mv[i], g_cells.mv[i], Cells_LevelName(g_cells.level[i]));
    }
    BMS_Log("---------------------------------------\r\n");
    BMS_Log("最高 %u mV (第 %u 节)   最低 %u mV (第 %u 节)\r\n",
            g_cells.max_mv, (unsigned)(g_cells.idx_max + 1U),
            g_cells.min_mv, (unsigned)(g_cells.idx_min + 1U));
    BMS_Log("平均 %u mV             压差 %u mV%s\r\n",
            g_cells.avg_mv, g_cells.delta_mv,
            g_cells.unbalance ? "  ★不均衡(持续超限)" : "");
    if (g_cells.sum_checked) {
        BMS_Log("总和校验: Σ=%lu mV  偏差 %+d mV  (限值 %u mV) %s\r\n",
                (unsigned long)g_cells.sum_mv,
                g_cells.sum_err_mv, BMS_CELL_SUM_TOL_MV,
                (g_cells.sum_err_mv > -(int16_t)BMS_CELL_SUM_TOL_MV
                 && g_cells.sum_err_mv < (int16_t)BMS_CELL_SUM_TOL_MV) ? "通过" : "★异常");
    } else {
        BMS_Log("总和校验: 跳过（有均衡在动作，被均衡节读数被压低）\r\n");
    }
    BMS_Log("采样回路: %s   wire_ok=%d  有效样本 %lu\r\n",
            Cells_ErrName(g_cells.err), (int)g_cells.wire_ok,
            (unsigned long)g_cells.samples);
    BMS_Log("阈值: OV 越限 %u / 预警 %u   UV 越限 %u / 预警 %u  压差告警 %u mV\r\n",
            BMS_CELL_OV_MV, BMS_CELL_OV_WARN_MV,
            BMS_CELL_UV_MV, BMS_CELL_UV_WARN_MV, BMS_CELL_DELTA_WARN_MV);
    BMS_Log("========================\r\n");
}
 /**
  * @file   Cells_OpenWireTest
  * @brief  采样线开路自检（CELLDIAG 命令调用）：
  *         1) 先要求静置（|电流| < BMS_CELL_DIAG_MAX_A），否则均衡压降会被负载掩盖；
  *         2) 关掉全部均衡，等稳定，记录各节基准电压；
  *         3) 逐节单独打开该节均衡，等稳定，再看该节读数——正常电芯的读数会被
  *            均衡电流在 R22~R25 上产生的压降压低；若某节几乎不动，
  *            说明均衡电流没有流过它的采样电阻（采样线开路/接触不良）；
  *         4) 用「相对比较」判定（压降最小的那节可疑），不依赖压降的绝对大小；
  *         5) 结束后恢复原均衡掩码。
  *         注意：整个过程约 5.4s 为阻塞执行，期间保护评估暂停
  *               （AFE 硬件保护仍然有效），看门狗在等待中被手动喂狗。
  * @param  无
  * @retval 无
  */
void Cells_OpenWireTest(void)
{
    uint16_t base[BMS_CELL_COUNT];
    uint16_t bal_mv[BMS_CELL_COUNT];
    uint16_t drop[BMS_CELL_COUNT];
    uint16_t max_drop = 0U;
    uint8_t  i;

    /* 1) 前置条件 */
    if (fabsf(g_bq.current_a) > BMS_CELL_DIAG_MAX_A) {
        BMS_Log("[DIAG] 当前电流 %.2f A，请断开充放电、静置后再自检（要求 |I| < %.1f A）\r\n",
                g_bq.current_a, BMS_CELL_DIAG_MAX_A);
        return;
    }
    if (g_prot.fault != BMS_FLT_NONE) {
        BMS_Log("[DIAG] 存在故障(%s)，请先排除并 CLR 再自检\r\n", Prot_FaultName(g_prot.fault));
        return;
    }
    if (!Cells_WireOk()) {
        BMS_Log("[DIAG] 采样回路已判定异常(%s)，仍继续自检以定位具体是哪一节\r\n",
                Cells_ErrName(g_cells.err));
    }

    BMS_Log("\r\n[DIAG] 开始采样线自检（约 5.4s，期间自动均衡会暂停）...\r\n");
    g_cells_diag_active = true;             /* 通知均衡模块不要插手 */
    BQ_SetBalanceMask(0x00U);
    HAL_Delay(BMS_CELL_DIAG_SETTLE_MS);

    /* 2) 基准读数（无均衡） */
    BQ_ReadCells();
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        base[i] = g_bq.real_mv[i];
        drop[i] = 0U;
    }

    /* 3) 逐节施加均衡，观察该节读数被压低多少 */
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        BQ_SetBalanceMask((uint8_t)(1U << s_slot[i]));
        Bms_WdgFeed();
        HAL_Delay(BMS_CELL_DIAG_ON_MS);

        BQ_ReadCells();
        bal_mv[i] = g_bq.real_mv[i];
        drop[i] = (base[i] > bal_mv[i]) ? (uint16_t)(base[i] - bal_mv[i]) : 0U;
        if (drop[i] > max_drop) { max_drop = drop[i]; }

        BQ_SetBalanceMask(0x00U);
        Bms_WdgFeed();
        HAL_Delay(BMS_CELL_DIAG_SETTLE_MS);
    }
    g_cells_diag_active = false;
    /* 交给 Bal_Task 下一拍按逻辑掩码重新下发（这里只把状态标成"已关"） */
    g_bal.applied_mask = 0U;
    BQ_SetBalanceMask(0x00U);

    /* 4) 输出结果 */
    BMS_Log("===== 采样线自检结果 =====\r\n");
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        const char *verdict = "正常";
        if (max_drop >= 20U && drop[i] < (uint16_t)(max_drop / 3U)) {
            verdict = "★可疑：该节采样线开路或接触不良";
        }
        BMS_Log("  电芯%u (VC%u): 基准 %5u mV → 均衡时 %5u mV   压降 %4u mV   %s\r\n",
                (unsigned)(i + 1U), (unsigned)(s_slot[i] + 1U),
                base[i], bal_mv[i], drop[i], verdict);
    }
    if (max_drop < 20U) {
        BMS_Log("  说明：均衡对读数的影响过小（最大仅 %u mV），本方法无法判别。\r\n"
                "        请改用万用表实测各节抽头电压（应等于相邻 VC 引脚间电压）。\r\n", max_drop);
    } else {
        BMS_Log("  说明：压降最小的那一节最可疑——别人都有明显压降而它没有，\r\n"
                "        说明均衡电流没流过它的采样电阻。\r\n");
    }
    BMS_Log("=========================\r\n");
}
