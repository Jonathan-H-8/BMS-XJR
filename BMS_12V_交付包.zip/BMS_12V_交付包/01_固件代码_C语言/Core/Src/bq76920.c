/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bq76920.c
 * 描述    ：BQ76920 驱动实现：I2C 读写、电压/温度/电流换算、保护寄存器配置、FET 与均衡控制
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: PB6=I2C1_SCL; PB7=I2C1_SDA; PA1=ALERT(EXTI 上升沿)
 * 参考手册: TI SLUSBK2I
 * 寄存器参考: SYS_STAT=0x00 ... CC=0x32/0x33; ADCGAIN1=0x50; ADCOFFSET=0x51; ADCGAIN2=0x59
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bq76920.h"
#include <math.h>
#include <string.h>

BQ_Data_t g_bq;
bool       g_bq_i2c_ok = false;
static uint16_t s_gain_uv = 380U;   /* ADC 增益 µV/LSB（开机从 OTP 读） */
static int8_t   s_offset_mv = 0;    /* ADC 偏移 mV */

extern I2C_HandleTypeDef BQ_I2C;

/* ------------------------------------------------------------------ */
/* 基础读写                                                            */
/* ------------------------------------------------------------------ */
 /**
  * @file   BQ_ReadBlock
  * @brief  从 BQ76920 连续读若干字节（一次事务保证数据同帧）
  * @param  reg 起始寄存器地址; buf 读出缓冲; len 字节数
  * @retval HAL_OK 成功；其它 失败（同时刷新 g_bq_i2c_ok）
  */
HAL_StatusTypeDef BQ_ReadBlock(uint8_t reg, uint8_t *buf, uint16_t len)
{
    HAL_StatusTypeDef st = HAL_I2C_Mem_Read(&BQ_I2C, BQ_I2C_ADDR8, reg,
                                            I2C_MEMADD_SIZE_8BIT, buf, len,
                                            BQ_I2C_TIMEOUT_MS);
    g_bq_i2c_ok = (st == HAL_OK);          /* 供看门狗判断通信是否健康 */
    return st;
}
 /**
  * @file   BQ_ReadReg
  * @brief  读 BQ76920 单个寄存器
  * @param  reg 寄存器地址; val 读出的值
  * @retval HAL_OK 成功；其它 失败
  */
HAL_StatusTypeDef BQ_ReadReg(uint8_t reg, uint8_t *val)
{
    return BQ_ReadBlock(reg, val, 1U);
}
 /**
  * @file   BQ_WriteReg
  * @brief  写 BQ76920 单个寄存器（1 字节）
  * @param  reg 寄存器地址; val 待写值
  * @retval HAL_OK 成功；其它 失败
  */
HAL_StatusTypeDef BQ_WriteReg(uint8_t reg, uint8_t val)
{
    HAL_StatusTypeDef st = HAL_I2C_Mem_Write(&BQ_I2C, BQ_I2C_ADDR8, reg,
                                             I2C_MEMADD_SIZE_8BIT, &val, 1U,
                                             BQ_I2C_TIMEOUT_MS);
    g_bq_i2c_ok = (st == HAL_OK);
    return st;
}
 /**
  * @file   rd8
  * @brief  （内部函数）读一字节寄存器，不做错误处理，简化上层代码
  * @param  reg 寄存器地址
  * @retval 读出的字节
  */
static uint8_t rd8(uint8_t reg)
{
    uint8_t v = 0U;
    (void)BQ_ReadReg(reg, &v);
    return v;
}
 /**
  * @file   wr8
  * @brief  （内部函数）写一字节寄存器，不做错误处理
  * @param  reg 寄存器地址; v 待写值
  * @retval 无
  */
static void wr8(uint8_t reg, uint8_t v)
{
    (void)BQ_WriteReg(reg, v);
}
 /**
  * @file   BQ_GetSysStat
  * @brief  读系统状态寄存器 SYS_STAT（含 CC_READY 与各类故障位）
  * @param  无
  * @retval 状态字节：bit7 CC_READY bit5 DEVICE_XREADY bit4 OVRD_ALERT bit3 UV bit2 OV bit1 SCD bit0 OCD
  */
uint8_t BQ_GetSysStat(void)
{
    g_bq.sys_stat = rd8(BQ_REG_SYS_STAT);
    return g_bq.sys_stat;
}
 /**
  * @file   BQ_ClearSysStat
  * @brief  清 SYS_STAT 指定位（该寄存器"写 1 清除、写 0 保持"，所以只能写要清的那些位）
  * @param  mask 要清除的位掩码
  * @retval 无
  */
void BQ_ClearSysStat(uint8_t mask)
{
    /* SYS_STAT 为“写 1 清除”，因此只能写要清的位 */
    wr8(BQ_REG_SYS_STAT, mask);
}

/* ------------------------------------------------------------------ */
/* 校准系数（OTA 出厂校准值）                                            */
/* ------------------------------------------------------------------ */
 /**
  * @file   BQ_ReadGainOffset
  * @brief  从 OTP 读 14 位 ADC 的校准系数：GAIN(µV/LSB) 与 OFFSET(mV)
  *         GAIN = 365 + ADCGAIN，其中 ADCGAIN[4:3] 在 0x50[3:2]、ADCGAIN[2:0] 在 0x59[7:5]
  * @param  无
  * @retval 无（结果存 s_gain_uv / s_offset_mv）
  */
void BQ_ReadGainOffset(void)
{
    uint8_t g1 = rd8(BQ_REG_ADCGAIN1);   /* bit3:2 = ADCGAIN[4:3] */
    uint8_t g2 = rd8(BQ_REG_ADCGAIN2);   /* bit7:5 = ADCGAIN[2:0] */
    uint8_t of = rd8(BQ_REG_ADCOFFSET);  /* 有符号 mV */
    uint8_t cal = (uint8_t)((((g1 >> 2) & 0x03U) << 3) | ((g2 >> 5) & 0x07U));

    s_gain_uv   = (uint16_t)(365U + cal);   /* 365..396 µV/LSB */
    s_offset_mv = (int8_t)of;
}
 /**
  * @file   BQ_GetGainUV
  * @brief  取当前 ADC 增益
  * @param  无
  * @retval 增益 µV/LSB（范围 365~396）
  */
uint16_t BQ_GetGainUV(void) { return s_gain_uv; }
 /**
  * @file   BQ_GetOffsetMV
  * @brief  取当前 ADC 偏移
  * @param  无
  * @retval 偏移 mV（有符号）
  */
int8_t   BQ_GetOffsetMV(void) { return s_offset_mv; }

/* ------------------------------------------------------------------ */
/* 初始化                                                              */
/* ------------------------------------------------------------------ */
 /**
  * @file   BQ_Init
  * @brief  BQ76920 上电初始化：
  *         1) 清所有状态位  2) SYS_CTRL1=0x18 开 ADC 并选外部热敏
  *         3) CC_CFG=0x19（数据手册强制要求）  4) 读 ADC 校准值
  *         5) 下发保护参数  6) 使能 CHG/DSG 与库仑计  7) 等 250ms 后首读电压
  * @param  无
  * @retval HAL_OK 成功；HAL_ERROR 总线无应答（查地址/上拉/供电）
  */
HAL_StatusTypeDef BQ_Init(void)
{
    memset(&g_bq, 0, sizeof(g_bq));

    if (HAL_I2C_IsDeviceReady(&BQ_I2C, BQ_I2C_ADDR8, 3U, 100U) != HAL_OK) {
        return HAL_ERROR;                       /* 总线无应答：查地址/上拉/供电 */
    }

    /* 1) 清所有状态位 */
    BQ_ClearSysStat(0xFFU);
    HAL_Delay(2U);

    /* 2) SYS_CTRL1 = ADC_EN | TEMP_SEL(外部 NTC)，ADC 不使能则 OV/UV 保护不工作 */
    wr8(BQ_REG_SYS_CTRL1, BQ_CTRL1_NORMAL);
    HAL_Delay(2U);

    /* 3) CC_CFG 必须写 0x19 */
    wr8(BQ_REG_CC_CFG, BQ_CC_CFG_VALUE);
    HAL_Delay(2U);

    /* 4) 读 ADC 校准值 */
    BQ_ReadGainOffset();

    /* 5) 下发保护参数 */
    BQ_ConfigProtection();

    /* 6) 使能 FET 与库仑计 */
    BQ_SetBalanceMask(0x00U);
    BQ_SetFets(true, true);

    /* 7) 从 SHIP 唤醒后，首次读取电压前需等待 ≥250ms */
    HAL_Delay(260U);
    BQ_ReadCells();

    return HAL_OK;
}

/* ------------------------------------------------------------------ */
/* 电压                                                            */
/* ------------------------------------------------------------------ */
 /**
  * @file   adc_to_mv
  * @brief  （内部函数）14 位 ADC 码 → 单体电压 mV：V = GAIN×ADC + OFFSET
  * @param  adc 14 位 ADC 原始码
  * @retval 电压 mV
  */
static uint16_t adc_to_mv(uint16_t adc)
{
    int32_t mv = ((int32_t)adc * (int32_t)s_gain_uv) / 1000 + (int32_t)s_offset_mv;
    if (mv < 0) {
        mv = 0;
    }
    return (uint16_t)mv;
}
 /**
  * @file   BQ_ReadCellsRaw
  * @brief  读 VC1~VC5 的 14 位 ADC 码（0x0C~0x15 连续 10 字节）
  * @param  adc5 输出缓冲（长度 5），依次为 VC1..VC5 的 ADC 码
  * @retval HAL_OK 成功；其它 失败
  */
HAL_StatusTypeDef BQ_ReadCellsRaw(uint16_t *adc5)
{
    uint8_t buf[10];
    uint8_t i;

    if (adc5 == NULL) {
        return HAL_ERROR;
    }

    /* 必须一次读完 10 字节：分成两次事务可能读到跨转换帧的拼凑值 */
    if (BQ_ReadBlock(BQ_REG_VC1_HI, buf, 10U) != HAL_OK) {
        return HAL_ERROR;
    }
    for (i = 0U; i < 5U; i++) {
        adc5[i] = (uint16_t)(((uint16_t)buf[i * 2U] << 8) | buf[i * 2U + 1U]);
    }
    return HAL_OK;
}
 /**
  * @file   BQ_ReadCells
  * @brief  刷新全部电芯电压：读 VC1~VC5 → 按本板 4S 槽位映射取出真实 4 节，
  *         并算出最小/最大/平均值
  * @param  无
  * @retval 无（更新 g_bq.cell_mv / g_bq.real_mv 等）
  */
void BQ_ReadCells(void)
{
    uint16_t adc5[5];
    uint8_t i;

    /* 读失败就保留上一次的值，由 bms_cells.c 按 g_bq_i2c_ok 判断数据是否过期 */
    if (BQ_ReadCellsRaw(adc5) != HAL_OK) {
        return;
    }

    uint16_t min_mv = 0xFFFFU, max_mv = 0U;
    uint32_t sum = 0U;

    for (i = 0U; i < 5U; i++) {
        g_bq.cell_mv[i] = adc_to_mv(adc5[i]);
    }

    /* 按本板的 4S 槽位映射取真实电芯电压 */
    static const uint8_t slot[BMS_CELL_COUNT] = {
        BMS_CELL_SLOT_0, BMS_CELL_SLOT_1, BMS_CELL_SLOT_2, BMS_CELL_SLOT_3
    };

    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        uint16_t v = g_bq.cell_mv[slot[i]];
        g_bq.real_mv[i] = v;
        if (v < min_mv) { min_mv = v; }
        if (v > max_mv) { max_mv = v; }
        sum += v;
    }

    g_bq.real_min_mv = min_mv;
    g_bq.real_max_mv = max_mv;
    g_bq.real_avg_mv = (uint16_t)(sum / BMS_CELL_COUNT);
}
 /**
  * @file   BQ_GetPackMv
  * @brief  读电池组总电压：V(BAT) = 4 × GAIN × ADC + N × OFFSET
  * @param  无
  * @retval 组端电压 mV（失败返回 0）
  */
uint16_t BQ_GetPackMv(void)
{
    uint8_t b[2];
    if (BQ_ReadBlock(BQ_REG_BAT_HI, b, 2U) != HAL_OK) {
        return 0U;
    }
    uint16_t adc = (uint16_t)(((uint16_t)b[0] << 8) | b[1]);
    /* 数据手册：V(BAT) = 4 × GAIN × ADC + N × OFFSET（N=组串节数） */
    int32_t mv = ((int32_t)adc * 4 * (int32_t)s_gain_uv) / 1000
               + (int32_t)BMS_CELL_COUNT * (int32_t)s_offset_mv;
    if (mv < 0) {
        mv = 0;
    }
    return (uint16_t)mv;
}

/* ------------------------------------------------------------------ */
/* 温度                                                            */
/* ------------------------------------------------------------------ */
 /**
  * @file   BQ_GetTs1Adc
  * @brief  读 TS1 温度通道的 14 位 ADC 码
  * @param  无
  * @retval ADC 码（0~16383）
  */
int16_t BQ_GetTs1Adc(void)
{
    uint8_t b[2];
    if (BQ_ReadBlock(BQ_REG_TS1_HI, b, 2U) != HAL_OK) {
        return 0;
    }
    return (int16_t)((((uint16_t)b[0] << 8) | b[1]) & 0x3FFFU);
}
 /**
  * @file   BQ_ReadTs1
  * @brief  读 TS1 温度通道并做完整诊断：
  *         1) 读 0x2C 得到 14 位 ADC 码；
  *         2) 换算引脚电压 V = ADC × 382 µV（数据手册）；
  *         3) 换算 NTC 阻值 R = 上拉10k × V / (VREF 3.3V − V)；
  *         4) 按阻值判开路/短路/超范围——★这一步很关键：
  *            NTC 开路时 TS1 被上拉到 3.3V，按公式会算成「极低温」；
  *            NTC 短路时 TS1 为 0V，会算成「极高温」。
  *            如果不做诊断，固件就会把「传感器坏了」误当成「电池过温/过冷」，
  *            既可能误保护，也可能掩盖真实的过温。
  * @param  adc 输出 TS1 的 14 位 ADC 码（可为 NULL）; volt 输出引脚电压 V（可为 NULL）
  *         r_ntc 输出 NTC 阻值 Ω（可为 NULL）; status 输出诊断状态（BQ_TS_xxx，可为 NULL）
  * @retval HAL_OK 读取成功（status 里带诊断结论）；其它 I2C 失败
  */
HAL_StatusTypeDef BQ_ReadTs1(int16_t *adc, float *volt, float *r_ntc, uint8_t *status)
{
    int16_t code;
    float   v;
    float   r;
    uint8_t st = BQ_TS_OK;

    code = BQ_GetTs1Adc();
    if ((code == 0) && (!g_bq_i2c_ok)) {
        if (status != NULL) { *status = BQ_TS_IO_ERR; }
        return HAL_ERROR;
    }

    v = (float)code * BQ_TS1_LSB_V;

    /* 电气硬判：接近 0V = 短路到地；接近 VREF = 未接/开路 */
    if (v <= 0.02f) {
        st = BQ_TS_SHORT;
        r = 0.0f;
    } else if (v >= (BMS_NTC_VREF - 0.02f)) {
        st = BQ_TS_OPEN;
        r = 999999.0f;
    } else {
        r = (BMS_NTC_PULLUP_OHM * v) / (BMS_NTC_VREF - v);
        if (r >= BMS_NTC_R_OPEN_OHM) {
            st = BQ_TS_OPEN;
        } else if (r <= BMS_NTC_R_SHORT_OHM) {
            st = BQ_TS_SHORT;
        } else {
            st = BQ_TS_OK;
        }
    }

    if (adc != NULL)    { *adc = code; }
    if (volt != NULL)   { *volt = v; }
    if (r_ntc != NULL)  { *r_ntc = r; }
    if (status != NULL) { *status = st; }
    return HAL_OK;
}
 /**
  * @file   BQ_TempFromNtcR
  * @brief  NTC 阻值 → 温度（B 参数模型，Steinhart-Hart 简化式）：
  *         1/T = 1/T0 + ln(R/R0) / B，T0 = 298.15K（25℃）
  * @param  r_ntc NTC 阻值 Ω
  * @retval 温度 ℃（超出 BMS_TEMP_VALID_MIN..MAX 时截断到边界）
  */
int8_t BQ_TempFromNtcR(float r_ntc)
{
    float t;

    if (r_ntc <= 1.0f) {
        return BMS_TEMP_VALID_MAX;
    }

    t = 1.0f / ((1.0f / 298.15f) + (logf(r_ntc / BMS_NTC_R0_OHM) / BMS_NTC_B)) - 273.15f;

    if (t > (float)BMS_TEMP_VALID_MAX) { t = (float)BMS_TEMP_VALID_MAX; }
    if (t < (float)BMS_TEMP_VALID_MIN) { t = (float)BMS_TEMP_VALID_MIN; }
    return (int8_t)t;
}
 /**
  * @file   BQ_GetTs1Temp
  * @brief  由 TS1 外接 NTC 换算温度（兼容旧接口，不做诊断）
  *         需要区分「传感器坏了」和「温度真的超限」时请用 BQ_ReadTs1
  * @param  无
  * @retval 温度 ℃（异常时返回量程边界值）
  */
int8_t BQ_GetTs1Temp(void)
{
    float   v;
    float   r;
    uint8_t st = BQ_TS_OK;

    if (BQ_ReadTs1(NULL, &v, &r, &st) != HAL_OK) {
        return BMS_TEMP_VALID_MAX;
    }
    (void)v;
    if (st == BQ_TS_OPEN) {
        return BMS_TEMP_VALID_MIN;      /* 开路：假象极低温 */
    }
    if (st == BQ_TS_SHORT) {
        return BMS_TEMP_VALID_MAX;      /* 短路：假象极高温 */
    }
    return BQ_TempFromNtcR(r);
}
 /**
  * @file   BQ_IsExtTempSel
  * @brief  查询 TS1 通道当前选的是外部 NTC 还是内部温度传感器
  * @param  无
  * @retval true = 选的是外部 NTC（TEMP_SEL=1）
  */
bool BQ_IsExtTempSel(void)
{
    uint8_t ctrl = 0U;
    if (BQ_ReadReg(BQ_REG_SYS_CTRL1, &ctrl) != HAL_OK) {
        return false;
    }
    return ((ctrl & BQ_CTRL1_TEMP_SEL) != 0U);
}
 /**
  * @file   BQ_GetDieTemp
  * @brief  算芯片内部温度：TEMPDIE = 25 − (V(TS1) − 1.200) / 0.0042
  *         ★注意：它直接用当前 TS1 的读数，只有 TEMP_SEL=0（选内部传感器）时才有意义。
  *         本板 TEMP_SEL=1（外部 NTC），所以不要周期性调用它——那样算出来的是
  *         拿 NTC 电压套芯片温度公式的假值。要读就用 BQ_ReadDieTempOnce()。
  * @param  无
  * @retval 芯片内部温度 ℃
  */
int8_t BQ_GetDieTemp(void)
{
    /* 内部温度模式：TEMPDIE = 25 - (V(TS1) - 1.200) / 0.0042 */
    float v = ((float)BQ_GetTs1Adc() * BQ_TS1_LSB_V);
    return (int8_t)(25.0f - (v - 1.200f) / 0.0042f);
}
 /**
  * @file   BQ_ReadDieTempOnce
  * @brief  读一次芯片内部温度：
  *         0x2C(TS1) 是外部 NTC 与内部温度传感器共用的 ADC 通道，由 TEMP_SEL 选择。
  *         本板平时是 TEMP_SEL=1，所以这里临时切到内部传感器、等一个转换周期、
  *         读完再切回外部 NTC（否则外部 NTC 的温度就没了）。
  *         仅用于看板级温升趋势，不能当电芯温度用。
  * @param  无
  * @retval 芯片内部温度 ℃（读取失败返回 0）
  */
int8_t BQ_ReadDieTempOnce(void)
{
    uint8_t ctrl = 0U;
    float   v;
    int8_t  t;

    if (BQ_ReadReg(BQ_REG_SYS_CTRL1, &ctrl) != HAL_OK) {
        return 0;
    }

    /* 1) 切到内部温度传感器（保持 ADC_EN 不变，否则 OV/UV 保护会失效） */
    if (BQ_WriteReg(BQ_REG_SYS_CTRL1, (uint8_t)(ctrl & (uint8_t)(~BQ_CTRL1_TEMP_SEL))) != HAL_OK) {
        return 0;
    }

    /* 2) 等 ADC 完成一次转换（数据手册：ADC 每 250ms 更新一次） */
    HAL_Delay(BMS_TEMP_DIE_SETTLE_MS);

    v = (float)BQ_GetTs1Adc() * BQ_TS1_LSB_V;
    t = (int8_t)(25.0f - (v - 1.200f) / 0.0042f);

    /* 3) 恢复原来的通道选择 */
    (void)BQ_WriteReg(BQ_REG_SYS_CTRL1, ctrl);
    return t;
}

/* ------------------------------------------------------------------ */
/* 库仑计                                                             */
/* ------------------------------------------------------------------ */
 /**
  * @file   BQ_GetCcLsbA
  * @brief  库仑计 1 个 LSB 对应多少安培：8.44µV ÷ 采样电阻(Ω)
  * @param  无
  * @retval 电流 A/LSB（R17=1mΩ 时为 8.44mA）
  */
float BQ_GetCcLsbA(void)
{
    /* LSB 电压 8.44µV ÷ 采样电阻(Ω) = 电流(A) */
    return (BMS_CC_LSB_UV / 1000.0f) / BMS_RSENSE_MOHM;
}
 /**
  * @file   BQ_ReadCc
  * @brief  读库仑计 CC（16 位有符号，单位 LSB，「读走即复位」），并换算当前电流
  * @param  无
  * @retval CC 原始值（有符号）
  */
int16_t BQ_ReadCc(void)
{
    uint8_t b[2];
    if (BQ_ReadBlock(BQ_REG_CC_HI, b, 2U) != HAL_OK) {
        return 0;
    }
    g_bq.cc_raw = (int16_t)(((uint16_t)b[0] << 8) | b[1]);   /* 读走即复位 */
    g_bq.current_a = (float)g_bq.cc_raw * BQ_GetCcLsbA();
    return g_bq.cc_raw;
}
 /**
  * @file   BQ_GetCurrentA
  * @brief  取最近一次换算出的电流
  * @param  无
  * @retval 电流 A（+充电 / -放电）
  */
float BQ_GetCurrentA(void)
{
    return g_bq.current_a;
}

/* ------------------------------------------------------------------ */
/* FET / 均衡 / 保护                                                   */
/* ------------------------------------------------------------------ */
 /**
  * @file   BQ_SetFets
  * @brief  同时设置 CHG 与 DSG 两个 MOS 驱动，并保持库仑计常开（SYS_CTRL2）
  * @param  chg true=开充电管; dsg true=开放电管
  * @retval 无
  */
void BQ_SetFets(bool chg, bool dsg)
{
    uint8_t v = rd8(BQ_REG_SYS_CTRL2);
    v &= (uint8_t)~(BQ_CTRL2_CHG_ON | BQ_CTRL2_DSG_ON);
    v |= BQ_CTRL2_CC_EN;                     /* 库仑计常开 */
    v &= (uint8_t)~BQ_CTRL2_CC_ONESHOT;
    if (chg) { v |= BQ_CTRL2_CHG_ON; }
    if (dsg) { v |= BQ_CTRL2_DSG_ON; }
    wr8(BQ_REG_SYS_CTRL2, v);

    g_bq.chg_on = chg;
    g_bq.dsg_on = dsg;
}
 /**
  * @file   BQ_SetChg
  * @brief  单独开/关充电管（保持放电管状态不变）
  * @param  on true=开
  * @retval 无
  */
void BQ_SetChg(bool on) { BQ_SetFets(on, g_bq.dsg_on); }
 /**
  * @file   BQ_SetDsg
  * @brief  单独开/关放电管（保持充电管状态不变）
  * @param  on true=开
  * @retval 无
  */
void BQ_SetDsg(bool on) { BQ_SetFets(g_bq.chg_on, on); }
 /**
  * @file   BQ_IsLoadPresent
  * @brief  读负载检测状态：CHG 关闭时该位表示 PACK 端是否挂着负载/充电器
  * @param  无
  * @retval true=检测到负载
  */
bool BQ_IsLoadPresent(void)
{
    return ((rd8(BQ_REG_SYS_CTRL1) & BQ_CTRL1_LOAD_PRESENT) != 0U);
}
 /**
  * @file   BQ_SetBalanceMask
  * @brief  写 CELLBAL1 控制内部均衡 FET。bit0~bit4 对应 AFE 槽 1~5；
  *         本板第 4 槽是短接的空槽，这里强制屏蔽，避免去均衡一个 0V 的槽
  * @param  mask 均衡掩码（bit0=槽1 … bit4=槽5）
  * @retval 无
  */
void BQ_SetBalanceMask(uint8_t mask)
{
    /* CELLBAL1 bit0..bit4 对应内部槽 1..5；本板槽 4 被短接，强制屏蔽 */
    mask &= (uint8_t)0x1FU;
    mask &= (uint8_t)~BMS_BAL_SKIP_MASK;
    wr8(BQ_REG_CELLBAL1, mask);
    g_bq.bal_mask = mask;
}
 /**
  * @file   BQ_SetOvUvTrip
  * @brief  设置过压/欠压跳闸阈值。寄存器只放 14 位 ADC 码的「中间 8 位」，
  *         高 2 位固定 10(OV)/01(UV)、低 4 位固定 1000/0000，所以这里先反算 ADC 码再取中间 8 位
  * @param  ov_mv 过压阈值 mV; uv_mv 欠压阈值 mV
  * @retval 无
  */
void BQ_SetOvUvTrip(uint16_t ov_mv, uint16_t uv_mv)
{
    /* 寄存器内容 = 14bit ADC 码的中间 8 位；高位固定 10(OV)/01(UV)，低 4 位固定 1000/0000
     * 14bit 码 = (V_mV - OFFSET_mV) × 1000 / GAIN_µV                              */
    int32_t ov_adc = (((int32_t)ov_mv - (int32_t)s_offset_mv) * 1000) / (int32_t)s_gain_uv;
    int32_t uv_adc = (((int32_t)uv_mv - (int32_t)s_offset_mv) * 1000) / (int32_t)s_gain_uv;

    if (ov_adc < 0)    { ov_adc = 0; }
    if (ov_adc > 16383){ ov_adc = 16383; }
    if (uv_adc < 0)    { uv_adc = 0; }
    if (uv_adc > 16383){ uv_adc = 16383; }

    wr8(BQ_REG_OV_TRIP, (uint8_t)((ov_adc >> 4) & 0xFF));
    wr8(BQ_REG_UV_TRIP, (uint8_t)((uv_adc >> 4) & 0xFF));
}
 /**
  * @file   BQ_ConfigProtection
  * @brief  配置三级保护寄存器：
  *         PROTECT1：RSNS + 短路(SCD)阈值与延时
  *         PROTECT2：放电过流(OCD)阈值与延时
  *         PROTECT3：过压/欠压延时
  *         最后再写 OV_TRIP / UV_TRIP
  * @param  无（参数全部来自 bms_config.h）
  * @retval 无
  */
void BQ_ConfigProtection(void)
{
    uint8_t p1 = ((BMS_RSNS_BIT & 0x01U) << 7)                 /* RSNS */
               | ((BMS_SCD_DELAY_CODE & 0x03U) << 3)           /* SCD_D[1:0] */
               | (BMS_SCD_THRESH_CODE & 0x07U);                /* SCD_T[2:0] */
    uint8_t p2 = ((BMS_OCD_DELAY_CODE & 0x07U) << 4)           /* OCD_D[2:0] */
               | (BMS_OCD_THRESH_CODE & 0x0FU);                /* OCD_T[3:0] */
    uint8_t p3 = ((BMS_UV_DELAY_CODE & 0x03U) << 6)            /* UV_D[1:0] */
               | ((BMS_OV_DELAY_CODE & 0x03U) << 4);           /* OV_D[1:0] */

    wr8(BQ_REG_PROTECT1, p1);
    wr8(BQ_REG_PROTECT2, p2);
    wr8(BQ_REG_PROTECT3, p3);      /* bit3:0 保留，保持 0 */

    BQ_SetOvUvTrip(BMS_CELL_OV_MV, BMS_CELL_UV_MV);
}
 /**
  * @file   BQ_EnterShipMode
  * @brief  进入 SHIP 低功耗模式（先把两个 MOS 关掉，再按 SHUT_A/SHUT_B 时序写 SYS_CTRL1）
  * @param  无
  * @retval 无
  */
void BQ_EnterShipMode(void)
{
    /* 进入 SHIP：先把 CHG/DSG 关掉，再按 SHUT_A / SHUT_B 时序进入。
     * 注意保留 ADC_EN / TEMP_SEL（否则唤醒后 ADC 未使能，OV/UV 保护不工作）。 */
    BQ_SetFets(false, false);
    HAL_Delay(10U);

#if (BMS_SHIP_SEQ_ORDER == 0U)
    wr8(BQ_REG_SYS_CTRL1, (uint8_t)(BQ_CTRL1_NORMAL | BQ_CTRL1_SHUT_A));   /* 0x1A */
    HAL_Delay(1U);
    wr8(BQ_REG_SYS_CTRL1,
        (uint8_t)(BQ_CTRL1_NORMAL | BQ_CTRL1_SHUT_A | BQ_CTRL1_SHUT_B));   /* 0x1B */
#else
    wr8(BQ_REG_SYS_CTRL1, (uint8_t)(BQ_CTRL1_NORMAL | BQ_CTRL1_SHUT_B));   /* 0x19 */
    HAL_Delay(1U);
    wr8(BQ_REG_SYS_CTRL1, (uint8_t)(BQ_CTRL1_NORMAL | BQ_CTRL1_SHUT_A));   /* 0x1A */
#endif
}
