/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_soc.c
 * 描述    ：电量（SOC）估算实现：以 BQ76920 的硬件库仑计为主，静置时用 OCV 修正
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 无（算法模块）
 * 参考手册: BQ76920 库仑计章节
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_soc.h"
#include "bq76920.h"
#include <string.h>

Soc_Info_t g_soc;

/* 充电为正：正电荷累加、负电荷累减，统一用 int64 nAh 避免浮点漂移 */
static int64_t s_remain_nah;          /* 剩余电量   (nAh) */
static int64_t s_cap_nah;             /* 当前容量   (nAh) */
static int64_t s_q_since_full_nah;    /* 自上次满充以来的净放出电量（用于学容量） */
static int64_t s_q_since_empty_nah;   /* 自上次放空以来的净充入电量 */
static bool    s_seen_full;
static bool    s_seen_empty;
static bool    s_charging;
/* ★ s_aligned：SOC 是否已经对齐到真实值。
 *   上电瞬间它是 false —— 此时 BMS 确实"不知道"电量，g_soc.valid 也是 false，
 *   soc_pct 里的数字只是内部运算的中间量，调用方必须按 SOC_STATE_UNKNOWN 处理
 *   （LED 不亮电量条、仪表不显示具体数字），绝不允许拿它当真实电量展示。
 *   以下任一条发生时置 true：
 *     · 从 EEPROM 载入了掉电前存的电量（Soc_SetInitialSoc）→ RESTORED
 *     · 上电快速 OCV 对齐成功（Soc_OnBootOcv）            → OCV_ALIGNED
 *     · 判定满充 / 放空（Soc_MarkFull / Soc_MarkEmpty，这两个事件本身就是绝对基准）
 *     · 满足 30min 静置条件（Soc_OnRest）
 *   在它为 false 期间，上层（LED / CAN / 串口）应当把 SOC 当作"未校准"看待。 */
static bool    s_aligned;

/* ★ s_state：SOC 可信度来源分级，供上层区分"不确定"与"确定" */
static Soc_State_t s_state = SOC_STATE_UNKNOWN;

/* ★ s_cold_boot：本次上电是否为"待测电芯确认的冷启动"（由 App 在初始化时告知）。
 *   它只影响提示语义（是"电量未知"还是"确认冷启动、电量未知"），
 *   不影响算法本身 —— 两者都不能凭空造一个 SOC 出来。 */
static bool    s_cold_boot;

/* 单体 OCV → SOC 表（LiFePO4；换三元电池请重做此表） */
typedef struct { uint16_t mv; uint8_t soc; } OcvPoint_t;
static const OcvPoint_t s_ocv[] = {
    { 3400U, 100U }, { 3360U, 97U }, { 3340U, 90U }, { 3325U, 80U },
    { 3315U, 70U },  { 3308U, 60U }, { 3300U, 50U }, { 3292U, 40U },
    { 3285U, 30U },  { 3275U, 20U }, { 3262U, 12U }, { 3240U, 7U },
    { 3180U, 3U },   { 3000U, 0U }
};
#define OCV_TBL_LEN (sizeof(s_ocv) / sizeof(s_ocv[0]))
 /**
  * @file   ocv_to_soc
  * @brief  （内部函数）单体开路电压 → SOC 查表插值（LiFePO4 平台平坦，仅作辅助修正）
  * @param  cell_mv 单体电压 mV
  * @retval SOC 百分比
  */
static float ocv_to_soc(uint16_t cell_mv)
{
    uint32_t i;
    if (cell_mv >= s_ocv[0].mv) {
        return 100.0f;
    }
    for (i = 1U; i < OCV_TBL_LEN; i++) {
        if (cell_mv >= s_ocv[i].mv) {
            uint16_t v_hi = s_ocv[i - 1U].mv;
            uint16_t v_lo = s_ocv[i].mv;
            uint8_t  s_hi = s_ocv[i - 1U].soc;
            uint8_t  s_lo = s_ocv[i].soc;
            float k = (float)(cell_mv - v_lo) / (float)(v_hi - v_lo);
            return (float)s_lo + k * (float)(s_hi - s_lo);
        }
    }
    return 0.0f;
}

/* 每 LSB 折算成多少 nAh（Ah × 1e9）
 * @1mΩ、250ms 窗口：8.44mA × 250ms = 0.5861 µAh = 586.1 nAh               */
 /**
  * @file   cc_lsb_to_nah
  * @brief  把库仑计 1 个 LSB 折算成电荷 nAh：8.44mA × 250ms = 586.1nAh（@1mΩ）
  * @param  无
  * @retval 电荷 nAh/LSB
  */
static float cc_lsb_to_nah(void)
{
    float i_lsb_a = BQ_GetCcLsbA();                          /* A / LSB */
    float win_h   = BMS_CC_WINDOW_MS / 3600000.0f;           /* ms → h */
    return i_lsb_a * win_h * 1.0e9f;
}
 /**
  * @file   soc_refresh
  * @brief  （内部函数）把内部 nAh 累加值刷新成对外的 SOC% 与剩余容量，并做上下限保护
  * @param  无
  * @retval 无
  */
static void soc_refresh(void)
{
    if (s_cap_nah <= 0) {
        s_cap_nah = (int64_t)(BMS_CAPACITY_AH * 1.0e9f);
    }
    if (s_remain_nah < 0) {
        s_remain_nah = 0;
    }
    if (s_remain_nah > s_cap_nah) {
        s_remain_nah = s_cap_nah;
    }
    g_soc.soc_pct   = (float)s_remain_nah * 100.0f / (float)s_cap_nah;
    g_soc.remain_ah = (float)s_remain_nah / 1.0e9f;
    g_soc.capacity_ah = (float)s_cap_nah / 1.0e9f;
}
 /**
  * @file   Soc_Init
  * @brief  SOC 模块初始化。★ 上电时真实电量是未知的，本函数不猜、不填占位值：
  *         它把 SOC 置为 UNKNOWN（valid=false、s_aligned=false），
  *         s_remain_nah 里的数字只是内部运算的起点，调用方禁止当作真实电量使用。
  *         随后由 App 层用下面两条路之一把它变成真实值：
  *           · Soc_SetInitialSoc() —— EEPROM 掉电记录（最准，不受极化影响）
  *           · Soc_OnBootOcv()     —— 冷启动静置稳定后按 OCV 对齐
  * @param  capacity_ah 电池额定容量 Ah
  * @retval 无
  */
void Soc_Init(float capacity_ah)
{
    memset(&g_soc, 0, sizeof(g_soc));
    g_soc.rated_ah = capacity_ah;
    s_cap_nah = (int64_t)(capacity_ah * 1.0e9f);
    /* ★ 这里不写 50% 之类的占位数字：真实电量未知就是未知。
       0 只是"还没开始积分"的内部起点，对外由 valid/state 标记为不可信。 */
    s_remain_nah = 0;
    s_q_since_full_nah  = 0;
    s_q_since_empty_nah = 0;
    s_seen_full = false;
    s_seen_empty = false;
    s_charging  = false;
    s_aligned   = false;
    s_state     = SOC_STATE_UNKNOWN;
    g_soc.valid = false;
    soc_refresh();
}
 /**
  * @file   Soc_NotifyColdBoot
  * @brief  由 App 层在初始化时告知"本次上电是否为待测电芯确认的冷启动"。
  *         冷启动 = 系统此前处于彻底断电状态，RAM 里的电量信息全部丢失，
  *         通常意味着换电池/长期搁置，是"必须重新对齐 SOC"最强的硬件证据。
  * @param  cold true=冷启动
  * @retval 无
  */
void Soc_NotifyColdBoot(bool cold)
{
    s_cold_boot = cold;
}
 /**
  * @file   Soc_SetInitialSoc
  * @brief  用掉电保存的电量设定上电初值（★ 上电显示真实电量的第一条路径）。
  *         这条路不经过 OCV，所以不受极化电压影响，是三者中最准的。
  * @param  soc_pct 掉电前的 SOC 百分比 0~100
  * @retval 无
  */
void Soc_SetInitialSoc(float soc_pct)
{
    if (soc_pct < 0.0f) {
        soc_pct = 0.0f;
    }
    if (soc_pct > 100.0f) {
        soc_pct = 100.0f;
    }
    if (s_cap_nah <= 0) {
        s_cap_nah = (int64_t)(BMS_CAPACITY_AH * 1.0e9f);
    }
    s_remain_nah = (int64_t)((float)s_cap_nah * soc_pct / 100.0f);
    s_aligned = true;
    s_state   = SOC_STATE_RESTORED;
    g_soc.valid = true;
    /* 注意：这里不改 s_seen_full / s_seen_empty。
     * 掉电恢复的只是一个数，并没有"走完一整段充放电"，不能当作学习依据。 */
    soc_refresh();
}
 /**
  * @file   Soc_OnBootOcv
  * @brief  上电快速 OCV 对齐（★ 上电显示真实电量的第二条路径）。
  *         由 App 层在"电流接近 0 且电压稳定"时调用，不必等 30 分钟静置。
  *
  *         三种情形的处理：
  *           ① 从未对齐过（首次上电、EEPROM 无记录）→ 直接采信 OCV
  *           ② 与已有记录差异 > BMS_OCV_BOOT_SNAP_PCT
  *              → 认为记录不可信（换过电池 / 长期搁置自放电 / 掉电过久），
  *                物理量优先，直接采信 OCV
  *           ③ 差异不大 → 按 BMS_OCV_BOOT_WEIGHT 融合（比 30min 慢修正的 0.1 激进）
  *
  *         ★ 为什么权重能比慢修正大：慢修正是在"运行中"做的，电压随时会被
  *           负载扰动；而本函数的前提是"已确认静置且电压稳定"，此时端电压
  *           就是 OCV，可信度高得多。
  * @param  avg_cell_mv 当前平均单体电压 mV
  * @retval true 已对齐（本次一定生效）
  */
bool Soc_OnBootOcv(uint16_t avg_cell_mv)
{
    float ocv_soc = ocv_to_soc(avg_cell_mv);
    float now     = g_soc.soc_pct;
    float diff    = ocv_soc - now;

    if (!s_aligned) {
        s_remain_nah = (int64_t)((float)s_cap_nah * ocv_soc / 100.0f);
        s_aligned = true;
        s_state   = SOC_STATE_OCV_ALIGNED;
        g_soc.valid = true;
    } else if (diff > BMS_OCV_BOOT_SNAP_PCT || diff < -BMS_OCV_BOOT_SNAP_PCT) {
        s_remain_nah = (int64_t)((float)s_cap_nah * ocv_soc / 100.0f);
    } else {
        float blended = now + BMS_OCV_BOOT_WEIGHT * diff;
        s_remain_nah = (int64_t)((float)s_cap_nah * blended / 100.0f);
    }
    soc_refresh();
    return true;
}
 /**
  * @file   Soc_IsAligned
  * @brief  查询 SOC 是否已对齐到真实值
  * @param  无
  * @retval true=SOC 可信；false=真实电量未知（内部数字不具物理意义，禁止显示）
  */
bool Soc_IsAligned(void)
{
    return s_aligned;
}
 /**
  * @file   Soc_GetState
  * @brief  取 SOC 可信度分级，供上层决定"能不能显示具体数字"
  * @param  无
  * @retval SOC_STATE_UNKNOWN / SOC_STATE_RESTORED / SOC_STATE_OCV_ALIGNED
  */
Soc_State_t Soc_GetState(void)
{
    return s_state;
}
 /**
  * @file   Soc_IsColdBoot
  * @brief  查询本次上电是否为待测电芯确认的冷启动
  * @param  无
  * @retval true=冷启动（此前彻底断电，电量信息全部丢失）
  */
bool Soc_IsColdBoot(void)
{
    return s_cold_boot;
}
 /**
  * @file   Soc_GetPermille
  * @brief  取 SOC 千分比，供掉电保存使用
  * @param  无
  * @retval 0~1000
  */
uint16_t Soc_GetPermille(void)
{
    float p = g_soc.soc_pct;
    if (p < 0.0f) {
        p = 0.0f;
    }
    if (p > 100.0f) {
        p = 100.0f;
    }
    return (uint16_t)(p * 10.0f + 0.5f);
}
 /**
  * @file   Soc_SetCapacity
  * @brief  手动设置电池容量（比例如用户改容量或从 EEPROM 载入时），剩余电量按比例保留
  * @param  capacity_ah 新的容量 Ah
  * @retval 无
  */
void Soc_SetCapacity(float capacity_ah)
{
    if (capacity_ah < 0.1f) {
        return;
    }
    float ratio = (s_cap_nah > 0) ? ((float)s_remain_nah / (float)s_cap_nah) : 0.5f;
    s_cap_nah = (int64_t)(capacity_ah * 1.0e9f);
    s_remain_nah = (int64_t)((float)s_cap_nah * ratio);
    g_soc.rated_ah = capacity_ah;
    soc_refresh();
}
 /**
  * @file   Soc_NotifyCharging
  * @brief  告知当前是否处于充电方向（满充判定要用）
  * @param  charging true=充电中
  * @retval 无
  */
void Soc_NotifyCharging(bool charging)
{
    s_charging = charging;
}
 /**
  * @file   Soc_OnCcSample
  * @brief  库仑计采样回调（App 每 250ms 调用一次）：
  *         充电时对电荷打库仑效率折扣后累加，放电时扣除；
  *         同时分别为"满充学习"和"放空学习"累计电量
  * @param  cc_raw 本次库仑计读数（LSB，有符号）
  * @retval 无
  */
void Soc_OnCcSample(int16_t cc_raw)
{
    int32_t q_nah = (int32_t)((float)cc_raw * cc_lsb_to_nah());

    /* 充电时按库仑效率打折（充进去的电荷并非全部可放出） */
    if (q_nah > 0) {
        q_nah = (int32_t)((float)q_nah * BMS_COULOMB_EFF);
        s_q_since_empty_nah += q_nah;
    } else {
        s_q_since_full_nah += -(int64_t)q_nah;
    }

    s_remain_nah += q_nah;
    soc_refresh();
}
 /**
  * @file   Soc_OnRest
  * @brief  静置修正：用 OCV 查表结果修正当前 SOC。
  *         未对齐过 → 直接采用 OCV；已对齐过 → 小权重加权
  *         （LiFePO4 平台平坦，运行中权重取 0.1）。
  * @param  avg_cell_mv 当前平均单体电压 mV
  * @retval 无
  */
void Soc_OnRest(uint16_t avg_cell_mv)
{
    float ocv_soc = ocv_to_soc(avg_cell_mv);
    float now = g_soc.soc_pct;

    if (!s_aligned) {                       /* 首次对齐：直接采用 OCV 结果 */
        s_remain_nah = (int64_t)((float)s_cap_nah * ocv_soc / 100.0f);
        s_aligned = true;
        s_state   = SOC_STATE_OCV_ALIGNED;
        g_soc.valid = true;
    } else {
        float blended = now + BMS_OCV_WEIGHT * (ocv_soc - now);
        s_remain_nah = (int64_t)((float)s_cap_nah * blended / 100.0f);
    }
    soc_refresh();
}
 /**
  * @file   learn_capacity
  * @brief  （内部函数）用一次完整循环反推可用容量（粗粒度 SOH）：
  *         与旧值按 7:3 平滑，并限幅在额定容量的 30%~150%
  * @param  measured_nah 本次实测到的电量 nAh
  * @retval 无
  */
static void learn_capacity(int64_t measured_nah)
{
    if (measured_nah < (int64_t)(0.3f * BMS_CAPACITY_AH * 1.0e9f)) {
        return;                             /* 数据太短，不采信 */
    }
    float cand = (float)measured_nah / 1.0e9f;
    float old  = (float)s_cap_nah / 1.0e9f;
    float newc = old * 0.7f + cand * 0.3f;  /* 平滑，避免单次异常把容量带偏 */

    /* 限幅在额定值的 30%~150% */
    if (newc < 0.3f * BMS_CAPACITY_AH) { newc = 0.3f * BMS_CAPACITY_AH; }
    if (newc > 1.5f * BMS_CAPACITY_AH) { newc = 1.5f * BMS_CAPACITY_AH; }

    g_soc.learned_ah = cand;
    s_cap_nah = (int64_t)(newc * 1.0e9f);
    Soc_SaveCapacityCb(newc);
}
 /**
  * @file   Soc_MarkFull
  * @brief  满充判定：SOC 强制归 100%，若此前经历过放空则顺便学习容量，满充次数 +1
  * @param  无
  * @retval 无
  */
void Soc_MarkFull(void)
{
    if (s_seen_empty) {                     /* 走完 空→满 的整段，学习容量 */
        learn_capacity(s_q_since_empty_nah);
    }
    s_remain_nah = s_cap_nah;
    s_q_since_full_nah = 0;
    s_q_since_empty_nah = 0;
    s_seen_full = true;
    s_aligned = true;                       /* 满充是绝对基准，SOC 由此对齐 */
    s_state   = SOC_STATE_RESTORED;         /* 由已知绝对基准确定，等同"可信" */
    g_soc.full_flag = true;
    g_soc.valid = true;
    g_soc.charge_count++;
    soc_refresh();
}
 /**
  * @file   Soc_MarkEmpty
  * @brief  放空判定：SOC 强制归 0%，若此前经历过满充则顺便学习容量
  * @param  无
  * @retval 无
  */
void Soc_MarkEmpty(void)
{
    if (s_seen_full) {                      /* 走完 满→空 的整段，学习容量 */
        learn_capacity(s_q_since_full_nah);
    }
    s_remain_nah = 0;
    s_q_since_empty_nah = 0;
    s_q_since_full_nah = 0;
    s_seen_empty = true;
    s_aligned = true;                       /* 放空是绝对基准，SOC 由此对齐 */
    s_state   = SOC_STATE_RESTORED;         /* 由已知绝对基准确定，等同"可信" */
    g_soc.full_flag = false;
    g_soc.valid = true;
    soc_refresh();
}
 /**
  * @file   Soc_GetPercent
  * @brief  取当前电量百分比
  * @param  无
  * @retval SOC 0~100
  */
float Soc_GetPercent(void)  { return g_soc.soc_pct; }
 /**
  * @file   Soc_GetRemainAh
  * @brief  取当前剩余容量
  * @param  无
  * @retval 剩余 Ah
  */
float Soc_GetRemainAh(void) { return g_soc.remain_ah; }
 /**
  * @file   Soc_SaveCapacityCb
  * @brief  容量学习回调（重写 bms_soc.c 里的弱函数）：把学到的容量写入 AT24C02
  * @param  capacity_ah 学到的容量 Ah
  * @retval 无
  */
__weak void Soc_SaveCapacityCb(float capacity_ah)
{
    (void)capacity_ah;      /* 需要掉电保存时，在此写入 AT24C02 */
}
