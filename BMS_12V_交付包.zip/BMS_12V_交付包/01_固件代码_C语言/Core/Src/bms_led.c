/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_led.c
 * 描述    ：LED 电量条实现：5 颗灯对应 5 档电量，含低电量闪烁与故障 3 连闪（非阻塞）
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: LED1=PB1; LED2=PB0; LED3=PA7; LED4=PA6; LED5=PA4(红)
 * 参考手册: 无
 * 驱动方式: LED 阳极接 MCU 口、阴极经 470Ω 到 GND，输出高电平点亮
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_led.h"

typedef struct { GPIO_TypeDef *port; uint16_t pin; } LedPin_t;

/* 顺序即点亮顺序：1 颗=20%，2 颗=40% …… 5 颗=100% */
static const LedPin_t s_led[BMS_LED_COUNT] = {
    { GPIOB, GPIO_PIN_1 },   /* LED1 20%  绿 */
    { GPIOB, GPIO_PIN_0 },   /* LED2 40%  绿 */
    { GPIOA, GPIO_PIN_7 },   /* LED3 60%  绿 */
    { GPIOA, GPIO_PIN_6 },   /* LED4 80%  绿 */
    { GPIOA, GPIO_PIN_4 }    /* LED5 100% 红 */
};

static Led_Mode_t s_mode = LED_MODE_SOC;
static uint8_t    s_mask = 0U;
static uint8_t    s_lit  = 0U;
static uint16_t   s_tick = 0U;        /* 10ms 计数 */
static uint8_t    s_phase = 0U;
 /**
  * @file   write_mask
  * @brief  （内部函数）把掩码直接写到 5 个 LED 引脚，并统计亮灯数量
  * @param  mask bit0=LED1 … bit4=LED5
  * @retval 无
  */
static void write_mask(uint8_t mask)
{
    uint8_t i;
    for (i = 0U; i < BMS_LED_COUNT; i++) {
        GPIO_PinState st = ((mask >> i) & 0x01U) ? GPIO_PIN_SET : GPIO_PIN_RESET;
        HAL_GPIO_WritePin(s_led[i].port, s_led[i].pin, st);
    }
    s_lit = 0U;
    for (i = 0U; i < BMS_LED_COUNT; i++) {
        if ((mask >> i) & 0x01U) { s_lit++; }
    }
}
 /**
  * @file   Led_Init
  * @brief  LED 初始化：全部熄灭，进入"按电量显示"模式
  * @param  无
  * @retval 无
  */
void Led_Init(void)
{
    write_mask(0x00U);
    s_mode = LED_MODE_SOC;
    s_tick = 0U;
    s_phase = 0U;
}
 /**
  * @file   Led_SetMode
  * @brief  切换 LED 显示模式（电量条 / 指定掩码 / 故障 / 低电量 / 全灭）
  * @param  mode 显示模式
  * @retval 无
  */
void Led_SetMode(Led_Mode_t mode)
{
    s_mode = mode;
    s_tick = 0U;
}
 /**
  * @file   Led_ShowPercent
  * @brief  按电量百分比点亮对应数量的 LED：每 20% 一颗，
  *         电量 >0% 时至少亮 1 颗，100% 时 5 颗全亮
  * @param  soc_pct 电量百分比 0~100
  * @retval 无
  */
void Led_ShowPercent(float soc_pct)
{
    uint8_t n;

    if (soc_pct <= 0.0f) {
        n = 0U;
    } else {
        n = (uint8_t)(soc_pct / 20.0f);          /* 向下取整 */
        if (n == 0U) { n = 1U; }                 /* 0~20% 之间仍亮 1 颗 */
        if (n > BMS_LED_COUNT) { n = BMS_LED_COUNT; }
    }

    s_mask = (uint8_t)((1U << n) - 1U);
    write_mask(s_mask);
}
 /**
  * @file   Led_ShowMask
  * @brief  按指定掩码点亮 LED（bit0=LED1 … bit4=LED5）
  * @param  mask 掩码
  * @retval 无
  */
void Led_ShowMask(uint8_t mask)
{
    s_mask = (uint8_t)(mask & 0x1FU);
    write_mask(s_mask);
}
 /**
  * @file   Led_AllOff
  * @brief  全部熄灭
  * @param  无
  * @retval 无
  */
void Led_AllOff(void)
{
    s_mask = 0U;
    write_mask(0U);
}
 /**
  * @file   Led_GetLitCount
  * @brief  取当前点亮的 LED 数量
  * @param  无
  * @retval 亮灯数 0~5
  */
uint8_t Led_GetLitCount(void) { return s_lit; }
 /**
  * @file   Led_Task
  * @brief  LED 动画任务（App 每 10ms 调用一次）：
  *         电量条模式常亮；低电量模式整体 1Hz 闪烁；故障模式 3 连闪（非阻塞）
  * @param  无
  * @retval 无
  */
void Led_Task(void)
{
    s_tick++;                                   /* 由 App 每 10ms 调用 */

    switch (s_mode) {
    case LED_MODE_SOC:
    case LED_MODE_MASK:
        write_mask(s_mask);                     /* 常亮，不需要动画 */
        break;

    case LED_MODE_LOW_BAT:
        /* 1Hz 整体闪烁：低电量告警 */
        if (s_tick >= 50U) { s_tick = 0U; s_phase ^= 1U; }
        write_mask(s_phase ? s_mask : 0x00U);
        break;

    case LED_MODE_CALIBRATING:
        /* ★ 电量未知：单颗灯 300ms 一档向右流动（跑马灯）。
         *   绝不停在固定档数上 —— 固定档数会被当成"真实电量"读走，
         *   而此刻 BMS 确实不知道电量。转圈表示"正在确定"。 */
        if (s_tick >= 30U) {
            s_tick = 0U;
            s_phase = (uint8_t)((s_phase + 1U) % BMS_LED_COUNT);
        }
        write_mask((uint8_t)(1U << s_phase));
        break;

    case LED_MODE_FAULT:
        /* 每 2s 内 3 连闪（亮 200ms、灭 200ms ×3，然后长灭） */
        if (s_tick >= 200U) {
            s_tick = 0U;
            s_phase++;
            if (s_phase >= 10U) { s_phase = 0U; s_tick = 0U; }
        }
        write_mask(((s_phase % 2U) == 0U && s_phase < 6U) ? 0x1FU : 0x00U);
        break;

    case LED_MODE_ALL_OFF:
    default:
        write_mask(0x00U);
        break;
    }
}
