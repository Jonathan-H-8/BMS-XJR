/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_debug.c
 * 描述    ：串口日志实现：不依赖 printf 重定向，直接用 HAL 发送
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: PA9=USART1_TX; PA10=USART1_RX，115200 8N1
 * 参考手册: 无
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_debug.h"
#include "bq76920.h"
#include "bms_soc.h"
#include "bms_protect.h"
#include "bms_balance.h"
#include "bms_led.h"
#include "bms_cells.h"
#include "bms_temp.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef BMS_UART;
 /**
  * @file   BMS_Log
  * @brief  串口格式化打印（内部用 vsnprintf 组包后直接 HAL 发送，不依赖 printf 重定向）
  * @param  fmt 格式串; ... 可变参数
  * @retval 无
  */
void BMS_Log(const char *fmt, ...)
{
    char buf[192];
    va_list ap;
    int n;

    va_start(ap, fmt);
    n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    if (n > 0) {
        if ((size_t)n >= sizeof(buf)) { n = (int)sizeof(buf) - 1; }
        (void)HAL_UART_Transmit(&BMS_UART, (uint8_t *)buf, (uint16_t)n, 100U);
    }
}
 /**
  * @file   BMS_PrintStatus
  * @brief  打印完整状态：电压、电流、温度、SOC、FET、均衡、限值、故障、校准值
  * @param  无
  * @retval 无
  */
void BMS_PrintStatus(void)
{
    uint8_t i;
    BMS_Log("\r\n===== BMS for 12V Battery =====\r\n");
    /* ★ 电量未对齐时打印 "UNKNOWN"，不打印数字。
     *   打印数字（哪怕是 50.0）会被人当成真实电量抄走 —— 这正是要修掉的问题。 */
    if (Soc_IsAligned()) {
        BMS_Log("SOC      : %5.1f %%   remain %.3f Ah / cap %.3f Ah   [来源: %s]\r\n",
                g_soc.soc_pct, g_soc.remain_ah, g_soc.capacity_ah,
                (Soc_GetState() == SOC_STATE_RESTORED) ? "EEPROM 掉电记录"
                                                       : "OCV 对齐");
    } else {
        BMS_Log("SOC      : UNKNOWN（电量未确定：%s，等静置电压稳定后由 OCV 对齐）\r\n",
                Soc_IsColdBoot() ? "待测电芯确认冷启动" : "无 EEPROM 记录");
        BMS_Log("           cap %.3f Ah（额定值，仅供参照）\r\n", g_soc.capacity_ah);
    }
    BMS_Log("Pack     : %u mV   Cells(mV):", g_bq.pack_mv);
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        BMS_Log(" %u", g_bq.real_mv[i]);
    }
    BMS_Log("\r\nDelta    : %u mV   (AFE raw:",
            (unsigned)(g_bq.real_max_mv - g_bq.real_min_mv));
    for (i = 0U; i < 5U; i++) {
        BMS_Log(" %u", g_bq.cell_mv[i]);
    }
    BMS_Log(")\r\n");
    BMS_Log("Current  : %+7.3f A   (CC raw %d)\r\n", g_bq.current_a, g_bq.cc_raw);
    BMS_Log("Temp     : %d C（电芯）   分区 %s   传感器 %s\r\n",
            g_bq.temp_c, Temp_ZoneName(g_temp.zone), Temp_SensName(g_temp.sens));
    BMS_Log("  允许    : CHG(温度)=%s  DSG(温度)=%s   采样 %lu 次 / 丢弃 %lu 次\r\n",
            Temp_ChgAllowed() ? "是" : "否", Temp_DsgAllowed() ? "是" : "否",
            (unsigned long)g_temp.samples, (unsigned long)g_temp.rejects);
    BMS_Log("采样回路 : %s   wire_ok=%d   不均衡=%d（压差 %u mV，阈 %u mV）\r\n",
            Cells_ErrName(g_cells.err), (int)g_cells.wire_ok, (int)g_cells.unbalance,
            g_cells.delta_mv, BMS_CELL_DELTA_WARN_MV);
    BMS_Log("FET      : CHG=%s DSG=%s   BAL mask=0x%02X (%s, delta %u mV)\r\n",
            g_prot.chg_allowed ? "ON" : "OFF",
            g_prot.dsg_allowed ? "ON" : "OFF",
            g_bal.mask, g_bal.active ? "run" : "idle", g_bal.delta_mv);
    BMS_Log("Limits   : chg<=%.1f A  dsg<=%.1f A\r\n",
            g_prot.chg_limit_a, g_prot.dsg_limit_a);
    BMS_Log("Fault    : %s   locked=%d  sys_stat=0x%02X\r\n",
            Prot_FaultName(g_prot.fault), (int)g_prot.locked, g_bq.sys_stat);
    BMS_Log("LED      : %u/5 lit\r\n", Led_GetLitCount());
    BMS_Log("Cal      : gain=%u uV/LSB  offset=%d mV\r\n",
            BQ_GetGainUV(), BQ_GetOffsetMV());
    BMS_Log("===============================\r\n");
}
 /**
  * @file   BMS_PrintCsv
  * @brief  打印一帧机器可读数据（供 PC 端实时看板解析），格式：
  *         $BMS,时间ms,组端mV,节1,节2,节3,节4,电流mA,温度C,SOC×10,剩余mAh,容量mAh,CHG,DSG,均衡,故障*XOR
  *         例：$BMS,123456,12840,3210,3205,3212,3213,-1520,25,785,7846,10000,1,1,0,0*3F
  *         说明：SOC 放大 10 倍、容量放大 1000 倍以整数发送，避免浮点和小数点解析问题；
  *              "*" 后面是异或校验（$ 与 * 之间的所有字符逐字节异或），上位机可校验
  * @param  无
  * @retval 无
  */
void BMS_PrintCsv(void)
{
    char    body[192];
    uint8_t x = 0U;
    int     n, i;
    int32_t ma = (int32_t)(g_bq.current_a * 1000.0f);   /* 电流换算成 mA（有符号） */
    /* ★ 电量未对齐时发哨兵值 BMS_SOC_UNKNOWN_X10，而不是随便一个数字。
     *   看板端据此显示"未知 / 正在确定"，不会把占位数字画成真实曲线。 */
    unsigned soc_x10 = Soc_IsAligned() ? (unsigned)(Soc_GetPercent() * 10.0f)
                                       : (unsigned)BMS_SOC_UNKNOWN_X10;

    if (ma > 32000)  { ma = 32000; }
    if (ma < -32000) { ma = -32000; }

    n = snprintf(body, sizeof(body),
                 "%lu,%u,%u,%u,%u,%u,%d,%d,%u,%ld,%ld,%u,%u,%u,%u",
                 (unsigned long)HAL_GetTick(),               /* 1  时间戳 ms      */
                 (unsigned)g_bq.pack_mv,                     /* 2  组端电压 mV    */
                 (unsigned)g_bq.real_mv[0],                  /* 3  第 1 节 mV     */
                 (unsigned)g_bq.real_mv[1],                  /* 4  第 2 节 mV     */
                 (unsigned)g_bq.real_mv[2],                  /* 5  第 3 节 mV     */
                 (unsigned)g_bq.real_mv[3],                  /* 6  第 4 节 mV     */
                 (int)ma,                                    /* 7  电流 mA        */
                 (int)g_bq.temp_c,                           /* 8  温度 ℃         */
                 soc_x10,                                    /* 9  SOC ×10        */
                 (long)(Soc_GetRemainAh() * 1000.0f),        /* 10 剩余容量 mAh   */
                 (long)(g_soc.capacity_ah * 1000.0f),        /* 11 总容量 mAh     */
                 (unsigned)(g_prot.chg_allowed ? 1U : 0U),   /* 12 充电管允许     */
                 (unsigned)(g_prot.dsg_allowed ? 1U : 0U),   /* 13 放电管允许     */
                 (unsigned)g_bal.mask,                       /* 14 均衡掩码       */
                 (unsigned)g_prot.fault);                    /* 15 故障码         */

    if (n <= 0) {
        return;
    }
    if ((size_t)n >= sizeof(body)) {
        n = (int)sizeof(body) - 1;
    }
    for (i = 0; i < n; i++) {
        x ^= (uint8_t)body[i];                              /* 逐字节异或校验 */
    }
    BMS_Log("$BMS,%s*%02X\r\n", body, x);
}

 /**
  * @file   BMS_PrintHelp
  * @brief  打印串口命令帮助
  * @param  无
  * @retval 无
  */
void BMS_PrintHelp(void)
{
    BMS_Log("\r\n命令列表：\r\n"
            "  ?                  打印完整状态\r\n"
            "  SET CHG <A>        设置最大充电电流 (A)\r\n"
            "  SET DSG <A>        设置最大放电电流 (A)\r\n"
            "  CAP <Ah>           设置电池容量\r\n"
            "  CLR                清除故障并解锁\r\n"
            "  BAL <0|1>         0=停止均衡  1=允许均衡\r\n"
            "  CELL               打印单体电压检测详情（逐节读数/级别/压差/采样回路结论）\r\n"
            "  TEMP               打印温度检测详情（TS1 电压/NTC 阻值/温度/分区/传感器状态）\r\n"
            "  TEMP DIE           读一次 AFE 芯片内部温度（仅看板级温升，非电芯温度）\r\n"
            "  CELLDIAG           采样线开路自检（需静置，约 5.4s，期间均衡暂停）\r\n"
            "  MON <0|1>          0=停止  1=每秒自动推送一帧 $BMS 数据（配合 PC 端看板看容量）\r\n"
            "  FET <c> <d>        手动控制 FET（调试用）\r\n"
            "  SHIP               进入 SHIP 低功耗模式\r\n");
}
