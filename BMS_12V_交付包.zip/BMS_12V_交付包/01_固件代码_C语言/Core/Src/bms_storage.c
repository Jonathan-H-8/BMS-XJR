/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_storage.c
 * 描述    ：参数掉电保存实现：AT24C02 页写 + magic/版本 + CRC16 校验
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: AT24C02：I2C 地址 0x50，与 AFE 共用 PB6/PB7
 * 参考手册: AT24C02 数据手册
 * 地址说明: U4=AT24C02，A0/A1/A2 接地 → 器件地址 0x50，WP 接地 → 允许写入
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_storage.h"
#include "bms_debug.h"
#include "bq76920.h"
#include <string.h>

#define EEPROM_ADDR8       (0x50U << 1)   /* AT24C02 7bit 0x50 */
#define EEPROM_MAGIC0      'B'
#define EEPROM_MAGIC1      'M'
#define EEPROM_MAGIC2      'S'
#define EEPROM_MAGIC3      '4'
/* ★ V0x02：BmsParam_t 里新增了 SOC 相关字段（soc_permille 等），结构体长度变了。
 *   长度在 hdr[5] 里参与校验，所以必须升版本 —— 否则老数据会被当成"长度不符"
 *   而全部回落到默认值。升版本后第一次上电等效于"新板"，会重新写入一份。 */
#define EEPROM_VERSION     0x02U
#define EEPROM_BASE        0x00U
#define EEPROM_PAGE        8U              /* 页写边界 8 字节 */
#define EEPROM_WRITE_MS    6U              /* 写周期留余量 */

BmsParam_t g_param;
bool       g_param_loaded = false;

extern I2C_HandleTypeDef BQ_I2C;            /* 与 BQ76920 共用 I2C1 */
 /**
  * @file   crc16
  * @brief  （内部函数）CRC16-CCITT 校验（多项式 0x1021，初值 0xFFFF）
  * @param  buf 数据; len 长度
  * @retval CRC16 值
  */
static uint16_t crc16(const uint8_t *buf, uint16_t len)
{
    uint16_t crc = 0xFFFFU;
    uint16_t i;
    uint8_t  b;

    for (i = 0U; i < len; i++) {
        crc ^= (uint16_t)buf[i] << 8;
        for (b = 0U; b < 8U; b++) {
            crc = (crc & 0x8000U) ? (uint16_t)((crc << 1) ^ 0x1021U) : (uint16_t)(crc << 1);
        }
    }
    return crc;
}
 /**
  * @file   ee_read
  * @brief  （内部函数）AT24C02 随机读
  * @param  mem 片内地址; buf 缓冲; len 字节数
  * @retval HAL_OK 成功
  */
static HAL_StatusTypeDef ee_read(uint8_t mem, uint8_t *buf, uint16_t len)
{
    return HAL_I2C_Mem_Read(&BQ_I2C, EEPROM_ADDR8, mem, I2C_MEMADD_SIZE_8BIT,
                            buf, len, BQ_I2C_TIMEOUT_MS);
}
 /**
  * @file   ee_write
  * @brief  （内部函数）AT24C02 页写。AT24C02 页大小 8 字节且写不会跨页回卷，
  *         所以这里按页边界拆成多次写，每次写完等 6ms（tWR ≤ 5ms）
  * @param  mem 片内地址; buf 数据; len 字节数
  * @retval HAL_OK 成功
  */
static HAL_StatusTypeDef ee_write(uint8_t mem, const uint8_t *buf, uint16_t len)
{
    uint16_t done = 0U;

    while (done < len) {
        uint16_t room = EEPROM_PAGE - ((mem + done) % EEPROM_PAGE);   /* 本页还能写几字节 */
        uint16_t n = (uint16_t)((len - done) < room ? (len - done) : room);

        if (HAL_I2C_Mem_Write(&BQ_I2C, EEPROM_ADDR8, (uint8_t)(mem + done),
                              I2C_MEMADD_SIZE_8BIT, (uint8_t *)(buf + done), n,
                              BQ_I2C_TIMEOUT_MS) != HAL_OK) {
            return HAL_ERROR;
        }
        HAL_Delay(EEPROM_WRITE_MS);          /* 等本次页写完成（tWR ≤ 5ms） */
        done = (uint16_t)(done + n);
        if (done >= 256U) { break; }
    }
    return HAL_OK;
}
 /**
  * @file   Sto_Init
  * @brief  探测 AT24C02 是否在线（只寻址，不读写数据）
  * @param  无
  * @retval HAL_OK 存在
  */
HAL_StatusTypeDef Sto_Init(void)
{
    /* 只做寻址探测，不读写，避免误动数据 */
    return HAL_I2C_IsDeviceReady(&BQ_I2C, EEPROM_ADDR8, 3U, 100U);
}
 /**
  * @file   Sto_LoadDefaults
  * @brief  把配置默认值填进参数结构体（EEPROM 空白或校验失败时使用）
  * @param  p 参数结构体指针
  * @retval 无
  */
void Sto_LoadDefaults(BmsParam_t *p)
{
    memset(p, 0, sizeof(*p));
    p->capacity_ah   = BMS_CAPACITY_AH;
    p->learned_ah    = 0.0f;
    p->chg_limit_a   = BMS_CHARGE_MAX_A;
    p->dsg_limit_a   = BMS_DISCHARGE_MAX_A;
    p->ov_mv         = BMS_CELL_OV_MV;
    p->uv_mv         = BMS_CELL_UV_MV;
    p->temp_chg_max  = (uint8_t)BMS_TEMP_CHG_MAX;
    p->temp_dsg_max  = (uint8_t)BMS_TEMP_DSG_MAX;
    p->bal_enable    = 1U;
    p->charge_count  = 0U;
    p->run_seconds   = 0U;
    /* ★ 默认 SOC 记录标记为"不可信"：没存过就不要拿去用，
     *   否则会用 0% 冒充真实电量，比 50% 起步还糟。
     *   调用方看到 soc_valid==0 会改走上电快速 OCV 对齐。 */
    p->soc_permille  = 0U;
    p->soc_valid     = 0U;
    p->soc_saved_s   = 0U;
}
 /**
  * @file   Sto_Load
  * @brief  从 EEPROM 读参数：校验 magic + 版本 + 长度 + CRC16，
  *         任一项不对就返回错误并由调用方使用默认值（不会因为半写坏数据把设备带死）
  * @param  p 参数结构体指针
  * @retval HAL_OK 读取并校验成功；HAL_ERROR 用默认值
  */
HAL_StatusTypeDef Sto_Load(BmsParam_t *p)
{
    uint8_t  hdr[6];
    uint8_t  payload[sizeof(BmsParam_t)];
    uint8_t  tail[2];
    uint16_t crc_calc, crc_stored;

    Sto_LoadDefaults(p);

    if (Sto_Init() != HAL_OK) {
        return HAL_ERROR;                       /* 没焊 EEPROM 也不影响运行 */
    }
    if (ee_read(EEPROM_BASE, hdr, sizeof(hdr)) != HAL_OK) {
        return HAL_ERROR;
    }
    if (hdr[0] != EEPROM_MAGIC0 || hdr[1] != EEPROM_MAGIC1 ||
        hdr[2] != EEPROM_MAGIC2 || hdr[3] != EEPROM_MAGIC3) {
        return HAL_ERROR;                       /* 出厂空白或首次上电 */
    }
    if (hdr[4] != EEPROM_VERSION) {
        return HAL_ERROR;                       /* 版本不匹配，用默认值并等待覆盖 */
    }
    if (hdr[5] != (uint8_t)sizeof(BmsParam_t)) {
        return HAL_ERROR;
    }
    if (ee_read((uint8_t)(EEPROM_BASE + 6U), payload, sizeof(payload)) != HAL_OK) {
        return HAL_ERROR;
    }
    if (ee_read((uint8_t)(EEPROM_BASE + 6U + sizeof(payload)), tail, 2U) != HAL_OK) {
        return HAL_ERROR;
    }
    crc_stored = (uint16_t)(((uint16_t)tail[0] << 8) | tail[1]);
    crc_calc   = crc16(payload, (uint16_t)sizeof(payload));
    if (crc_stored != crc_calc) {
        return HAL_ERROR;                       /* 数据损坏 */
    }

    memcpy(p, payload, sizeof(*p));
    return HAL_OK;
}
 /**
  * @file   Sto_Save
  * @brief  把参数写入 EEPROM：先组帧再算 CRC16，一次写入（约 15~25ms，含页写等待）
  * @param  p 参数结构体指针
  * @retval HAL_OK 成功
  */
HAL_StatusTypeDef Sto_Save(const BmsParam_t *p)
{
    uint8_t  buf[6 + sizeof(BmsParam_t) + 2];
    uint16_t crc;

    buf[0] = EEPROM_MAGIC0;
    buf[1] = EEPROM_MAGIC1;
    buf[2] = EEPROM_MAGIC2;
    buf[3] = EEPROM_MAGIC3;
    buf[4] = EEPROM_VERSION;
    buf[5] = (uint8_t)sizeof(BmsParam_t);
    memcpy(&buf[6], p, sizeof(*p));
    crc = crc16(buf + 6, (uint16_t)sizeof(*p));
    buf[6 + sizeof(*p)]     = (uint8_t)(crc >> 8);
    buf[6 + sizeof(*p) + 1] = (uint8_t)(crc & 0xFF);

    return ee_write(EEPROM_BASE, buf, (uint16_t)sizeof(buf));
}
 /**
  * @file   Sto_SaveCapacity
  * @brief  只更新容量字段并落盘（供容量学习回调调用）
  * @param  capacity_ah 容量 Ah
  * @retval 无
  */
void Sto_SaveCapacity(float capacity_ah)
{
    g_param.capacity_ah = capacity_ah;
    if (Sto_Save(&g_param) != HAL_OK) {
        BMS_Log("[EE] 容量保存失败\r\n");
    }
}
 /**
  * @file   Sto_Printf
  * @brief  把当前保存的参数打印到串口
  * @param  无
  * @retval 无
  */
void Sto_Printf(void)
{
    BMS_Log("\r\n---- 掉电保存参数 (AT24C02) ----\r\n");
    BMS_Log("  电池容量   : %.3f Ah   (学习值 %.3f Ah)\r\n",
            g_param.capacity_ah, g_param.learned_ah);
    BMS_Log("  充电限流   : %.2f A    放电限流 %.2f A\r\n",
            g_param.chg_limit_a, g_param.dsg_limit_a);
    BMS_Log("  OV / UV    : %u mV / %u mV\r\n", g_param.ov_mv, g_param.uv_mv);
    BMS_Log("  温度上限   : 充 %u C   放 %u C\r\n",
            g_param.temp_chg_max, g_param.temp_dsg_max);
    BMS_Log("  均衡开关   : %s     满充次数 %u\r\n",
            g_param.bal_enable ? "ON" : "OFF", g_param.charge_count);
    BMS_Log("  累计运行   : %lu s\r\n", (unsigned long)g_param.run_seconds);
    /* ★ 掉电时存的电量：上电就是靠它直接显示真实 SOC，而不是固定 50% */
    if (g_param.soc_valid != 0U) {
        BMS_Log("  掉电电量   : %.1f %%  (存于运行 %lu s 时)\r\n",
                (float)g_param.soc_permille / 10.0f,
                (unsigned long)g_param.soc_saved_s);
    } else {
        BMS_Log("  掉电电量   : 无有效记录（上电将由 OCV 对齐）\r\n");
    }
    BMS_Log("------------------------------\r\n");
}
