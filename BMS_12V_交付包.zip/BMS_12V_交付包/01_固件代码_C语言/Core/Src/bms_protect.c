/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_protect.c
 * 描述    ：保护与限流实现：AFE 硬件保护兜底 + 软件二级判定 + 锁存/重试/锁定状态机
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: DSG=U9.DSG(Pin1); CHG=U9.CHG(Pin2)
 * 参考手册: TI SLUSBK2I
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_protect.h"
#include "bq76920.h"
#include <math.h>

Prot_Info_t g_prot;

/* 过压 / 欠压恢复回差，避免在阈值附近反复跳 */
#define OV_RECOVER_HYST_MV  150U
#define UV_RECOVER_HYST_MV  150U

static bool     s_ov_lat;        /* 过压锁存 */
static bool     s_uv_lat;
static bool     s_ocd_lat;
static bool     s_scd_lat;
static bool     s_occhg_lat;
static bool     s_xready_lat;

/* 传感器健康标志与它们的锁存（用于区分「上升沿」和「持续存在」） */
static uint8_t  s_sens_flags;
static bool     s_wire_lat;
static bool     s_tsens_lat;

static uint32_t s_oc_dsg_ms;
static uint32_t s_oc_chg_ms;
static uint32_t s_retry_at_ms;
static uint32_t s_retry_reset_ms;
static bool     s_last_chg_on;
static bool     s_last_dsg_on;
 /**
  * @file   Prot_FaultName
  * @brief  故障码 → 字符串（打印用）
  * @param  f 故障码
  * @retval 故障名称字符串
  */
const char *Prot_FaultName(Bms_Fault_t f)
{
    switch (f) {
    case BMS_FLT_CELL_OV:   return "CELL_OV";
    case BMS_FLT_CELL_UV:   return "CELL_UV";
    case BMS_FLT_OC_DSG:    return "OC_DISCHARGE";
    case BMS_FLT_SCD:       return "SHORT_CIRCUIT";
    case BMS_FLT_OC_CHG:    return "OC_CHARGE";
    case BMS_FLT_TEMP_HIGH: return "TEMP_HIGH";
    case BMS_FLT_TEMP_LOW:  return "TEMP_LOW";
    case BMS_FLT_TEMP_SENSOR: return "TEMP_SENSOR_FAIL";
    case BMS_FLT_CELL_WIRE:   return "CELL_WIRE_OPEN";
    case BMS_FLT_AFE:       return "AFE_ERROR";
    case BMS_FLT_LOCKED:    return "LOCKED";
    default:                return "NONE";
    }
}
 /**
  * @file   Prot_Init
  * @brief  保护模块初始化：限流值取配置默认值，清所有锁存标志
  * @param  无
  * @retval 无
  */
void Prot_Init(void)
{
    g_prot.chg_limit_a = BMS_CHARGE_MAX_A;
    g_prot.dsg_limit_a = BMS_DISCHARGE_MAX_A;
    g_prot.fault = BMS_FLT_NONE;
    g_prot.locked = false;
    g_prot.retry_cnt = 0U;
    g_prot.chg_allowed = true;
    g_prot.dsg_allowed = true;
    s_ov_lat = s_uv_lat = s_ocd_lat = s_scd_lat = s_occhg_lat = s_xready_lat = false;
    s_sens_flags = 0U;
    s_wire_lat = s_tsens_lat = false;
    s_oc_dsg_ms = s_oc_chg_ms = 0U;
    s_retry_at_ms = 0U;
    s_retry_reset_ms = HAL_GetTick();
    s_last_chg_on = true;
    s_last_dsg_on = true;
}
 /**
  * @file   Prot_SetLimits
  * @brief  运行时修改最大充电/放电电流（会被 App 存进 EEPROM）
  * @param  chg_a 最大充电电流 A; dsg_a 最大放电电流 A
  * @retval 无
  */
void Prot_SetLimits(float chg_a, float dsg_a)
{
    if (chg_a > 0.0f && chg_a <= BMS_RSENSE_RATED_A) { g_prot.chg_limit_a = chg_a; }
    if (dsg_a > 0.0f && dsg_a <= BMS_RSENSE_RATED_A) { g_prot.dsg_limit_a = dsg_a; }
}
 /**
  * @file   Prot_ClearFault
  * @brief  清除所有故障锁存、解除过流锁定、清 AFE 状态位（对应串口 CLR 命令）
  * @param  无
  * @retval 无
  */
void Prot_ClearFault(void)
{
    uint8_t i;
    s_ov_lat = s_uv_lat = s_ocd_lat = s_scd_lat = s_occhg_lat = s_xready_lat = false;
    s_wire_lat = s_tsens_lat = false;
    s_oc_dsg_ms = s_oc_chg_ms = 0U;
    g_prot.locked = false;
    g_prot.retry_cnt = 0U;
    g_prot.fault = BMS_FLT_NONE;
    for (i = 0U; i <= BMS_FLT_LOCKED; i++) { g_prot.counts[i] = 0U; }
    BQ_ClearSysStat(0xFFU);
}
 /**
  * @file   latch_fault
  * @brief  （内部函数）锁存一个故障码并累计事件次数；newly 为真时才计数，
  *         避免每 10ms 都被重复统计一次
  * @param  f 故障码; newly 是否本次新产生
  * @retval 无
  */
static void latch_fault(Bms_Fault_t f, bool newly)
{
    if (newly && f <= BMS_FLT_LOCKED) {
        if (g_prot.counts[f] < 255U) { g_prot.counts[f]++; }
    }
    if (g_prot.fault == BMS_FLT_NONE) { g_prot.fault = f; }
}
 /**
  * @file   Prot_SetSensorFlags
  * @brief  上报传感器健康标志（由 App 每 10ms 调用，必须在 Prot_Task 之前）：
  *         单体电压采样回路异常、温度传感器故障、电芯不均衡三个标志
  * @param  flags PROT_SENSF_xxx 的按位或
  * @retval 无
  */
void Prot_SetSensorFlags(uint8_t flags)
{
    s_sens_flags = flags;
}
 /**
  * @file   eval_sens_flag
  * @brief  （内部函数）评估一个传感器标志：只在上升沿计一次数，按需闭锁充放电
  * @param  bit 标志位; f 对应故障码; lat 锁存变量; block 是否闭锁充放电
  *         chg_ok/dsg_ok 回写允许状态
  * @retval 无
  */
static void eval_sens_flag(uint8_t bit, Bms_Fault_t f, bool *lat, bool block,
                           bool *chg_ok, bool *dsg_ok)
{
    bool now = ((s_sens_flags & bit) != 0U);

    if (now && !(*lat)) {
        *lat = true;
        latch_fault(f, true);
    } else if (!now) {
        *lat = false;
    }

    if (now && block) {
        *chg_ok = false;
        *dsg_ok = false;
    }
}
 /**
  * @file   Prot_Task
  * @brief  保护与限流主函数（App 每 10ms 调用一次）：
  *         1) 采集 AFE 硬件故障位（OV/UV/OCD/SCD/XREADY）并锁存，
  *         条件消失后按 150mV 回差自动解除；
  *         2) 软件过流判定：放电侧为硬件保护的二级补充，
  *         充电侧是「唯一」的过流保护（AFE 没有硬件充电过流）；
  *         3) 温度保护（过温禁充放、低温禁充）；
  *         4) 汇总允许状态并写 CHG/DSG；
  *         5) 过流后按 5s 间隔重试，连续 3 次失败则锁定（需 CLR 解锁）
  * @param  current_a 电流 A; cell_mv 4 节电芯电压; temp_c 温度℃; sys_stat AFE 状态字节
  * @retval 无
  */
void Prot_Task(float current_a, const uint16_t *cell_mv, int8_t temp_c, uint8_t sys_stat)
{
    uint32_t now = HAL_GetTick();
    bool chg_ok = true;
    bool dsg_ok = true;
    uint8_t  i;

    g_prot.current_a = current_a;

    /* ---------------- 1. AFE 硬件故障位 ---------------- */
    bool new_ov = false, new_uv = false, new_ocd = false, new_scd = false;
    bool new_occhg = false, new_xrdy = false;

    if ((sys_stat & BQ_STAT_OV) != 0U && !s_ov_lat)   { s_ov_lat = true;      new_ov = true; }
    if ((sys_stat & BQ_STAT_UV) != 0U && !s_uv_lat)   { s_uv_lat = true;      new_uv = true; }
    if ((sys_stat & BQ_STAT_OCD) != 0U && !s_ocd_lat) { s_ocd_lat = true;     new_ocd = true; }
    if ((sys_stat & BQ_STAT_SCD) != 0U && !s_scd_lat) { s_scd_lat = true;     new_scd = true; }
    if ((sys_stat & BQ_STAT_DEVICE_XREADY) != 0U && !s_xready_lat) {
        s_xready_lat = true; new_xrdy = true;
    }
    (void)new_ov; (void)new_uv; (void)new_xrdy;

    /* 条件消失后自动解除锁存（带回差） */
    uint16_t vmax = 0U, vmin = 0xFFFFU;
    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        if (cell_mv[i] > vmax) { vmax = cell_mv[i]; }
        if (cell_mv[i] < vmin) { vmin = cell_mv[i]; }
    }
    if (s_ov_lat && vmax < (uint16_t)(BMS_CELL_OV_MV - OV_RECOVER_HYST_MV)) { s_ov_lat = false; }
    if (s_uv_lat && vmin > (uint16_t)(BMS_CELL_UV_MV + UV_RECOVER_HYST_MV)) { s_uv_lat = false; }
    if (s_xready_lat && (sys_stat & BQ_STAT_DEVICE_XREADY) == 0U) { s_xready_lat = false; }

    /* ---------------- 2. 电流限制 ---------------- */
    /* 2.1 放电过流（软件二级判定，硬件 OCD 已在 AFE 内生效） */
    if (-current_a >= g_prot.dsg_limit_a) {
        s_oc_dsg_ms += BMS_TASK_FAST_MS;
        if (s_oc_dsg_ms >= BMS_OC_SW_DELAY_MS) {
            if (!s_ocd_lat) { new_ocd = true; }
            s_ocd_lat = true;
            s_oc_dsg_ms = 0U;
        }
    } else if (-current_a < (g_prot.dsg_limit_a * BMS_OC_RECOVER_RATIO)) {
        s_oc_dsg_ms = 0U;
    }

    /* 2.2 充电过流（AFE 无此功能，全靠软件） */
    if (current_a >= g_prot.chg_limit_a) {
        s_oc_chg_ms += BMS_TASK_FAST_MS;
        if (s_oc_chg_ms >= BMS_OC_SW_DELAY_MS) {
            if (!s_occhg_lat) { new_occhg = true; }
            s_occhg_lat = true;
            s_oc_chg_ms = 0U;
        }
    } else if (current_a < (g_prot.chg_limit_a * BMS_OC_RECOVER_RATIO)) {
        s_oc_chg_ms = 0U;
    }

    /* ---------------- 3. 温度 ---------------- */
    if (temp_c >= BMS_TEMP_CHG_MAX) { chg_ok = false; }
    if (temp_c <= BMS_TEMP_CHG_MIN) { chg_ok = false; }
    if (temp_c >= BMS_TEMP_DSG_MAX) { dsg_ok = false; }
    if (temp_c >= BMS_TEMP_CHG_MAX) {
        latch_fault(BMS_FLT_TEMP_HIGH, (g_prot.fault != BMS_FLT_TEMP_HIGH));
    } else if (temp_c <= BMS_TEMP_CHG_MIN) {
        latch_fault(BMS_FLT_TEMP_LOW, (g_prot.fault != BMS_FLT_TEMP_LOW));
    }

    /* ---------------- 3.1 传感器健康：采不到真值就不能继续充放电 ----------------
     * 单体电压采样回路异常：连电压都不可信了，继续充放电就是在裸奔 → 全停；
     * 温度传感器故障：按 BMS_TEMP_SENSOR_FAILSAFE 决定是闭锁还是只告警；
     * 电芯不均衡：不做故障处理（否则会停掉均衡，越不均衡越不均衡），
     *           只在状态里显示，由均衡慢慢拉平。 */
    eval_sens_flag(PROT_SENSF_CELL_WIRE, BMS_FLT_CELL_WIRE, &s_wire_lat, true, &chg_ok, &dsg_ok);
#if (BMS_TEMP_SENSOR_FAILSAFE == 1U)
    eval_sens_flag(PROT_SENSF_TEMP_FAIL, BMS_FLT_TEMP_SENSOR, &s_tsens_lat, true, &chg_ok, &dsg_ok);
#else
    eval_sens_flag(PROT_SENSF_TEMP_FAIL, BMS_FLT_TEMP_SENSOR, &s_tsens_lat, false, &chg_ok, &dsg_ok);
#endif
    /* ---------------- 4. 汇总允许状态 ---------------- */
    bool chg_lat_fault = s_ov_lat || s_occhg_lat;
    bool dsg_lat_fault = s_uv_lat || s_ocd_lat || s_scd_lat || s_xready_lat;

    if (chg_lat_fault) { chg_ok = false; }
    if (dsg_lat_fault) { dsg_ok = false; }

    if (s_ov_lat)     { latch_fault(BMS_FLT_CELL_OV, new_ov); }
    if (s_uv_lat)     { latch_fault(BMS_FLT_CELL_UV, new_uv); }
    if (s_occhg_lat)  { latch_fault(BMS_FLT_OC_CHG, new_occhg); }
    if (s_ocd_lat)    { latch_fault(BMS_FLT_OC_DSG, new_ocd); }
    if (s_scd_lat)    { latch_fault(BMS_FLT_SCD, new_scd); }
    if (s_xready_lat) { latch_fault(BMS_FLT_AFE, new_xrdy); }

    /* ---------------- 5. 过流重试与锁定 ---------------- */
    if (s_ocd_lat || s_scd_lat || s_occhg_lat) {
        if (s_retry_at_ms == 0U) {
            s_retry_at_ms = now + BMS_OC_RETRY_MS;
            g_prot.retry_cnt++;
            if (g_prot.retry_cnt > BMS_OC_MAX_RETRY) {
                g_prot.locked = true;
                latch_fault(BMS_FLT_LOCKED, true);
            }
        }
        if (!g_prot.locked && now >= s_retry_at_ms
            && fabsf(current_a) < (g_prot.dsg_limit_a * 0.5f)) {
            /* 条件满足：清锁存，重新尝试导通；若仍过流会被 AFE/软件再次切断 */
            s_ocd_lat = s_scd_lat = s_occhg_lat = false;
            s_retry_at_ms = 0U;
            s_retry_reset_ms = now;
            g_prot.fault = BMS_FLT_NONE;
            BQ_ClearSysStat((uint8_t)(BQ_STAT_OCD | BQ_STAT_SCD));
        }
    }

    /* 超过 60s 无过流 → 重试计数清零 */
    if ((now - s_retry_reset_ms) > 60000U) {
        g_prot.retry_cnt = 0U;
        s_retry_reset_ms = now;
    }

    /* 锁定状态下强制不允许充放电 */
    if (g_prot.locked) {
        chg_ok = false;
        dsg_ok = false;
    }

    /* ---------------- 6. 下发 FET 状态 ---------------- */
    g_prot.chg_allowed = chg_ok;
    g_prot.dsg_allowed = dsg_ok;

    if (chg_ok != s_last_chg_on || dsg_ok != s_last_dsg_on) {
        BQ_SetFets(chg_ok, dsg_ok);
        s_last_chg_on = chg_ok;
        s_last_dsg_on = dsg_ok;
    }

    /* 全部条件解除后，清 AFE 状态位（ALERT 才会回落） */
    if (!s_ov_lat && !s_uv_lat && !s_xready_lat) {
        BQ_ClearSysStat((uint8_t)(BQ_STAT_OV | BQ_STAT_UV | BQ_STAT_DEVICE_XREADY));
    }
    if (g_prot.fault != BMS_FLT_NONE) {
        Bms_Fault_t f = g_prot.fault;
        bool still = false;
        switch (f) {
        case BMS_FLT_CELL_OV:   still = s_ov_lat; break;
        case BMS_FLT_CELL_UV:   still = s_uv_lat; break;
        case BMS_FLT_OC_DSG:    still = s_ocd_lat; break;
        case BMS_FLT_SCD:       still = s_scd_lat; break;
        case BMS_FLT_OC_CHG:    still = s_occhg_lat; break;
        case BMS_FLT_TEMP_HIGH: still = (temp_c >= BMS_TEMP_CHG_MAX); break;
        case BMS_FLT_TEMP_LOW:  still = (temp_c <= BMS_TEMP_CHG_MIN); break;
        case BMS_FLT_TEMP_SENSOR: still = s_tsens_lat; break;
        case BMS_FLT_CELL_WIRE:   still = s_wire_lat; break;
        case BMS_FLT_AFE:       still = s_xready_lat; break;
        case BMS_FLT_LOCKED:    still = g_prot.locked; break;
        default: still = false; break;
        }
        if (!still) { g_prot.fault = BMS_FLT_NONE; }
    }
}
