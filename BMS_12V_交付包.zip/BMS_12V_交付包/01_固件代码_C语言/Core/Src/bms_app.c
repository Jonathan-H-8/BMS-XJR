/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_app.c
 * 描述    ：应用层实现：10ms/250ms/1s/5s 任务调度 + 串口命令行（所有功能的总入口）
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 见各模块
 * 参考手册: 无
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_app.h"
#include "bq76920.h"
#include "bms_soc.h"
#include "bms_led.h"
#include "bms_balance.h"
#include "bms_cells.h"
#include "bms_temp.h"
#include "bms_protect.h"
#include "bms_debug.h"
#include "bms_storage.h"
#include "bms_can.h"
#include "bms_wdg.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

static uint32_t s_t_fast = 0U;
static uint32_t s_t_cell = 0U;
static uint32_t s_t_slow = 0U;
static uint32_t s_t_bal  = 0U;

static uint32_t s_full_hold_ms = 0U;
static uint32_t s_empty_hold_ms = 0U;
static uint32_t s_rest_ms = 0U;

/* ---- 上电快速 OCV 对齐状态（★ 让上电就显示真实电量，不必等 30 分钟静置）----
 * 判据要同时满足三条，缺一不可：
 *   ① 电流接近 0        —— 确实在静置，不是带载测量
 *   ② 电压稳定          —— 窗口内极差 < BMS_OCV_BOOT_STABLE_MV，说明极化已恢复完
 *   ③ 上面两条持续够久  —— ≥ BMS_OCV_BOOT_MS
 * ★ 为什么要 ② ：刚跑完车立刻重启，端电压还带着极化（放电后偏低），
 *   只看"电流小"会把极化电压误当成 OCV，反而把 SOC 拉错。 */
static uint16_t s_boot_win[BMS_OCV_BOOT_WIN];   /* 平均单体电压样本（环形窗口） */
static uint8_t  s_boot_idx  = 0U;                /* 窗口写指针 */
static uint8_t  s_boot_cnt  = 0U;                /* 已填样本数（未满不判稳） */
static uint32_t s_boot_rest_ms = 0U;             /* 静置累计时长 ms */
static uint8_t  s_boot_hold = 0U;                /* 稳定判据连续满足次数 */
static bool     s_boot_done = false;             /* 本次上电是否已做过一次 OCV 对齐 */

/* ---- SOC 掉电快照 ---- */
static uint16_t s_soc_last_saved = 0U;           /* 上次落盘的千分比 */
static uint32_t s_soc_save_tick  = 0U;           /* 上次落盘时刻 */

/* ---- ★ 上电 SOC 一级判据：待测电芯（冷启动检测）----
 * 在 BMS_Init() 的最开头、任何 I2C 初始化之前采一次样，用来回答
 * "本次上电是彻底断电后的冷启动，还是系统一直在电的热重启"。
 * 判据与理由见 bms_config.h 里 BMS_COLDSTART_DETECT 的注释。 */
static bool     s_cold_boot_done = false;        /* 是否已采过样（只采一次） */
static bool     s_cold_boot      = false;        /* 冷启动判定结果 */
static uint16_t s_cold_boot_adc  = 0U;           /* 当时的原始 ADC 码，供日志/调试 */

static volatile bool s_alert_flag = false;
static bool s_bal_enable = true;
static uint32_t s_t_can = 0U;
static uint32_t s_t_param = 0U;
static bool     s_mon_enable = false;   /* 是否每秒推送 $BMS 数据帧（MON 1 打开，供 PC 看板） */

/* 串口接收行缓冲 */
static char    s_rx_line[64];
static uint8_t s_rx_len = 0U;
static volatile bool s_rx_ready = false;

#define BMS_LOW_SOC_WARN_PCT   10.0f

/* ------------------------------------------------------------------ */
/* 上电冷启动检测（待测电芯）                                          */
/* ------------------------------------------------------------------ */
 /**
  * @file   app_read_startup_adc
  * @brief  （内部函数）读一次待测电芯（R17 开尔文取样点）的原始 ADC 码。
  *         必须在任何 I2C / AFE 初始化之前调用，此时引脚还是上电默认状态。
  *         ★ 不要在这里改引脚配置 —— 一旦配置成模拟输入，"上电前是高阻"这个
  *           信息就丢了，热重启与冷启动会长得一模一样。
  * @param  无
  * @retval ADC 原始码（0~4095）；硬件未接、读数越界时返回 BMS_STARTUP_ADC_NEUTRAL
  */
static uint16_t app_read_startup_adc(void)
{
#if (BMS_COLDSTART_DETECT == 1U)
    HAL_ADC_Start(&BMS_STARTUP_ADC_HANDLE);
    if (HAL_ADC_PollForConversion(&BMS_STARTUP_ADC_HANDLE, 2U) != HAL_OK) {
        (void)HAL_ADC_Stop(&BMS_STARTUP_ADC_HANDLE);
        return (uint16_t)BMS_STARTUP_ADC_NEUTRAL;   /* 读不到就退回中性值，不误判成冷启动 */
    }
    {
        uint16_t raw = (uint16_t)HAL_ADC_GetValue(&BMS_STARTUP_ADC_HANDLE);
        (void)HAL_ADC_Stop(&BMS_STARTUP_ADC_HANDLE);
        /* 读数贴着上下轨 → 引脚可能没接（悬空被拉死）。当"无信息"处理，
           退回中性值，让后续仍走 EEPROM/OCV 两条路，不产生假判据。 */
        if (raw < BMS_STARTUP_ADC_MIN || raw > BMS_STARTUP_ADC_MAX) {
            return (uint16_t)BMS_STARTUP_ADC_NEUTRAL;
        }
        return raw;
    }
#else
    return (uint16_t)BMS_STARTUP_ADC_NEUTRAL;       /* 未启用：始终"无信息" */
#endif
}
 /**
  * @file   app_detect_cold_boot
  * @brief  （内部函数）判定本次上电是否为冷启动。
  *         判据：待测电芯读数落在零点死区内 → 上电前该点无电流路径上的真实压差
  *               → 系统此前处于彻底断电状态（冷启动）。
  *         ★ 为什么这不是"猜"：热重启时采样电阻上一定带着当时的电流压降
  *           （哪怕只有几毫安 × 1mΩ，也会把读数推出 ±0.77mV 的死区之外），
  *           所以"落在死区里"这件事本身就给出了可靠信息。
  * @param  无
  * @retval 无（结果写入 s_cold_boot / s_cold_boot_adc）
  */
static void app_detect_cold_boot(void)
{
    uint16_t raw = app_read_startup_adc();
    uint16_t diff;

    s_cold_boot_adc = raw;
    if (raw >= (uint16_t)BMS_STARTUP_ADC_NEUTRAL) {
        diff = (uint16_t)(raw - BMS_STARTUP_ADC_NEUTRAL);
    } else {
        diff = (uint16_t)(BMS_STARTUP_ADC_NEUTRAL - raw);
    }
    s_cold_boot = (diff <= (uint16_t)BMS_STARTUP_ADC_DEADBAND) ? true : false;
    s_cold_boot_done = true;
}
 /**
  * @file   BMS_SampleStartupCell
  * @brief  外部可调的采样入口（★ 给"想要最严格时序"的用法）。
  *
  *         ★ 时序为什么关键：本检测靠的是"上电后引脚还没有被程序动过"这件事。
  *           必须在 MX_ADC1_Init() 之后、BQ_Init() 之前调用 ——
  *           · 早于 MX_ADC1_Init()：HAL_ADC_Start() 会失败（外设时钟/句柄还没好）
  *           · 晚于 BQ_Init() 或任何 I2C 动作：采样电阻上已经可能流过电流，
  *             热重启与冷启动就分不出来了
  *         推荐写法（main.c）：
  *             MX_ADC1_Init();
  *             HAL_ADCEx_Calibration_Start(&hadc1);   // F1 系列需要
  *             BMS_SampleStartupCell();               // ★ 就在这里
  *             ...
  *             BMS_Init();                            // 此时不会再重复采样
  *         若不这样写（比如直接把 BMS_Init() 放在 ADC 初始化前），BMS_Init()
  *         内部会自行尝试采样一次；采样失败会当作"无信息"处理（不影响其它功能），
  *         只是这条硬件判据用不上，SOC 仍由 EEPROM / OCV 两条路确定。
  * @param  无
  * @retval 无
  */
void BMS_SampleStartupCell(void)
{
    if (!s_cold_boot_done) {
        app_detect_cold_boot();
    }
}
 /**
  * @file   BMS_IsColdBoot
  * @brief  查询本次上电是否为待测电芯确认的冷启动
  * @param  无
  * @retval 1=冷启动；0=热重启或检测未启用
  */
int BMS_IsColdBoot(void)
{
    return s_cold_boot ? 1 : 0;
}

/* ------------------------------------------------------------------ */
/* SOC 显示/上报：未对齐时绝不报具体数字                                */
/* ------------------------------------------------------------------ */
 /**
  * @file   app_soc_displayable
  * @brief  （内部函数）当前 SOC 是否已有物理意义、可以对外显示具体数字
  * @param  无
  * @retval true=可信；false=真实电量未知，上层应显示"未知/正在确定"
  */
static bool app_soc_displayable(void)
{
    return Soc_IsAligned();
}

/* ------------------------------------------------------------------ */
 /**
  * @file   BMS_AlertIsr
  * @brief  ALERT 引脚中断回调：只置一个标志，真正的处理放在主循环（不要在中断里做 I2C）
  * @param  无
  * @retval 无
  */
void BMS_AlertIsr(void)
{
    s_alert_flag = true;        /* 只在中断里置标志，实际处理放主循环 */
}
 /**
  * @file   BMS_UartRxByte
  * @brief  串口接收一字节（在 HAL_UART_RxCpltCallback 里调用），遇回车换行即组成一条命令
  * @param  byte 收到的字节
  * @retval 无
  */
void BMS_UartRxByte(uint8_t byte)
{
    if (byte == '\r' || byte == '\n') {
        if (s_rx_len > 0U) {
            s_rx_line[s_rx_len] = '\0';
            s_rx_ready = true;
        }
    } else if (s_rx_len < (sizeof(s_rx_line) - 1U)) {
        s_rx_line[s_rx_len++] = (char)byte;
    }
}

/* ------------------------------------------------------------------ */
/* 初始化                                                              */
/* ------------------------------------------------------------------ */
 /**
  * @file   BMS_Init
  * @brief  BMS 总初始化（在 main() 里调用一次）：
  *         1) 读 EEPROM 掉电参数（没焊也能跑，用配置默认值）
  *         2) 初始化 BQ76920（清状态、开 ADC、下发保护、开 MOS）
  *         3) 用参数初始化 SOC / 保护 / 均衡
  *         4) 初始化 CAN
  *         5) 最后开看门狗
  * @param  无
  * @retval 无
  */
void BMS_Init(void)
{
    /* ---- 第 0 步：★ 冷启动检测（必须最先做，早于任何外设初始化）----
     * 待测电芯在上电前的状态是"热重启 / 冷启动"的唯一可靠证据，
     * 一旦配置了 ADC 引脚或初始化了 AFE，这个信息就永久丢失了。 */
    app_detect_cold_boot();

    Led_Init();
    Led_ShowMask(0x1FU);            /* 上电自检：5 颗灯全亮一下 */

    /* ---- 第 1 步：读掉电参数（EEPROM 没焊也能跑，用默认值） ---- */
    Sto_LoadDefaults(&g_param);
#if (BMS_USE_EEPROM == 1U)
    if (Sto_Load(&g_param) == HAL_OK) {
        g_param_loaded = true;
        BMS_Log("[EE] 已载入掉电参数\r\n");
    } else {
        BMS_Log("[EE] 无有效参数，使用配置默认值\r\n");
    }
#endif

    /* ---- 第 2 步：AFE ---- */
    if (BQ_Init() != HAL_OK) {
        BMS_Log("[BMS] BQ76920 通信失败！检查 I2C 上拉/地址/供电。\r\n");
        Led_SetMode(LED_MODE_FAULT);
        Soc_Init(g_param.capacity_ah);
        Soc_NotifyColdBoot(s_cold_boot);
        Prot_Init();
        Bms_WdgInit();              /* 通信失败也要开狗，靠复位尝试自恢复 */
        return;
    }

    /* ---- 第 3 步：算法模块（用掉电参数初始化） ---- */
    Soc_Init(g_param.capacity_ah);
    Soc_NotifyColdBoot(s_cold_boot);
    /* ★ 上电 SOC 对齐·第一条路（最准）：直接用掉电前存的电量。
     *   这条路不经过 OCV，所以不受极化电压影响 —— 刚跑完车立刻重启也准。
     *   若 EEPROM 没有有效记录（首次上电 / 换板 / 数据损坏），
     *   则保持 UNKNOWN（不猜、不填占位值），交给 cell_task() 里的
     *   上电快速 OCV 对齐；在那之前 LED 转圈、串口/CAN 报"电量未知"。 */
    if (g_param.soc_valid != 0U) {
        Soc_SetInitialSoc((float)g_param.soc_permille / 10.0f);
        BMS_Log("[SOC] 已从 EEPROM 恢复电量 %.1f %%（记录于运行 %lu s）\r\n",
                Soc_GetPercent(), (unsigned long)g_param.soc_saved_s);
    } else {
        if (s_cold_boot) {
            BMS_Log("[SOC] 待测电芯判定为冷启动（上电 ADC=%u，落在零点死区内）："
                    "电量未知，等静置电压稳定后由 OCV 对齐\r\n", (unsigned)s_cold_boot_adc);
        } else {
            BMS_Log("[SOC] 无掉电电量记录（热重启，上电 ADC=%u）："
                    "电量未知，等静置电压稳定后由 OCV 对齐\r\n", (unsigned)s_cold_boot_adc);
        }
    }
    Prot_Init();
    Prot_SetLimits(g_param.chg_limit_a, g_param.dsg_limit_a);
    s_bal_enable = (g_param.bal_enable != 0U);
    Bal_Init();

    /* ---- 第 3.1 步：检测层（单体电压 / 温度）---- */
    Cells_Init();
    Temp_Init();

    /* ---- 第 4 步：CAN ---- */
#if (BMS_CAN_ENABLE == 1U)
    Bms_CanInit();
#endif

    /* ---- 第 5 步：最后开看门狗 ---- */
    Bms_WdgInit();

    HAL_Delay(300U);
    Led_AllOff();
    /* ★ 只有电量已确定时才点亮电量条；
     *   未确定则进入"跑马灯"，明确表示"正在确定电量"，不显示假档位。 */
    if (app_soc_displayable()) {
        Led_SetMode(LED_MODE_SOC);
        Led_ShowPercent(Soc_GetPercent());
    } else {
        Led_SetMode(LED_MODE_CALIBRATING);
    }

    BMS_Log("[BMS] 初始化完成：gain=%u uV/LSB offset=%d mV\r\n",
            BQ_GetGainUV(), BQ_GetOffsetMV());

    if (g_param_loaded) {
        /* 已经存过参数 → 是正常在用的板子，自动打开 1Hz 数据推送，PC 看板一插就能看容量 */
        s_mon_enable = true;
        BMS_Log("[BMS] 已自动开启 1Hz 数据推送（发 MON 0 可关闭）\r\n");
    } else {
        /* 首次上电（EEPROM 空白）：打印参数与命令帮助，并顺便把默认参数存下来 */
        BMS_Printf();
        BMS_PrintHelp();
    }
}

/* ------------------------------------------------------------------ */
/* SOC 掉电快照                                                        */
/* ------------------------------------------------------------------ */
 /**
  * @file   soc_save_now
  * @brief  立刻把当前 SOC 存进 EEPROM（★ 上电真实电量的关键数据来源）。
  *         未对齐时不存 —— 存下去的是 50% 占位值，反而会污染下次上电。
  * @param  无
  * @retval 无
  */
static void soc_save_now(void)
{
    if (!Soc_IsAligned()) {
        return;
    }
    g_param.soc_permille = Soc_GetPermille();
    g_param.soc_valid    = 1U;
    g_param.soc_saved_s  = g_param.run_seconds;
    (void)Sto_Save(&g_param);
    s_soc_last_saved = g_param.soc_permille;
    s_soc_save_tick  = HAL_GetTick();
}
 /**
  * @file   soc_snapshot_task
  * @brief  周期性检查 SOC 是否变化到该备份的程度。
  *         触发条件（两个都要满足）：
  *           · 相对上次落盘变化 ≥ BMS_SOC_SAVE_DELTA_PCT
  *           · 距上次落盘 ≥ BMS_SOC_SAVE_MIN_MS
  *         第二个条件是为了保护 AT24C02 的擦写寿命（100 万次），
  *         避免 SOC 在门槛附近来回跳导致疯狂写盘。
  * @param  无
  * @retval 无
  */
static void soc_snapshot_task(void)
{
    uint16_t pm, diff;

    if (!Soc_IsAligned()) {
        return;
    }
    pm   = Soc_GetPermille();
    diff = (pm > s_soc_last_saved) ? (uint16_t)(pm - s_soc_last_saved)
                                   : (uint16_t)(s_soc_last_saved - pm);

    if (diff >= (uint16_t)(BMS_SOC_SAVE_DELTA_PCT * 10.0f)
        && (HAL_GetTick() - s_soc_save_tick) >= BMS_SOC_SAVE_MIN_MS) {
        soc_save_now();
    }
}

/* ------------------------------------------------------------------ */
/* 10ms 快速任务                                                        */
/* ------------------------------------------------------------------ */
 /**
  * @file   fast_task
  * @brief  10ms 快速任务：读 SYS_STAT → 有 CC_READY 就读库仑计并积分 → 保护评估 → LED 刷新
  * @param  无
  * @retval 无
  */
static void fast_task(void)
{
    uint8_t stat;

    stat = BQ_GetSysStat();
    Bms_WdgReportI2c(g_bq_i2c_ok);      /* 连续通信失败会让看门狗不再喂狗 → 复位自恢复 */

    /* 1) 只在整个 250ms 窗口结束（CC_READY=1）时读库仑计。
     *    提前读会把窗口截断，导致积分电量偏少 —— 所以不能用 ALERT 兜底去读。 */
    if ((stat & BQ_STAT_CC_READY) != 0U) {
        BQ_ReadCc();                    /* 读走即复位 */
        Soc_OnCcSample(g_bq.cc_raw);
        BQ_ClearSysStat(BQ_STAT_CC_READY);
    }

    /* 2) 上报传感器健康标志：采样回路异常 / 温度传感器故障 → 保护模块据此闭锁或告警 */
    {
        uint8_t sf = 0U;
        if (!Cells_WireOk())    { sf |= PROT_SENSF_CELL_WIRE; }
        if (Temp_SensorFault()) { sf |= PROT_SENSF_TEMP_FAIL; }
        Prot_SetSensorFlags(sf);
    }

    /* 3) 保护评估（传入最新电流、电压、温度、状态位） */
    Prot_Task(g_bq.current_a, g_bq.real_mv, g_bq.temp_c, stat);

    /* 4) LED：故障优先，其次"电量未确定"（跑马灯），再是低电量闪烁，最后按电量点亮。
     *    ★ 顺序里"未确定"排在低电量之前：既然不知道电量，就不能断言它低。 */
    if (g_prot.fault != BMS_FLT_NONE || g_prot.locked) {
        Led_SetMode(LED_MODE_FAULT);
    } else if (!app_soc_displayable()) {
        Led_SetMode(LED_MODE_CALIBRATING);
    } else if (Soc_GetPercent() < BMS_LOW_SOC_WARN_PCT) {
        Led_ShowMask(0x1FU);
        Led_SetMode(LED_MODE_LOW_BAT);
    } else {
        Led_SetMode(LED_MODE_SOC);
        Led_ShowPercent(Soc_GetPercent());
    }

    s_alert_flag = false;
}

/* ------------------------------------------------------------------ */
/* 250ms 中等任务                                                       */
/* ------------------------------------------------------------------ */
 /**
  * @file   cell_task
  * @brief  250ms 任务：刷新电芯电压与组端电压，做满充/放空/静置三种判定
  * @param  无
  * @retval 无
  */
static void cell_task(void)
{
    bool charging;
    uint8_t i;

    BQ_ReadCells();
    g_bq.pack_mv = BQ_GetPackMv();

    /* 单体电压检测：中值滤波 + 逐节 OV/UV 两级判定 + 采样回路诊断 + 压差统计。
     * 被均衡的电芯读数会被均衡电流压低，检测模块不会采用它（沿用上次可信值），
     * 所以这里用检测模块的「可信统计」覆盖 g_bq 的 min/max/avg，
     * 免得 SOC 的满充/放空判定、均衡策略被那些被压低的假电压带偏。 */
    Cells_Update(g_bq.real_mv, g_bq.pack_mv);

    /* 只在检测模块真的产出了可信统计时才回写，避免上电头几个周期把 0 值写回去 */
    if (g_cells.samples > 0U) {
        for (i = 0U; i < BMS_CELL_COUNT; i++) {
            g_bq.real_mv[i] = g_cells.mv[i];
        }
        g_bq.real_min_mv = g_cells.min_mv;
        g_bq.real_max_mv = g_cells.max_mv;
        g_bq.real_avg_mv = g_cells.avg_mv;
    }

    charging = (g_bq.current_a > 0.02f);
    Soc_NotifyCharging(charging);

    /* --- 满充判定：最高电芯接近 OV 阈值且电流已很小，持续 30s --- */
    if (charging
        && g_bq.real_max_mv >= BMS_FULL_DETECT_MV
        && g_bq.current_a < BMS_FULL_DETECT_A) {
        s_full_hold_ms += BMS_TASK_CELL_MS;
        if (s_full_hold_ms >= BMS_FULL_HOLD_MS) {
            Soc_MarkFull();
            s_full_hold_ms = 0U;
            BMS_Log("[SOC] 满充判定 → 100%%，容量学习值 %.3f Ah\r\n", g_soc.learned_ah);
        }
    } else {
        s_full_hold_ms = 0U;
    }

    /* --- 放空判定：最低电芯低于门槛，持续 5s --- */
    if (!charging
        && g_bq.current_a < -0.05f
        && g_bq.real_min_mv <= BMS_EMPTY_DETECT_MV) {
        s_empty_hold_ms += BMS_TASK_CELL_MS;
        if (s_empty_hold_ms >= BMS_EMPTY_HOLD_MS) {
            Soc_MarkEmpty();
            s_empty_hold_ms = 0U;
            BMS_Log("[SOC] 放空判定 → 0%%，容量学习值 %.3f Ah\r\n", g_soc.learned_ah);
        }
    } else {
        s_empty_hold_ms = 0U;
    }

    /* --- 静置判定：电流很小持续 30min → 用 OCV 修正 SOC --- */
    if (fabsf(g_bq.current_a) < BMS_OCV_REST_A) {
        s_rest_ms += BMS_TASK_CELL_MS;
        if (s_rest_ms >= BMS_OCV_REST_MS) {
            Soc_OnRest(g_bq.real_avg_mv);
            s_rest_ms = 0U;
            BMS_Log("[SOC] 静置 OCV 修正 → %.1f %%\r\n", g_soc.soc_pct);
        }
    } else {
        s_rest_ms = 0U;
    }

    /* --- ★ 上电快速 OCV 对齐（第二条路）：本次上电只做一次 ---
     * 与上面 30min 慢修正的区别：
     *   · 慢修正：运行中长期慢慢拉，权重 0.1，防负载扰动
     *   · 本函数：确认"静置 + 电压稳定"后立刻采信，权重 0.5（差异大时直接采纳），
     *             让上电几秒内就显示真实电量，而不是先骗用户 50%
     * 只在本次上电还没做过时执行；做完就交给库仑计，不再用 OCV 反复干预。 */
    if (!s_boot_done) {
        if (fabsf(g_bq.current_a) < BMS_OCV_REST_A) {
            uint8_t i;
            uint16_t vlo = 0xFFFFU, vhi = 0U;

            /* 把本次平均电压推入窗口 */
            s_boot_win[s_boot_idx] = g_bq.real_avg_mv;
            s_boot_idx = (uint8_t)((s_boot_idx + 1U) % BMS_OCV_BOOT_WIN);
            if (s_boot_cnt < BMS_OCV_BOOT_WIN) {
                s_boot_cnt++;
            }

            s_boot_rest_ms += BMS_TASK_CELL_MS;

            /* 窗口填满后才判稳定性：极差够小 = 电压已经不动了 = 极化恢复完 */
            if (s_boot_cnt >= BMS_OCV_BOOT_WIN) {
                for (i = 0U; i < BMS_OCV_BOOT_WIN; i++) {
                    if (s_boot_win[i] < vlo) { vlo = s_boot_win[i]; }
                    if (s_boot_win[i] > vhi) { vhi = s_boot_win[i]; }
                }
                if ((uint16_t)(vhi - vlo) < BMS_OCV_BOOT_STABLE_MV) {
                    if (s_boot_hold < BMS_OCV_BOOT_HOLD) {
                        s_boot_hold++;
                    }
                } else {
                    s_boot_hold = 0U;         /* 电压还在动：重新数，不能采信 */
                }
            }

            if (s_boot_rest_ms >= BMS_OCV_BOOT_MS && s_boot_hold >= BMS_OCV_BOOT_HOLD) {
                Soc_OnBootOcv(g_bq.real_avg_mv);
                s_boot_done = true;
                BMS_Log("[SOC] 上电 OCV 对齐 → %.1f %%（静置 %lu ms，单体均值 %u mV）\r\n",
                        Soc_GetPercent(), (unsigned long)s_boot_rest_ms, g_bq.real_avg_mv);
                soc_save_now();     /* ★ 刚拿到真实电量，立刻备份，供下次上电直接恢复 */
            }
        } else {
            /* 有电流：极化还在，窗口与计时全部作废，等下次真正停下来 */
            s_boot_rest_ms = 0U;
            s_boot_hold = 0U;
            s_boot_cnt = 0U;
            s_boot_idx = 0U;
        }
    }
}

/* ------------------------------------------------------------------ */
/* 1s 慢任务                                                           */
/* ------------------------------------------------------------------ */
 /**
  * @file   slow_task
  * @brief  1s 慢任务：刷新温度、累计运行时间
  * @param  无
  * @retval 无
  */
static void slow_task(void)
{
    /* 本函数每 1s 调用一次：统计累计运行时长 */
    g_param.run_seconds++;

    /* 温度检测：TS1 → NTC 阻值 → 开路/短路诊断 → 跳变剔除 → 滑动平均 → 温度分区 */
    Temp_Update();
    g_bq.temp_c = Temp_GetWorstC();
    /* 芯片内部温度与外部 NTC 共用 TS1 通道（TEMP_SEL=1 时读到的不是芯片温度），
     * 所以不再每秒读它——需要时用 TEMP DIE 命令单独读一次即可。 */
    g_bq.chg_on = g_prot.chg_allowed;
    g_bq.dsg_on = g_prot.dsg_allowed;

    /* 温度已刷新，再往串口推一帧机器可读数据，供 PC 端实时看容量 */
    if (s_mon_enable) {
        BMS_PrintCsv();
    }
}

/* ------------------------------------------------------------------ */
/* 串口命令                                                            */
/* ------------------------------------------------------------------ */
 /**
  * @file   handle_command
  * @brief  串口命令解析与执行（? / HELP / PARAM / SAVE / SET CHG|DSG / CAP / CLR / BAL / FET / SHIP）
  * @param  line 一条以 \0 结尾的命令字符串
  * @retval 无
  */
static void handle_command(char *line)
{
    char cmd[16] = {0};
    float val = 0.0f;
    int a = 0, b = 0;

    if (sscanf(line, "%15s", cmd) != 1) {
        return;
    }

    if (strcmp(cmd, "?") == 0 || strcmp(cmd, "STATUS") == 0) {
        BMS_PrintStatus();
    } else if (strcmp(cmd, "HELP") == 0) {
        BMS_PrintHelp();
    } else if (strcmp(cmd, "SAVE") == 0) {
        g_param.chg_limit_a = g_prot.chg_limit_a;
        g_param.dsg_limit_a = g_prot.dsg_limit_a;
        g_param.bal_enable  = s_bal_enable ? 1U : 0U;
        g_param.charge_count = g_soc.charge_count;
        if (Sto_Save(&g_param) == HAL_OK) {
            BMS_Log("[EE] 参数已保存\r\n");
        } else {
            BMS_Log("[EE] 保存失败（EEPROM 未焊接或损坏？）\r\n");
        }
    } else if (strcmp(cmd, "PARAM") == 0) {
        BMS_Printf();
    } else if (strcmp(cmd, "SET") == 0) {
        char what[8] = {0};
        if (sscanf(line, "%*s %7s %f", what, &val) == 2) {
            if (strcmp(what, "CHG") == 0) {
                Prot_SetLimits(val, g_prot.dsg_limit_a);
                g_param.chg_limit_a = g_prot.chg_limit_a;
                (void)Sto_Save(&g_param);
                BMS_Log("[CFG] 最大充电电流 = %.2f A（已存）\r\n", g_prot.chg_limit_a);
            } else if (strcmp(what, "DSG") == 0) {
                Prot_SetLimits(g_prot.chg_limit_a, val);
                g_param.dsg_limit_a = g_prot.dsg_limit_a;
                (void)Sto_Save(&g_param);
                BMS_Log("[CFG] 最大放电电流 = %.2f A（已存）\r\n", g_prot.dsg_limit_a);
            } else {
                BMS_Log("[CFG] 用法：SET CHG <A> | SET DSG <A>\r\n");
            }
        }
    } else if (sscanf(line, "%*s %f", &val) == 1 && strcmp(cmd, "CAP") == 0) {
        Soc_SetCapacity(val);
        g_param.capacity_ah = val;
        (void)Sto_Save(&g_param);
        BMS_Log("[CFG] 电池容量 = %.3f Ah（已存）\r\n", val);
    } else if (strcmp(cmd, "CELL") == 0) {
        Cells_Print();
    } else if (strcmp(cmd, "TEMP") == 0) {
        char what[8] = {0};
        if (sscanf(line, "%*s %7s", what) == 1 && strcmp(what, "DIE") == 0) {
            Temp_ReadDie();
        } else {
            Temp_Print();
        }
    } else if (strcmp(cmd, "CELLDIAG") == 0) {
        Cells_OpenWireTest();
    } else if (strcmp(cmd, "CLR") == 0) {
        Prot_ClearFault();
        BMS_Log("[CFG] 故障已清除，保护恢复\r\n");
    } else if (sscanf(line, "%*s %d", &a) == 1 && strcmp(cmd, "MON") == 0) {
        s_mon_enable = (a != 0);
        BMS_Log("[CFG] 实时数据推送 %s（1Hz，格式 $BMS,...）\r\n", s_mon_enable ? "开" : "关");
    } else if (sscanf(line, "%*s %d", &a) == 1 && strcmp(cmd, "BAL") == 0) {
        s_bal_enable = (a != 0);
        if (!s_bal_enable) { Bal_Stop(); }
        g_param.bal_enable = s_bal_enable ? 1U : 0U;
        (void)Sto_Save(&g_param);
        BMS_Log("[CFG] 均衡 %s（已存）\r\n", s_bal_enable ? "允许" : "关闭");
    } else if (sscanf(line, "%*s %d %d", &a, &b) == 2 && strcmp(cmd, "FET") == 0) {
        BQ_SetFets(a != 0, b != 0);
        BMS_Log("[CFG] CHG=%d DSG=%d（手动调试，保护逻辑会在下一周期覆盖）\r\n", a, b);
    } else if (strcmp(cmd, "SHIP") == 0) {
        BMS_Log("[CFG] 进入 SHIP 模式，需按 BOOT 键唤醒\r\n");
        HAL_Delay(20U);
        BQ_EnterShipMode();
    } else {
        BMS_Log("[CFG] 未知命令：%s（发 HELP 查看）\r\n", cmd);
    }
}

/* ------------------------------------------------------------------ */
/* 主循环                                                              */
/* ------------------------------------------------------------------ */
 /**
  * @file   BMS_Loop
  * @brief  BMS 主循环（while(1) 里反复调用）：所有任务都在这里调度，不阻塞
  *         10ms：CC/保护/LED/均衡相位  250ms：电压与检测  1s：温度  5s：均衡策略
  *         20ms：CAN 收发      最后喂狗（必须放最后）
  * @param  无
  * @retval 无
  */
void BMS_Loop(void)
{
    uint32_t now = HAL_GetTick();

    if ((now - s_t_fast) >= BMS_TASK_FAST_MS) {
        s_t_fast = now;
        fast_task();
        Led_Task();
        Bal_Task();     /* 均衡开/停相位：周期性让出测量窗口，让单体电压采样拿到真值 */
    }

    if ((now - s_t_cell) >= BMS_TASK_CELL_MS) {
        s_t_cell = now;
        cell_task();
    }

    if ((now - s_t_slow) >= BMS_TASK_SLOW_MS) {
        s_t_slow = now;
        slow_task();
    }

    if ((now - s_t_bal) >= BMS_BAL_PERIOD_MS) {
        s_t_bal = now;
        if (s_bal_enable) {
            Bal_Update(g_bq.real_mv, g_bq.temp_c, g_bq.current_a,
                       (g_prot.fault != BMS_FLT_NONE) || g_prot.locked);
        }
    }

#if (BMS_CAN_ENABLE == 1U)
    if ((now - s_t_can) >= 20U) {          /* CAN 收发（内部按 200ms 控制上传节奏） */
        s_t_can = now;
        Bms_CanTask();
    }
#endif

    if (s_rx_ready) {
        s_rx_ready = false;
        handle_command(s_rx_line);
        s_rx_len = 0U;
    }

    /* 慢变量（累计运行时长）周期性落盘，避免频繁擦写 EEPROM */
    if ((now - s_t_param) >= BMS_PARAM_SAVE_MS) {
        s_t_param = now;
        soc_save_now();                 /* 先把当前 SOC 写进去，再落盘整包参数 */
        (void)Sto_Save(&g_param);
    } else {
        soc_snapshot_task();            /* 变化够大就提前落盘，别等 10min 周期 */
    }

    Bms_WdgFeed();                          /* ★ 必须放在主循环最后 */
}

/* ------------------------------------------------------------------ */
/* 容量学习结果落盘（覆盖 bms_soc.c 里的 __weak 空实现）                  */
/* ------------------------------------------------------------------ */
 /**
  * @file   Soc_SaveCapacityCb
  * @brief  容量学习回调（重写 bms_soc.c 里的弱函数）：把学到的容量写入 AT24C02
  * @param  capacity_ah 学到的容量 Ah
  * @retval 无
  */
void Soc_SaveCapacityCb(float capacity_ah)
{
    g_param.learned_ah  = capacity_ah;
    g_param.charge_count = g_soc.charge_count;
    if (Sto_Save(&g_param) == HAL_OK) {
        BMS_Log("[EE] 学习容量 %.3f Ah 已保存\r\n", capacity_ah);
    }
}
