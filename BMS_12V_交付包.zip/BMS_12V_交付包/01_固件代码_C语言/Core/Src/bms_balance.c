/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_balance.c
 * 描述    ：被动均衡实现：压差 + 电压 + 温度 + 电流四条件判断，相邻电芯不同时均衡
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: AFE 内部均衡 FET（经 R22~R25 1kΩ 采样电阻）
 * 参考手册: TI SLUSBK2I
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_balance.h"
#include "bq76920.h"
#include "bms_cells.h"

Bal_Info_t g_bal;

static uint32_t s_last_ms = 0U;
static uint8_t  s_hold_cnt = 0U;
static uint32_t s_phase_ms = 0U;        /* 当前相位（均衡 / 暂停）已持续时长 */
static bool     s_in_pause = false;     /* 是否处于「暂停均衡、让出测量窗口」相位 */
 /**
  * @file   Bal_Init
  * @brief  均衡模块初始化：关闭所有均衡 FET，清空状态
  * @param  无
  * @retval 无
  */
void Bal_Init(void)
{
    g_bal.active = false;
    g_bal.mask = 0U;
    g_bal.applied_mask = 0U;
    g_bal.measuring = false;
    g_bal.delta_mv = 0U;
    g_bal.target_mv = 0U;
    s_phase_ms = 0U;
    s_in_pause = false;
    BQ_SetBalanceMask(0x00U);
}
 /**
  * @file   Bal_Stop
  * @brief  立即停止均衡（写 CELLBAL1 = 0）
  * @param  无
  * @retval 无
  */
void Bal_Stop(void)
{
    g_bal.active = false;
    g_bal.measuring = false;
    g_bal.mask = 0U;
    g_bal.applied_mask = 0U;
    s_phase_ms = 0U;
    s_in_pause = false;
    BQ_SetBalanceMask(0x00U);
}
 /**
  * @file   Bal_Task
  * @brief  均衡相位控制（App 每 10ms 调用一次）：
  *         1) 均衡电流会流过 R22~R25 采样电阻，被均衡那一节的 AFE 读数会被压低，
  *            所以不能一直开着——否则单体电压检测永远拿不到真值，SOC 也会被带偏；
  *         2) 于是采用「开 BMS_BAL_ON_MS → 停 BMS_BAL_PAUSE_MS」的循环：
  *            暂停期间 CELLBAL1 写 0，没有任何均衡电流，AFE 转换出来的就是真实电压；
  *            bms_cells.c 看到 applied_mask=0 就会把这次读数当成可信值；
  *         3) 暂停时长必须大于 AFE 的 250ms ADC 更新周期，配置里给了 500ms；
  *         4) 采样线自检（CELLDIAG）进行期间完全不插手，交给自检代码控制。
  * @param  无
  * @retval 无
  */
void Bal_Task(void)
{
    /* 自检进行中：不抢 CELLBAL1 */
    if (g_cells_diag_active) {
        g_bal.measuring = false;
        return;
    }

    /* 没有均衡需求：确保关掉，并复位相位 */
    if (g_bal.mask == 0U) {
        if (g_bal.applied_mask != 0U) {
            BQ_SetBalanceMask(0x00U);
            g_bal.applied_mask = 0U;
        }
        g_bal.active = false;
        g_bal.measuring = false;
        s_phase_ms = 0U;
        s_in_pause = false;
        return;
    }

    s_phase_ms += BMS_TASK_FAST_MS;

    if (!s_in_pause) {
        /* 均衡相位：把逻辑掩码真正下发到 CELLBAL1 */
        if (g_bal.applied_mask != g_bal.mask) {
            BQ_SetBalanceMask(g_bal.mask);
            g_bal.applied_mask = g_bal.mask;
        }
        g_bal.active = true;
        g_bal.measuring = false;
        if (s_phase_ms >= BMS_BAL_ON_MS) {
            s_phase_ms = 0U;
            s_in_pause = true;
        }
    } else {
        /* 暂停相位：关掉全部均衡，让 AFE 采到真实电压 */
        if (g_bal.applied_mask != 0U) {
            BQ_SetBalanceMask(0x00U);
            g_bal.applied_mask = 0U;
        }
        g_bal.active = false;
        g_bal.measuring = true;
        if (s_phase_ms >= BMS_BAL_PAUSE_MS) {
            s_phase_ms = 0U;
            s_in_pause = false;
        }
    }
}
 /**
  * @file   Bal_Update
  * @brief  均衡策略主函数（App 每 5s 调用一次）：
  *         1) 找出最高/最低电芯，判断温度、电压、压差、电流四个条件；
  *         2) 挑出高于"最低+门槛"的候选电芯；
  *         3) 按电压从高到低贪心选取，跳过与已选电芯相邻的（避免相邻同时泄放）；
  *         4) 结果写入 CELLBAL1
  * @param  cell_mv 4 节真实电芯电压数组; temp_c 温度℃; current_a 电流 A; fault 是否处于故障
  * @retval 无
  */
void Bal_Update(const uint16_t *cell_mv, int8_t temp_c, float current_a, bool fault)
{
    uint8_t i;
    uint16_t vmin = 0xFFFFU, vmax = 0U;
    uint8_t  mask = 0U;

    if (cell_mv == NULL) {
        return;
    }

    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        if (cell_mv[i] < vmin) { vmin = cell_mv[i]; }
        if (cell_mv[i] > vmax) { vmax = cell_mv[i]; }
    }
    g_bal.delta_mv  = (uint16_t)(vmax - vmin);
    g_bal.target_mv = vmin;

    /* ---- 采样线自检进行中：均衡交给自检代码控制 ---- */
    if (g_cells_diag_active) {
        return;
    }

    /* ---- 逼近过压阈值时停手 ----
     * 均衡电流会压低被均衡那一节的读数，若此时真有电芯冲高，
     * AFE 的硬件过压比较器和软件判定都可能看不到真实电压 → 提前停止均衡。 */
    if (g_cells.samples > 0U
        && g_cells.max_mv >= (uint16_t)(BMS_CELL_OV_MV - BMS_BAL_OV_GUARD_MV)) {
        Bal_Stop();
        return;
    }

    /* ---- 前置条件判断 ---- */
    if (fault
        || temp_c < BMS_BAL_TEMP_MIN || temp_c > BMS_BAL_TEMP_MAX
        || vmin < BMS_BAL_MIN_MV
        || vmax < BMS_BAL_START_MV
        || g_bal.delta_mv < BMS_BAL_DELTA_MV) {
        Bal_Stop();
        return;
    }

    /* 电流条件：放电大电流时暂停（充电中电流较大也允许） */
    if (current_a < -BMS_BAL_MAX_CURRENT_A) {
        Bal_Stop();
        return;
    }

    /* ---- 计算掩码（映射到真实电芯 → AFE 槽位）----
     * 先挑出所有"高于最低电芯 + 门槛"的候选电芯，
     * 再按电压从高到低贪心选取，跳过与已选电芯相邻的（BMS_BAL_NO_ADJACENT=1 时）。
     * 理由：AFE 相邻通道的采样线共用滤波电阻与内部泄放通路，
     *       两节相邻电芯同时均衡会互相干扰电压测量。 */
    static const uint8_t slot[BMS_CELL_COUNT] = {
        BMS_CELL_SLOT_0, BMS_CELL_SLOT_1, BMS_CELL_SLOT_2, BMS_CELL_SLOT_3
    };

    uint8_t cand[BMS_CELL_COUNT];
    uint8_t n_cand = 0U;
    uint8_t sel[BMS_CELL_COUNT];
    uint8_t n_sel = 0U;
    uint8_t a, b, tmp;

    for (i = 0U; i < BMS_CELL_COUNT; i++) {
        if (cell_mv[i] > (uint16_t)(vmin + BMS_BAL_DELTA_MV)) {
            cand[n_cand++] = i;
        }
    }

    /* 按电压降序做简单选择排序（电芯数很少，不用 qsort） */
    for (a = 0U; a < n_cand; a++) {
        for (b = (uint8_t)(a + 1U); b < n_cand; b++) {
            if (cell_mv[cand[b]] > cell_mv[cand[a]]) {
                tmp = cand[a]; cand[a] = cand[b]; cand[b] = tmp;
            }
        }
    }

    for (a = 0U; a < n_cand; a++) {
        uint8_t idx = cand[a];
        bool conflict = false;

        for (b = 0U; b < n_sel; b++) {
#if (BMS_BAL_NO_ADJACENT == 1U)
            /* 相邻（差 1）或同一节都不允许同时均衡 */
            if ((idx == sel[b]) || (idx + 1U == sel[b]) || (sel[b] + 1U == idx)) {
                conflict = true;
                break;
            }
#else
            if (idx == sel[b]) { conflict = true; break; }
#endif
        }
        if (!conflict) {
            sel[n_sel++] = idx;
            mask |= (uint8_t)(1U << slot[idx]);
        }
    }

    /* 避免状态抖动：连续两次相同结果才动作；空槽 bit3 已被驱动层强制屏蔽 */
    if (mask == g_bal.mask) {
        if (s_hold_cnt < 255U) { s_hold_cnt++; }
    } else {
        s_hold_cnt = 0U;
        g_bal.mask = mask;
    }

    /* 这里只更新「想均衡谁」；真正写 CELLBAL1 由 Bal_Task 按开/停相位执行 */
    g_bal.active = (s_hold_cnt >= 1U) && (g_bal.mask != 0U);

    (void)s_last_ms;
}
