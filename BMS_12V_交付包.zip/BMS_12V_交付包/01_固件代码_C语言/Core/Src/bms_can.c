/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_can.c
 * 描述    ：CAN 通信实现：500kbps 扩展帧，每 200ms 轮发 7 帧；接收 [0x01,cmd,0x55] 控制字
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: TJA1050：PB8=CAN_RX; PB9=CAN_TX（CubeMX 里 CAN1 必须重映射）
 * 参考手册: 厂家 BMS_s940 例程
 * 波特率  : 500kbps（APB1=36MHz，预分频4、BS1=9tq、BS2=8tq、SJW=1tq）
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/

//头文件
#include "bms_can.h"
#include "bq76920.h"
#include "bms_soc.h"
#include "bms_protect.h"
#include "bms_balance.h"
#include "bms_debug.h"
#include <math.h>
#include <string.h>

extern CAN_HandleTypeDef hcan;

#define CAN_PERIOD_MS     200U        /* 上传周期：200ms 一轮 7 帧 */
#define CAN_TX_GAP_MS     2U          /* 帧间间隔，防止总线拥塞 */

static bool     s_upload = true;
static uint32_t s_last_tx_ms = 0U;
static uint32_t s_rx_cnt = 0U;
static uint8_t  s_tx_frame = 0U;
 /**
  * @file   put_u16
  * @brief  （内部函数）按高字节在前写入 2 字节（与厂家上位机约定一致）
  * @param  p 目标地址; v 16 位值
  * @retval 无
  */
static void put_u16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)(v & 0xFFU);
}
 /**
  * @file   can_tx
  * @brief  （内部函数）发送一帧扩展帧 CAN 数据（8 字节），并等发送完成（最多 20ms）
  * @param  id 扩展帧 ID; data 8 字节数据
  * @retval HAL_OK 成功
  */
static HAL_StatusTypeDef can_tx(uint32_t id, uint8_t *data)
{
    CAN_TxHeaderTypeDef hdr;
    uint32_t mailbox;

    hdr.ExtId = id;
    hdr.IDE   = CAN_ID_EXT;
    hdr.RTR   = CAN_RTR_DATA;
    hdr.DLC   = 8U;
    hdr.TransmitGlobalTime = DISABLE;

    if (HAL_CAN_AddTxMessage(&hcan, &hdr, data, &mailbox) != HAL_OK) {
        return HAL_ERROR;
    }
    /* 等发送完成（总线正常时 <1ms；失败也不阻塞太久） */
    uint32_t t0 = HAL_GetTick();
    while (HAL_CAN_IsTxMessagePending(&hcan, mailbox) && (HAL_GetTick() - t0) < 20U) {
        ;
    }
    return HAL_OK;
}
 /**
  * @file   Bms_CanInit
  * @brief  CAN 初始化：配置滤波器（全通）→ 启动 → 打开接收中断
  * @param  无
  * @retval 无
  */
void Bms_CanInit(void)
{
    CAN_FilterTypeDef f;

    f.FilterBank = 0U;
    f.FilterMode = CAN_FILTERMODE_IDMASK;
    f.FilterScale = CAN_FILTERSCALE_32BIT;
    f.FilterIdHigh = 0x0000U;
    f.FilterIdLow = 0x0000U;
    f.FilterMaskIdHigh = 0x0000U;
    f.FilterMaskIdLow = 0x0000U;
    f.FilterFIFOAssignment = CAN_RX_FIFO0;
    f.FilterActivation = ENABLE;
    f.SlaveStartFilterBank = 14U;

    if (HAL_CAN_ConfigFilter(&hcan, &f) != HAL_OK) {
        BMS_Log("[CAN] 滤波器配置失败\r\n");
        return;
    }
    if (HAL_CAN_Start(&hcan) != HAL_OK) {
        BMS_Log("[CAN] 启动失败\r\n");
        return;
    }
    /* 兼容不同 HAL 版本的接收中断使能 */
#if defined(CAN_IT_RX_FIFO0_MSG_PENDING)
    (void)HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
#else
    (void)HAL_CAN_ActivateNotification(&hcan, CAN_IT_FMP0);
#endif
    BMS_Log("[CAN] 500kbps 扩展帧，上传%s\r\n", s_upload ? "开" : "关");
}
 /**
  * @file   Bms_CanSetUpload
  * @brief  设置是否周期上传（对应下行命令 0x02/0x03）
  * @param  on true=上传
  * @retval 无
  */
void Bms_CanSetUpload(bool on) { s_upload = on; }
 /**
  * @file   Bms_CanIsUploadOn
  * @brief  查询当前是否在上传
  * @param  无
  * @retval true=上传中
  */
bool Bms_CanIsUploadOn(void)   { return s_upload; }
 /**
  * @file   Bms_CanGetRxCount
  * @brief  取累计收到的 CAN 帧数（调总线用）
  * @param  无
  * @retval 帧数
  */
uint32_t Bms_CanGetRxCount(void) { return s_rx_cnt; }
 /**
  * @file   Bms_CanSendOnce
  * @brief  发送 7 帧中的当前一帧，然后自动切到下一帧：
  *         帧1~5：电芯电压（每节 2 字节，大端 mV）
  *         帧6  ：总电压、SOC(0.1%)、电流(mA，有符号)
  *         帧7  ：温度、DSG 状态、CHG 状态、均衡掩码、故障码
  * @param  无
  * @retval 无
  */
void Bms_CanSendOnce(void)
{
    uint8_t d[8];
    uint8_t i;

    for (i = 0U; i < 8U; i++) { d[i] = 0U; }
    d[0] = 0xAAU;

    switch (s_tx_frame) {
    case 0U:   /* 帧1：cell1~cell3 */
        d[1] = 0x01U;
        put_u16(&d[2], g_bq.real_mv[0]);
        put_u16(&d[4], g_bq.real_mv[1]);
        put_u16(&d[6], g_bq.real_mv[2]);
        break;

    case 1U:   /* 帧2：cell4~cell6 */
        d[1] = 0x02U;
        put_u16(&d[2], (BMS_CELL_COUNT > 3U) ? g_bq.real_mv[3] : 0U);
        break;

    case 2U:   /* 帧3：cell7~cell9 */
        d[1] = 0x03U;
        break;

    case 3U:   /* 帧4 */
        d[1] = 0x04U;
        break;

    case 4U:   /* 帧5 */
        d[1] = 0x05U;
        break;

    case 5U:   /* 帧6：总电压 + SOC + 电流 */
        d[1] = 0x06U;
        put_u16(&d[2], g_bq.pack_mv);
        /* ★ 电量未对齐时发哨兵值 BMS_SOC_UNKNOWN_X10（0xFFFF），
         *   而不是随便一个数字 —— 上游仪表据此显示"未知"。 */
        put_u16(&d[4], Soc_IsAligned() ? (uint16_t)(Soc_GetPercent() * 10.0f)
                                       : (uint16_t)BMS_SOC_UNKNOWN_X10);
        {
            int32_t ma = (int32_t)(g_bq.current_a * 1000.0f);
            if (ma > 32000) { ma = 32000; }
            if (ma < -32000) { ma = -32000; }
            put_u16(&d[6], (uint16_t)(int16_t)ma);
        }
        break;

    case 6U:   /* 帧7：温度 + FET 状态 + 均衡掩码 */
    default:
        d[1] = 0x07U;
        d[2] = (uint8_t)(int8_t)g_bq.temp_c;
        d[3] = g_prot.dsg_allowed ? 1U : 0U;
        d[4] = g_prot.chg_allowed ? 1U : 0U;
        d[5] = g_bal.mask;
        d[6] = (uint8_t)g_prot.fault;
        break;
    }

    (void)can_tx(s_tx_frame + 1U, d);
    s_tx_frame = (uint8_t)((s_tx_frame + 1U) % 7U);
}
 /**
  * @file   can_handle_rx
  * @brief  （内部函数）取空接收 FIFO，解析下行控制命令 [0x01, cmd, 0x55]
  * @param  无
  * @retval 无
  */
static void can_handle_rx(void)
{
    CAN_RxHeaderTypeDef rx;
    uint8_t d[8];

    while (HAL_CAN_GetRxFifoFillLevel(&hcan, CAN_RX_FIFO0) > 0U) {
        if (HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &rx, d) != HAL_OK) {
            return;
        }
        s_rx_cnt++;

        if (d[0] != 0x01U || d[2] != 0x55U) {
            continue;                    /* 不是本协议，忽略 */
        }
        switch (d[1]) {
        case 0x02U: Bms_CanSetUpload(true);  BMS_Log("[CAN] 开始上传\r\n"); break;
        case 0x03U: Bms_CanSetUpload(false); BMS_Log("[CAN] 停止上传\r\n"); break;
        case 0x04U: BQ_SetDsg(true);          BMS_Log("[CAN] 开 DSG\r\n");  break;
        case 0x05U: BQ_SetDsg(false);         BMS_Log("[CAN] 关 DSG\r\n");  break;
        case 0x06U: BQ_SetChg(true);          BMS_Log("[CAN] 开 CHG\r\n");  break;
        case 0x07U: BQ_SetChg(false);         BMS_Log("[CAN] 关 CHG\r\n");  break;
        case 0x10U: Prot_ClearFault();        BMS_Log("[CAN] 清故障\r\n");  break;
        default: break;
        }
    }
}
 /**
  * @file   Bms_CanTask
  * @brief  CAN 周期任务：每 20ms 进来查接收；每 200ms 发一轮数据（帧间隔 2ms）
  * @param  无
  * @retval 无
  */
void Bms_CanTask(void)
{
    uint32_t now = HAL_GetTick();

    can_handle_rx();

    if (!s_upload) {
        return;
    }
    if ((now - s_last_tx_ms) >= CAN_PERIOD_MS) {
        s_last_tx_ms = now;
        Bms_CanSendOnce();
        HAL_Delay(CAN_TX_GAP_MS);        /* 只阻塞 2ms，帧间留空隙 */
    }
}
