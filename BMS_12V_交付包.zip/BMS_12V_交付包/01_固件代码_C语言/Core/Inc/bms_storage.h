/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_storage.h
 * 描述    ：参数掉电保存接口（AT24C02）：容量、限流、阈值、循环次数等
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: AT24C02：I2C 地址 0x50，与 AFE 共用 PB6/PB7
 * 参考手册: AT24C02 数据手册
 * 地址说明: U4=AT24C02，A0/A1/A2 接地 → 器件地址 0x50，WP 接地 → 允许写入
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_STORAGE_H
#define __BMS_STORAGE_H

#include "bms_config.h"

/* 掉电保存的参数集
 * ★ V0x02 起新增 soc_permille / soc_saved_s 两个字段：
 *   目的是让上电时能直接沿用掉电前的真实电量，而不是固定从 50% 起步。
 *   用"千分比"存是为了避免把 float 写进 EEPROM（float 的字节序/精度在不同
 *   编译器下不保证一致，用整数最稳）。*/
typedef struct {
    float    capacity_ah;      /* 电池容量（SOC 分母 / 容量学习基准） */
    float    learned_ah;       /* 最近一次学到的真实容量（SOH 用） */
    float    chg_limit_a;      /* 最大充电电流 */
    float    dsg_limit_a;      /* 最大放电电流 */
    uint16_t ov_mv;            /* 电芯过压阈值 */
    uint16_t uv_mv;            /* 电芯欠压阈值 */
    uint8_t  temp_chg_max;     /* 充电温度上限 */
    uint8_t  temp_dsg_max;     /* 放电温度上限 */
    uint8_t  bal_enable;       /* 均衡总开关 */
    uint8_t  reserved;
    uint16_t charge_count;     /* 累计满充次数（循环次数） */
    uint32_t run_seconds;      /* 累计运行时间（秒） */
    uint16_t soc_permille;     /* ★ 掉电时的 SOC 千分比（0~1000），上电直接沿用 */
    uint16_t soc_valid;        /* ★ 该 SOC 是否可信（1=可信；0=未校准过，别用） */
    uint32_t soc_saved_s;      /* ★ 记录 SOC 时的累计运行秒数（判断数据新鲜度用） */
} BmsParam_t;

extern BmsParam_t  g_param;
extern bool        g_param_loaded;

HAL_StatusTypeDef Sto_Init(void);   /* 探测 EEPROM */
HAL_StatusTypeDef Sto_Load(BmsParam_t *p);   /* 读参数（校验失败则填默认值） */
HAL_StatusTypeDef Sto_Save(const BmsParam_t *p);   /* 写参数（带 CRC，约 15~25ms） */
void              Sto_LoadDefaults(BmsParam_t *p);   /* 把配置默认值填进参数结构体（EEPROM 空白或校验失败时使用） */
void              Sto_Printf(void);   /* 打印当前参数 */

/* 供 Soc_SaveCapacityCb() 调用：只更新容量并落盘 */
void              Sto_SaveCapacity(float capacity_ah);   /* 只更新容量字段并落盘（供容量学习回调调用） */

#endif /* __BMS_STORAGE_H */
