/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_led.h
 * 描述    ：LED 电量条接口：用 LED 点亮数量显示电量百分比（用户需求 1）
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: LED1=PB1; LED2=PB0; LED3=PA7; LED4=PA6; LED5=PA4(红)
 * 参考手册: 无
 * 驱动方式: LED 阳极接 MCU 口、阴极经 470Ω 到 GND，输出高电平点亮
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_LED_H
#define __BMS_LED_H

#include "bms_config.h"

typedef enum {
    LED_MODE_SOC = 0,       /* 按电量点亮对应数量的 LED */
    LED_MODE_MASK,          /* 直接指定点亮掩码 */
    LED_MODE_FAULT,         /* 故障：3 连闪，周期重复 */
    LED_MODE_LOW_BAT,       /* 低电量：整体 1Hz 闪烁 */
    LED_MODE_CALIBRATING,   /* ★ 电量尚未对齐："跑马灯"转圈，明确表示"正在确定电量"，
                               绝不点亮成固定档数（那会被当成真实电量读走） */
    LED_MODE_ALL_OFF
} Led_Mode_t;

void Led_Init(void);   /* LED 初始化：全部熄灭，进入"按电量显示"模式 */
void Led_SetMode(Led_Mode_t mode);   /* 切换 LED 显示模式（电量条 / 指定掩码 / 故障 / 低电量 / 全灭） */
void Led_ShowPercent(float soc_pct);   /* 按电量百分比点亮对应数量的 LED：每 20% 一颗， */
void Led_ShowMask(uint8_t mask);   /* bit0=LED1 ... bit4=LED5 */
void Led_AllOff(void);   /* 全部熄灭 */
void Led_Task(void);   /* 每 10~50ms 调用，处理闪烁 */
uint8_t Led_GetLitCount(void);   /* 取当前点亮的 LED 数量 */

#endif /* __BMS_LED_H */
