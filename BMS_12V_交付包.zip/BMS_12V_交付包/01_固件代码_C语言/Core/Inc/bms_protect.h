/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_protect.h
 * 描述    ：保护与限流接口：最大充电电流、最大放电电流、过温欠温、故障恢复
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: DSG=U9.DSG(Pin1); CHG=U9.CHG(Pin2)
 * 参考手册: TI SLUSBK2I
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_PROTECT_H
#define __BMS_PROTECT_H

#include "bms_config.h"

typedef enum {
    BMS_FLT_NONE = 0,
    BMS_FLT_CELL_OV,        /* 电芯过压 */
    BMS_FLT_CELL_UV,        /* 电芯欠压 */
    BMS_FLT_OC_DSG,         /* 放电过流（软件二级 / AFE OCD） */
    BMS_FLT_SCD,            /* 放电短路 */
    BMS_FLT_OC_CHG,         /* 充电过流（软件） */
    BMS_FLT_TEMP_HIGH,      /* 过温 */
    BMS_FLT_TEMP_LOW,       /* 低温禁充 */
    BMS_FLT_TEMP_SENSOR,    /* 温度传感器故障（开路/短路/读数不可信） */
    BMS_FLT_CELL_WIRE,      /* 单体电压采样回路异常（开路/总和校验不符/数据过期） */
    BMS_FLT_AFE,            /* AFE 内部故障 / 通信异常 */
    BMS_FLT_LOCKED          /* 反复过流被锁定，需 CLR */
} Bms_Fault_t;

/* 传感器健康标志（App 每 10ms 上报一次，Prot_Task 据此闭锁或告警） */
#define PROT_SENSF_TEMP_FAIL   0x01U    /* 温度传感器故障 */
#define PROT_SENSF_CELL_WIRE   0x02U    /* 单体电压采样回路异常 */
/* 注意：电芯不均衡（压差长时间超标）故意不放进故障表——
 * 若记成故障，LED 会一直闪、Bal_Update 也会因为"有故障"而停止均衡，
 * 变成"越不均衡越不均衡"。它只作为 g_cells.unbalance 状态供打印/上报。 */

typedef struct {
    float        chg_limit_a;      /* 最大充电电流（可运行中修改） */
    float        dsg_limit_a;      /* 最大放电电流（可运行中修改） */
    float        current_a;        /* 最近一次电流 */
    uint8_t      counts[BMS_FLT_LOCKED + 1U]; /* 各故障累计次数 */
    uint32_t     retry_cnt;
    bool         locked;
    bool         chg_allowed;
    bool         dsg_allowed;
    Bms_Fault_t  fault;
} Prot_Info_t;

extern Prot_Info_t g_prot;

void        Prot_Init(void);   /* 保护模块初始化：限流值取配置默认值，清所有锁存标志 */
void        Prot_SetLimits(float chg_a, float dsg_a);   /* 运行时修改最大充电/放电电流（会被 App 存进 EEPROM） */
void        Prot_ClearFault(void);   /* 清故障并解锁 */
void        Prot_SetSensorFlags(uint8_t flags);   /* 上报传感器健康标志（App 每 10ms 调用，须在 Prot_Task 之前）（详见函数实现） */
void        Prot_Task(float current_a, const uint16_t *cell_mv,   /* 保护与限流主函数（App 每 10ms 调用一次）（详见函数实现） */
                      int8_t temp_c, uint8_t sys_stat);
const char *Prot_FaultName(Bms_Fault_t f);

#endif /* __BMS_PROTECT_H */
