/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_balance.h
 * 描述    ：被动均衡接口：写 CELLBAL1 控制 BQ76920 内置均衡 FET
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: AFE 内部均衡 FET（经 R22~R25 1kΩ 采样电阻）
 * 参考手册: TI SLUSBK2I
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_BALANCE_H
#define __BMS_BALANCE_H

#include "bms_config.h"

typedef struct {
    bool    active;         /* 当前是否有均衡在动作 */
    uint8_t mask;           /* 想均衡谁（逻辑掩码，AFE 槽位） */
    uint8_t applied_mask;   /* 实际写进 CELLBAL1 的掩码（测量窗口暂停期间为 0） */
    bool    measuring;      /* 是否正处于「暂停均衡、让出测量窗口」时段 */
    uint16_t delta_mv;      /* 当前最大压差 */
    uint16_t target_mv;     /* 本轮均衡参考（最低电芯电压） */
} Bal_Info_t;

extern Bal_Info_t g_bal;

void Bal_Init(void);   /* 均衡模块初始化：关闭所有均衡 FET，清空状态 */
void Bal_Update(const uint16_t *cell_mv, int8_t temp_c, float current_a, bool fault);   /* 均衡策略主函数（App 每 5s 调用一次）（详见函数实现） */
void Bal_Task(void);   /* 均衡相位控制（App 每 10ms 调用一次）：按开/停相位写 CELLBAL1，周期性让出测量窗口（详见函数实现） */
void Bal_Stop(void);   /* 立即停止均衡（写 CELLBAL1 = 0） */

#endif /* __BMS_BALANCE_H */
