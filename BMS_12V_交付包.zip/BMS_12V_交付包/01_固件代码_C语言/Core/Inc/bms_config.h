/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_config.h
 * 描述    ：BMS 全局配置：硬件资源映射、保护阈值、电流限值、算法参数（改参数只看这个文件）
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 硬件依据：嘉立创EDA工程 BMS for 12V Battery（Schematic2/Board2 V1.0）
 * 参考手册: 无（纯配置头文件）
 * 引脚分配: AFE=I2C1(PB6/PB7); LED=PB1/PB0/PA7/PA6/PA4; ALERT=PA1; CAN=PB8/PB9; UART=PA9/PA10
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_CONFIG_H
#define __BMS_CONFIG_H

#include "main.h"
#include <stdbool.h>
#include <stdint.h>

/* =========================================================================
 * 1. 硬件资源映射
 * ========================================================================= */

/* --- I2C：PB6=SCL / PB7=SDA（板上 R12/R13 4.7k 上拉；与 AT24C02 共用总线） --- */
#define BQ_I2C              hi2c1
#define BQ_I2C_TIMEOUT_MS   50U

/* --- BQ76920 7 位地址 0x08 --- */
#define BQ_I2C_ADDR7        0x08U
#define BQ_I2C_ADDR8        (BQ_I2C_ADDR7 << 1)

/* --- 调试串口：PA9=TX / PA10=RX，115200 8N1 --- */
#define BMS_UART            huart1
#define BMS_UART_BAUD       115200U

/* --- ALERT 引脚：PA1，EXTI 上升沿（BQ769x0 ALERT 为高有效） --- */
#define BMS_ALERT_PORT      GPIOA
#define BMS_ALERT_PIN       GPIO_PIN_1

/* LED 电量条：阳极接 MCU 口、阴极经 470Ω 到 GND，输出高电平点亮。
 * 具体引脚在 bms_led.c 的 s_led[] 表里定义：
 *   LED1 = PB1（20%）  LED2 = PB0（40%）  LED3 = PA7（60%）
 *   LED4 = PA6（80%）  LED5 = PA4（100%，红色）                                */
#define BMS_LED_COUNT       5U

/* =========================================================================
 * 2. 电池组参数（★ 必须按实际电芯修改 ★）
 *    本固件当前配置：亿纬动力 C33（33140 圆柱磷酸铁锂）2 并 4 串
 *      单体：3.2V / 15Ah，φ33.3×140.8mm，直流内阻 ≤8mΩ，最大持续充/放 2C/3C
 *      电池组：12.8V / 30Ah / 384Wh，直流内阻 ≈16mΩ（= 8mΩ÷2×4）
 *      单体截止：充到 3.65V，放到 2.5V
 *    ★ 2P 的含义：每"节"由 2 只电芯并联，BMS 只能测到并联后的电压，
 *      所以对外的节数（BMS_CELL_COUNT）仍然是 4，只有容量和电流能力翻倍。
 * ========================================================================= */
#define BMS_CELL_COUNT      4U          /* 4S：12.8V 标称 */
#define BMS_PACK_PARALLEL   2U          /* 2P：每节 2 只电芯并联（仅用于换算与说明） */
#define BMS_CAPACITY_AH     30.0f       /* 额定容量 Ah = 15Ah × 2P */
#define BMS_COULOMB_EFF     0.99f       /* 库仑效率（充电时对积分电量打折） */

/* 4S 接法下的 AFE 槽位映射（对应原理图 VC4-VC3 短接、CELL4 = VC5-VC4）
 * 数组下标 = 第几节电芯（0 起），值 = AFE 的内部槽位（0=VC1 ... 4=VC5） */
#define BMS_CELL_SLOT_0     0U          /* 电芯1 → VC1 槽 */
#define BMS_CELL_SLOT_1     1U          /* 电芯2 → VC2 槽 */
#define BMS_CELL_SLOT_2     2U          /* 电芯3 → VC3 槽 */
#define BMS_CELL_SLOT_3     4U          /* 电芯4 → VC5 槽（★不是 3★） */

/* AFE 中被短接的空槽（VC4-VC3 恒 0V）：禁止对它做均衡、禁止参与欠压判定 */
#define BMS_BAL_SKIP_MASK   0x08U       /* bit3 = AFE 第 4 槽 */

/* =========================================================================
 * 3. 采样电阻
 * ========================================================================= */
#define BMS_RSENSE_MOHM     1.0f        /* R17 = 1mΩ。改成 0.5/2mΩ 时电流换算自动跟随 */
#define BMS_RSENSE_RATED_A  55.0f       /* R17 额定 3W → 持续电流上限约 55A（硬件限制） */

/* CC（库仑计）换算
 * 数据手册：CC 读数 LSB = 8.44 µV；积分/更新周期 250 ms。
 * @1mΩ：1 LSB = 8.44 mA，折算电荷 = 8.44mA × 250ms = 0.5861 µAh
 * 若实测电量与真实值差 250 倍，把 BMS_CC_WINDOW_MS 改成 1.0f 即可（说明该版本读数为积分值） */
#define BMS_CC_WINDOW_MS    250.0f
#define BMS_CC_LSB_UV       8.44f

/* =========================================================================
 * 4. 电芯过压 / 欠压（AFE 硬件保护）
 * ========================================================================= */
#define BMS_CELL_OV_MV      3650U       /* LiFePO4 上限；三元电池改 4200 */
#define BMS_CELL_UV_MV      2500U       /* LiFePO4 下限；三元电池改 2800 */
#define BMS_OV_DELAY_CODE   0x00U       /* PROTECT3[5:4]：0=1s  1=2s  2=4s  3=8s */
#define BMS_UV_DELAY_CODE   0x01U       /* PROTECT3[7:6]：0=1s  1=4s  2=8s  3=16s */

/* 满充 / 放空判定（用于 SOC 归零归满与容量学习） */
#define BMS_FULL_DETECT_MV  3550U       /* 最高电芯达到此值且电流很小 → 判定满充 */
#define BMS_FULL_DETECT_A   1.0f        /* 满充判定电流门槛（30Ah 的 C/30；原 10Ah 配置是 0.3A） */
#define BMS_FULL_HOLD_MS    30000U      /* 条件需连续保持 30s */
#define BMS_EMPTY_DETECT_MV 2650U       /* 最低电芯低于此值 → 判定放空 */
#define BMS_EMPTY_HOLD_MS   5000U

/* =========================================================================
 * 5. 电流限制  ★用户需求：最大充电电流 / 最大放电电流★
 * ========================================================================= */
/* 初值（可在运行中通过串口 "SET CHG xx" / "SET DSG xx" 修改）
 *
 * ★★ 2P4S C33 的电流能力与现有硬件的冲突（务必先看这段）★★
 *   电芯能力：充电 2C/单体 → 2P 共 60A；放电 3C/单体 → 2P 共 90A
 *   硬件限制：R17 = 1mΩ/3W，P=I²R → 持续电流上限 ≈ 55A
 *             （90A 时耗散 8.1W，100A 时 10W，会烧采样电阻）
 *   所以默认按硬件能力设成 50A / 30A。要跑满 90A 必须同时改三处：
 *     ① 换采样电阻：0.5mΩ/5W 以上（90A 时耗散 4.05W）
 *     ② BMS_RSENSE_MOHM 改成 0.5
 *     ③ BMS_OCD_THRESH_CODE 重新选档（0.5mΩ 时 0x0F=100mV → 200A，够用）
 *   另外：BQ76920 的 OCD 最大档只有 100mV，@1mΩ 就是 100A，
 *        也就是说 1mΩ 采样电阻下硬件过流保护的天花板是 100A。 */
#define BMS_DISCHARGE_MAX_A 50.0f       /* 最大放电电流（受 R17 额定功率限制） */
#define BMS_CHARGE_MAX_A    30.0f       /* 最大充电电流 = 1C（电芯可到 60A，但受 R17 限制） */

/* 放电过流：BQ76920 有硬件保护（OCD）+ 短路保护（SCD）
 * PROTECT2[3:0] OCD 阈值（RSNS=1，单位 mV，@1mΩ 数值=A）：
 *   0x0=17 0x1=22 0x2=28 0x3=33 0x4=39 0x5=44 0x6=50 0x7=56
 *   0x8=61 0x9=67 0xA=72 0xB=78 0xC=83 0xD=89 0xE=94 0xF=100
 * PROTECT2[6:4] OCD 延时(ms)：0x0=8 0x1=20 0x2=40 0x3=80 0x4=160 0x5=320 0x6=640 0x7=1280
 * PROTECT1[2:0] SCD 阈值（RSNS=1，mV）：0x0=44 0x1=67 0x2=89 0x3=111 0x4=133 0x5=155 0x6=178 0x7=200
 * PROTECT1[4:3] SCD 延时：0x0=70µs 0x1=100µs 0x2=200µs 0x3=400µs                        */
#define BMS_OCD_THRESH_CODE 0x06U       /* 50mV → 50A @1mΩ，与 BMS_DISCHARGE_MAX_A 对齐 */
#define BMS_OCD_DELAY_CODE  0x05U       /* 320 ms */
#define BMS_SCD_THRESH_CODE 0x03U       /* 111mV → 111A @1mΩ（短路保护） */
#define BMS_SCD_DELAY_CODE  0x02U       /* 200 µs */
#define BMS_RSNS_BIT        0x01U       /* PROTECT1[7]：1=上限量程(±200mV)，与 CC 满量程匹配 */

/* 充电过流：BQ76920 没有硬件充电过流保护 → 必须由软件实现 */
#define BMS_OC_SW_DELAY_MS  100U        /* 软件过流去抖时间 */
#define BMS_OC_ESCAPE_MS    200U        /* 超过限值但未达去抖时间时，若继续超出则累计 */
#define BMS_OC_RETRY_MS     5000U       /* 过流关断后等待多久尝试恢复 */
#define BMS_OC_MAX_RETRY    3U          /* 连续失败次数，超过则锁定（需 CLR 命令或断电） */

/* 过流恢复时要求电流降到限值的百分比以下 */
#define BMS_OC_RECOVER_RATIO 0.80f

/* =========================================================================
 * 6. 温度保护
 * ========================================================================= */
#define BMS_NTC_R0_OHM      10000.0f    /* 外接 NTC 标称 10kΩ @25℃（CN3） */
#define BMS_NTC_B           3435.0f     /* NTC 的 B 值，按实际器件修改（103AT-2 = 3435） */
/* 亿纬 C33 官方工作温度：充电 0~55℃，放电 -20~60℃
 * 这里充电上限取 50℃（官方 55℃ 留 5℃ 余量），要更激进可改到 55 */
#define BMS_TEMP_CHG_MIN    0          /* ℃：低于此温度禁止充电（LFP 低温析锂） */
#define BMS_TEMP_CHG_MAX    50         /* ℃：高于此温度禁止充电 */
#define BMS_TEMP_DSG_MAX    60         /* ℃：高于此温度禁止放电 */
#define BMS_TEMP_VALID_MIN  (-40)
#define BMS_TEMP_VALID_MAX  100

/* =========================================================================
 * 7. 均衡参数
 * ========================================================================= */
#define BMS_BAL_START_MV    3400U       /* 最高电芯达到此值才开始均衡 */
#define BMS_BAL_DELTA_MV    30U         /* 压差门槛：高于最低电芯 30mV 以上才泄放 */
#define BMS_BAL_MIN_MV      2800U       /* 任何电芯低于此值立即停止均衡 */
#define BMS_BAL_TEMP_MIN    5           /* ℃ */
#define BMS_BAL_TEMP_MAX    45          /* ℃ */
#define BMS_BAL_MAX_CURRENT_A 1.0f      /* 电流绝对值超过此值不做均衡（充电中放宽见代码） */
#define BMS_BAL_PERIOD_MS   5000U       /* 均衡策略重算周期（避免抖动） */

/* =========================================================================
 * 8. SOC / 调度周期
 * ========================================================================= */
#define BMS_TASK_FAST_MS    10U         /* 状态轮询（含 CC_READY / 故障位） */
#define BMS_TASK_CELL_MS    250U        /* 电芯电压刷新（AFE 数据更新周期） */
#define BMS_TASK_SLOW_MS    1000U       /* 温度、LED、保护评估 */
#define BMS_OCV_REST_A      0.05f       /* 判定“静置”的电流阈值 */
#define BMS_OCV_REST_MS     1800000U    /* 静置 30min 后才允许 OCV 修正 */
#define BMS_OCV_WEIGHT      0.10f       /* OCV 修正权重（LiFePO4 平台平坦，权重不宜大） */

/* ---- 上电 SOC 对齐（★ 解决"上电固定按 50% 起步、仪表显示假电量"的问题）----
 *   原设计：Soc_Init() 写死 50%，必须静置 30min 才由 OCV 修正到真实值。
 *           结果满电待发时仪表显示 50%，车手会误判续航。
 *   现设计（两条路，优先用第一条）：
 *     ① EEPROM 恢复：掉电前把 SOC 千分比存进 AT24C02，上电直接沿用（不受极化影响，最准）
 *     ② 上电快速 OCV：EEPROM 无数据（首次上电/换板/数据损坏）时，
 *        发现"电流小且电压稳定"就立刻采信 OCV，不必等 30 分钟
 *   ★ 为什么不能只靠 ② ：刚跑完车立刻重启，端电压还带着极化（放电后偏低），
 *     所以要同时满足"电流小"+"电压稳定"两个条件，详见 Soc_OnBootOcv()。      */
#define BMS_OCV_BOOT_MS         15000U  /* 上电快速修正：静置稳定至少持续此时长(ms) */
#define BMS_OCV_BOOT_WIN        8U      /* 稳定性判据窗口点数（8 × 250ms = 2s） */
#define BMS_OCV_BOOT_STABLE_MV  20U     /* 窗口内平均电压极差 < 此值才认为"电压稳定" mV */
#define BMS_OCV_BOOT_HOLD       3U      /* 稳定判据需连续满足次数（3 × 2s = 6s） */
#define BMS_OCV_BOOT_WEIGHT     0.50f   /* 上电修正权重（比 30min 慢修正的 0.1 激进得多） */
#define BMS_OCV_BOOT_SNAP_PCT   8.0f    /* 与记录值差异 > 此值 → 直接采信 OCV（记录不可信） */
#define BMS_SOC_SAVE_DELTA_PCT  1.0f    /* SOC 变化超过此值才落盘（保护 EEPROM 擦写寿命） */
#define BMS_SOC_SAVE_MIN_MS     60000U  /* 两次 SOC 落盘的最小间隔（60s），防止频繁擦写 */
/* ★ $BMS 帧里表示"电量未知"的哨兵值（SOC×10 字段）。
 *   0xFFFF = 65535，正常 SOC 只会是 0~1000，不会冲突。
 *   上位机看到它就应显示"未知"，而不是画成 6553.5%。 */
#define BMS_SOC_UNKNOWN_X10     65535U

/* ---- ★ 上电 SOC 一级判据：待测电芯（开尔文取样点）判"冷启动" ----
 *   为什么需要它：Soc_Init() 里的 50% 只是"还不知道电量"的占位值。
 *   如果 EEPROM 无记录（首次上电 / 换板 / 数据损坏），BMS 就真的没有信息，
 *   但仪表和 LED 不能因此骗人 —— 所以用硬件给出一个可靠的"系统刚从彻底断电
 *   状态上电"的证据，从而把"无信息"这个状态显式表达出来（LED 转圈 + 报
 *   BMS_SOC_UNKNOWN），而不是随手填一个 50%。
 *
 *   取点位置：R17（1mΩ 采样电阻）两端的开尔文取样线上。
 *     · 冷启动：MCU 刚由 POR 释放 → 这两个脚上电前是高阻，此刻读到 0
 *     · 热重启：系统一直在电（软复位/看门狗复位），电流路径上是真实差分电压
 *   注意不能用 MCU 自身引脚的状态寄存器代替：引脚配置在启动代码里被重置，
 *   所有复位源看起来都一样，只有"先于配置就存在的物理量"才能区分。
 *
 *   ADC 映射：3.3V 参考、12bit → 满量程 4095 对应约 ±64.8mV（PGA=1 或外置×51.2）
 *            实测按 BMS_STARTUP_ADC_NEUTRAL 附近读数为准。
 *   若硬件上这两个脚没有接到 ADC（例如只接到 INA/比较器），把本宏置 0，
 *   代码自动退回"仅 EEPROM + OCV"两条老路（行为与上一版一致）。 */
#define BMS_COLDSTART_DETECT    1U      /* 1=启用待测电芯冷启动检测；0=关闭 */
#define BMS_STARTUP_ADC_NEUTRAL 2048U   /* ADC 零点码（对应 0V 差分） */
#define BMS_STARTUP_ADC_DEADBAND 48U    /* 死区：±48 LSB ≈ ±0.77mV。上电 0V 与<1mV 噪声都算"冷" */
#define BMS_STARTUP_ADC_MIN     16U     /* 有效读数下限（低于此值视为引脚未接/悬空） */
#define BMS_STARTUP_ADC_MAX     4080U   /* 有效读数上限 */
/* 待测电芯所用的 ADC 句柄（CubeMX 里配置该通道后生成的句柄名，按实际改） */
#define BMS_STARTUP_ADC_HANDLE  hadc1

/* =========================================================================
 * 9. CAN 通信（TJA1050，接 PB8=RX / PB9=TX，CubeMX 里 CAN1 必须重映射）
 * ========================================================================= */
#define BMS_CAN_ENABLE      1U          /* 0=完全不带 CAN 编译 */
#define BMS_CAN_PERIOD_MS   200U        /* 一轮 7 帧的上传周期 */
/* 协议沿用厂家 BMS 开发板的 CAN 帧格式，可直接用他们提供的上位机软件 */

/* =========================================================================
 * 10. 参数掉电保存（AT24C02，第 1 页原理图上的 U4，与 AFE 共用 I2C1）
 * ========================================================================= */
#define BMS_USE_EEPROM      1U
#define BMS_EEPROM_ADDR7    0x50U       /* AT24C02 的 7 位地址 */
#define BMS_PARAM_SAVE_MS   600000U     /* 运行时间等慢变量落盘周期（10min） */

/* =========================================================================
 * 11. 独立看门狗
 * ========================================================================= */
#define BMS_USE_WDG         1U
#define BMS_WDG_TIMEOUT_MS  2000U

/* =========================================================================
 * 12. 均衡：禁止相邻电芯同时均衡
 *   参考厂家 BMS 工程结论：AFE 相邻通道的采样线共用滤波电阻与内部泄放通路，
 *   两节相邻电芯同时泄放会互相影响电压测量。置 0 可恢复"所有超标电芯一起均衡"
 *   （速度快一倍，但测量会受扰）。
 * ========================================================================= */
#define BMS_BAL_NO_ADJACENT 1U

/* =========================================================================
 * 13. SHIP 模式进入时序
 *   0 = 写 SHUT_A 后再写 SHUT_A+SHUT_B（按数据手册描述）
 *   1 = 先写 SHUT_B 再写 SHUT_A（厂家参考工程的写法）
 *   若发 SHIP 命令后芯片没有休眠，把这个宏换成另一个即可。
 * ========================================================================= */
#define BMS_SHIP_SEQ_ORDER  0U

/* =========================================================================
 * 14. 单体电压检测（bms_cells.c）
 *     硬件依据：电芯抽头 → R22~R25(1kΩ) → U9.VC1..VC5，各脚对 AGND 挂 100nF
 * ========================================================================= */
/* --- 两级阈值：预警级比 AFE 跳闸阈值早，用来提前告警（真正的断电仍由 AFE 执行） --- */
#define BMS_CELL_OV_WARN_MV      3550U      /* 过压预警（AFE 跳闸阈值 = BMS_CELL_OV_MV 3650） */
#define BMS_CELL_UV_WARN_MV      2700U      /* 欠压预警（AFE 跳闸阈值 = BMS_CELL_UV_MV 2500） */

/* --- 去抖：连续 N 次（×250ms）都满足条件才认定 --- */
#define BMS_CELL_OV_DEBOUNCE     3U         /* 越限 750ms */
#define BMS_CELL_UV_DEBOUNCE     3U
#define BMS_CELL_WARN_DEBOUNCE   8U         /* 预警 2s */

/* --- 回差：解除判定要比触发判定更严格，避免在阈值上反复跳 --- */
#define BMS_CELL_HYST_MV         100U

/* --- 合理性检查：真实电芯不可能落在这个区间之外 → 一定是采样回路异常 --- */
#define BMS_CELL_PLAUSIBLE_MIN_MV 1200U     /* 低于此值：采样线开路 / 电芯失效 */
#define BMS_CELL_PLAUSIBLE_MAX_MV 4300U     /* 高于此值：采样线接错 / 高压串入 */

/* --- 采样回路整体校验：Σ(单节) 应与组端电压一致 --- */
#define BMS_CELL_SUM_TOL_MV      150U       /* 允许偏差 */
#define BMS_CELL_SUM_BAD_CNT     4U         /* 连续 4 次（1s）不符才报错 */

/* --- 压差（不均衡）告警 --- */
#define BMS_CELL_DELTA_WARN_MV   80U        /* 压差超过此值 */
#define BMS_CELL_DELTA_HOLD_MS   60000U     /* 且持续 60s → 判定真的不均衡 */

/* --- 采样数据新鲜度：I2C 连续读失败超过这个时长，就认为读到的是旧数据 --- */
#define BMS_CELL_STALE_MS        2000U

/* --- 均衡干扰窗口（★重要）---
 * 均衡电流流过 R22~R25，被均衡那一节的 AFE 读数会被压低；
 * AFE 的 ADC 每 250ms 更新一次，所以均衡状态改变后要等一个转换周期读数才可信 */
#define BMS_CELL_BAL_SETTLE_MS   300U       /* 均衡掩码变化后的屏蔽时间 */
#define BMS_CELL_HOLD_MAX_MS     30000U     /* 被均衡电芯最多沿用上次可信值 30s */

/* --- 采样线开路诊断（CELLDIAG 命令用） --- */
#define BMS_CELL_DIAG_MAX_A      0.5f       /* 要求静置：|电流| 小于此值才允许自检 */
#define BMS_CELL_DIAG_ON_MS      600U       /* 每节均衡施加时间 */
#define BMS_CELL_DIAG_SETTLE_MS  600U       /* 每次切换后的稳定等待 */

/* =========================================================================
 * 15. 温度检测（bms_temp.c）
 * ========================================================================= */
#define BMS_TEMP_FILTER_N        4U         /* 滑动平均点数（每 1s 一点） */
#define BMS_TEMP_RATE_MAX        8          /* 单次采样最大允许跳变 ℃，超过判为干扰并丢弃 */
#define BMS_TEMP_REJECT_MAX      3U         /* 连续丢弃次数上限，超过则判传感器不可信 */

/* TS1 通道电气参数（换算阻值必须用这三个值，不是 NTC 自己的 B 值）
 * R(NTC) = 上拉电阻 × V / (VREF − V)，V = ADC × 382µV */
#define BMS_NTC_PULLUP_OHM       10000.0f   /* AFE TS1 引脚内部上拉电阻（数据手册典型 10k） */
#define BMS_NTC_VREF             3.3f       /* 上拉电源（REGOUT/内部稳压）标称电压 */
#define BMS_TS1_LSB_UV           382.0f     /* TS1 通道 1 LSB = 382 µV（数据手册） */

/* NTC 阻值合理性区间（用于开路/短路诊断） */
#define BMS_NTC_R_OPEN_OHM       200000.0f  /* 阻值高于此值 = 开路（未接/断线） */
#define BMS_NTC_R_SHORT_OHM      300.0f     /* 阻值低于此值 = 短路到地 */

/* 温度分区（禁充 / 禁放 / 正常） */
#define BMS_TEMP_DSG_MIN         (-20)      /* ℃：低于此温度禁止放电（LiFePO4 低温析锂） */
#define BMS_TEMP_OT_HIGH         55         /* ℃：高温预警（禁充，允许放电并告警） */
/* BMS_TEMP_CHG_MIN / BMS_TEMP_CHG_MAX = 0 / 50（见第 6 节）；BMS_TEMP_DSG_MAX = 60 */

/* 传感器故障时的策略：1 = 保守处理（按过温禁充放，需 CLR 或修好后恢复）
 *                   0 = 仅告警，不限制充放电（风险自负） */
#define BMS_TEMP_SENSOR_FAILSAFE 1U

/* 开机宽限：初始化后这段时间内不判「传感器故障」。
 * 原因：第一次采样要等 1s，若不宽限，上电瞬间就会把充放电全锁掉 */
#define BMS_TEMP_BOOT_GRACE_MS   3000U

/* 芯片内部温度：0x2C(TS1) 是外部 NTC 与内部温度传感器「共用」的 ADC 通道，
 * 由 SYS_CTRL1.TEMP_SEL 选择。本板 TEMP_SEL=1（用外部 NTC），
 * 所以内部温度必须临时切到 TEMP_SEL=0 才能读 —— 只在 TEMP DIE 命令里按需读 */
#define BMS_TEMP_DIE_SETTLE_MS   300U

/* =========================================================================
 * 16. 均衡"测量窗口"（bms_balance.c）
 *     为了拿到准确的单体电压：均衡连续开 BMS_BAL_ON_MS 后暂停 BMS_BAL_PAUSE_MS，
 *     在暂停期间读到的电压才是没被均衡电流污染的（AFE 250ms 更新一次）
 * ========================================================================= */
#define BMS_BAL_ON_MS            5000U      /* 连续均衡时长 */
#define BMS_BAL_PAUSE_MS         900U       /* 暂停时长。★必须 > 250ms(ADC 更新周期) + 300ms(屏蔽窗口)，
                                             *   也就是「真正可信的窗口」要够宽，能覆盖至少 2 个 250ms 采样点，
                                             *   否则 250ms 的电压刷新可能整周期落在屏蔽窗口里，一直拿不到真值 */
#define BMS_BAL_OV_GUARD_MV      200U       /* 距 OV 跳闸阈值不足此值时，禁止对最高芯均衡 */

#endif /* __BMS_CONFIG_H */
