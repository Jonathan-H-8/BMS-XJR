/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_app.h
 * 描述    ：应用层接口：初始化、主循环调度、中断回调、串口命令行
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 见各模块
 * 参考手册: 无
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_APP_H
#define __BMS_APP_H

#include "bms_config.h"

void BMS_Init(void);   /* BMS 总初始化（在 main() 里调用一次）（详见函数实现） */
void BMS_Loop(void);   /* BMS 主循环（while(1) 里反复调用）：所有任务都在这里调度，不阻塞 */
void BMS_AlertIsr(void);   /* ALERT 引脚中断回调：只置一个标志，真正的处理放在主循环（不要在中断里做 I2C） */
void BMS_UartRxByte(uint8_t byte);   /* 串口接收一字节（在 HAL_UART_RxCpltCallback 里调用），遇回车换行即组成一条命令 */

/* ---- ★ 待测电芯（R17 开尔文取样点）冷启动检测 ----
 * BMS_Init() 内部会自动采样一次，正常情况下无需手工调用。
 * 下面两个接口用于"把采样挪到 main() 里、紧贴 MX_ADC1_Init() 之后"的场景，
 * 以及查询判定结果（例如打印到开机日志）。 */
void BMS_SampleStartupCell(void);   /* 采一次上电样本（须在任何 AFE/I2C 初始化之前调用） */
int  BMS_IsColdBoot(void);          /* 1=待测电芯确认本次为冷启动  0=热重启或未启用检测 */

#endif /* __BMS_APP_H */
