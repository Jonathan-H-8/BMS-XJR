/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_debug.h
 * 描述    ：串口日志接口（USART1）：状态打印与命令帮助
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: PA9=USART1_TX; PA10=USART1_RX，115200 8N1
 * 参考手册: 无
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_DEBUG_H
#define __BMS_DEBUG_H

#include "bms_config.h"

void BMS_Log(const char *fmt, ...);   /* 串口格式化打印（内部用 vsnprintf 组包后直接 HAL 发送，不依赖 printf 重定向） */
void BMS_PrintStatus(void);   /* 打印完整状态：电压、电流、温度、SOC、FET、均衡、限值、故障、校准值 */
void BMS_PrintCsv(void);      /* 打印一帧机器可读数据（$BMS,...*XX），供 PC 端实时看板解析 */
void BMS_PrintHelp(void);   /* 打印串口命令帮助 */

#endif /* __BMS_DEBUG_H */
