/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_wdg.h
 * 描述    ：看门狗接口（IWDG）：2s 超时，只在 AFE 通信健康时才喂狗
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 无（芯片内部 IWDG）
 * 参考手册: STM32F10x 参考手册
 * 超时计算: IWDG 时钟 40kHz，预分频 64、重装 1250 → 64×1250/40000 = 2.0s
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_WDG_H
#define __BMS_WDG_H

#include "bms_config.h"

void Bms_WdgInit(void);   /* 2s 超时 */
void Bms_WdgFeed(void);   /* 在 BMS_Loop() 里调用 */
void Bms_WdgReportI2c(bool ok);   /* 每次 AFE 通信后调用，失败过多则不再喂狗 */
uint8_t Bms_WdgGetFailCount(void);   /* 取连续通信失败次数 */

#endif /* __BMS_WDG_H */
