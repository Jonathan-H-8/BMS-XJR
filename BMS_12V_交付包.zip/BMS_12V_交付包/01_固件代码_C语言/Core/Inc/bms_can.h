/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_can.h
 * 描述    ：CAN 通信接口（TJA1050）：7 帧上传 + 下行控制命令，协议兼容厂家 CAN 上位机
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: TJA1050：PB8=CAN_RX; PB9=CAN_TX（CubeMX 里 CAN1 必须重映射）
 * 参考手册: 厂家 BMS_s940 例程
 * 波特率  : 500kbps（APB1=36MHz，预分频4、BS1=9tq、BS2=8tq、SJW=1tq）
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_CAN_H
#define __BMS_CAN_H

#include "bms_config.h"

void Bms_CanInit(void);   /* CAN 初始化：配置滤波器（全通）→ 启动 → 打开接收中断 */
void Bms_CanTask(void);   /* 周期调用：发 7 帧 + 收控制命令 */
void Bms_CanSetUpload(bool on);   /* 设置是否周期上传（对应下行命令 0x02/0x03） */
bool Bms_CanIsUploadOn(void);   /* 查询当前是否在上传 */
void Bms_CanSendOnce(void);   /* 立刻发一帧组 */
uint32_t Bms_CanGetRxCount(void);   /* 取累计收到的 CAN 帧数（调总线用） */

#endif /* __BMS_CAN_H */
