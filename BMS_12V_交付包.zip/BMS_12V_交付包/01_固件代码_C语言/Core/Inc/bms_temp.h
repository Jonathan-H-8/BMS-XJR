/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_temp.h
 * 描述    ：温度检测接口：NTC 阻值/温度换算、开路短路诊断、滑动滤波、温度分区与限值输出
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: CN3 外接 NTC(10k@25℃,B=3435) → U9.TS1(Pin?)；TS1 引脚内部 10k 上拉，
 *           NTC 另一端接 GND。TS1 同时接 KEY1+D3+R7(33K) 作 SHIP 唤醒，
 *           按键按下期间 TS1 被抬高 → 那段时间的温度读数不可信（本模块自动屏蔽）
 * 参考手册: TI SLUSBK2I（TS1 寄存器 0x2C，1 LSB = 382 µV；SYS_CTRL1.TEMP_SEL 选择通道）
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_TEMP_H
#define __BMS_TEMP_H

#include "bms_config.h"

/* ---------------- 传感器状态 ---------------- */
typedef enum {
    TEMP_SENS_OK = 0,       /* 正常 */
    TEMP_SENS_OPEN,         /* NTC 开路/未接：TS1 被上拉到 3.3V，会误读成极低温 */
    TEMP_SENS_SHORT,        /* NTC 短路到地：TS1 为 0V，会误读成极高温 */
    TEMP_SENS_RANGE,        /* 换算出的阻值超出合理性范围 */
    TEMP_SENS_UNSTABLE,     /* 连续多次读数跳变（按键 / 干扰 / 接触不良） */
    TEMP_SENS_STALE         /* I2C 读取失败 */
} Temp_Sens_t;

/* ---------------- 温度分区（决定允许充放电） ---------------- */
typedef enum {
    TEMP_ZONE_NORMAL = 0,   /* 正常：可充可放 */
    TEMP_ZONE_LOW,          /* 低温（< 0℃）：禁充，可放 */
    TEMP_ZONE_CRIT_LOW,     /* 极低温（< -20℃）：禁充放 */
    TEMP_ZONE_HIGH_CHG,     /* 高温（≥ 45℃）：禁充，可放并告警 */
    TEMP_ZONE_HIGH_BOTH,    /* 过温（≥ 60℃）：禁充放 */
    TEMP_ZONE_FAULT         /* 传感器故障 → 按 BMS_TEMP_SENSOR_FAILSAFE 处理 */
} Temp_Zone_t;

/* ---------------- 检测结果 ---------------- */
typedef struct {
    int8_t      cell_c;         /* 外部 NTC 温度（滑动平均后，℃） */
    int8_t      raw_c;          /* 本次未滤波的温度 */
    float       ntc_ohm;        /* 由 TS1 电压换算出的 NTC 阻值 */
    int16_t     ts1_adc;        /* TS1 原始 ADC 码（0~16383） */
    uint16_t    ts1_mv;         /* TS1 电压 mV */
    Temp_Sens_t sens;           /* 传感器状态 */
    Temp_Zone_t zone;           /* 当前温度分区 */
    bool        valid;          /* 温度是否可信（可作为保护判据） */
    int8_t      die_c;          /* 芯片内部温度（仅 TEMP DIE 命令手动读，用于看板级温升） */
    bool        die_valid;
    uint32_t    samples;        /* 累计采样次数 */
    uint32_t    rejects;        /* 累计丢弃样本数 */
    bool        key_mask;       /* 本次是否因跳变被屏蔽（多为按压 SHIP 键） */
} Temp_Info_t;

extern Temp_Info_t g_temp;

void        Temp_Init(void);   /* 温度模块初始化：清滤波缓冲、清状态，分区取正常区 */
void        Temp_Update(void);   /* 温度检测主函数（App 每 1s 调用一次）（详见函数实现） */
bool        Temp_Valid(void);   /* 温度是否可信 */
int8_t      Temp_GetCellC(void);   /* 取电芯温度 ℃（不可信时返回最近一次可信值） */
int8_t      Temp_GetWorstC(void);   /* 取用于保护的最保守温度（当前只有一路 NTC，与 GetCellC 相同）（详见函数实现） */
Temp_Zone_t Temp_GetZone(void);   /* 取当前温度分区 */
bool        Temp_ChgAllowed(void);   /* 按温度分区判断是否允许充电 */
bool        Temp_DsgAllowed(void);   /* 按温度分区判断是否允许放电 */
bool        Temp_SensorFault(void);   /* 温度传感器是否存在故障（供保护模块决定是否闭锁） */

const char *Temp_SensName(Temp_Sens_t s);   /* 传感器状态码 → 字符串（打印用） */
const char *Temp_ZoneName(Temp_Zone_t z);   /* 温度分区 → 字符串（打印用） */
void        Temp_Print(void);   /* 打印一页温度检测结果：TS1 电压、NTC 阻值、温度、分区、状态 */
void        Temp_ReadDie(void);   /* 读一次芯片内部温度（TEMP DIE 命令）：临时把 TEMP_SEL 切到内部传感器 */

#endif /* __BMS_TEMP_H */
