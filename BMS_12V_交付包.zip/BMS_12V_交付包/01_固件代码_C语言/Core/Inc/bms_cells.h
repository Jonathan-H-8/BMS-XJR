/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_cells.h
 * 描述    ：单体电压检测接口：逐节过压/欠压两级判定、采样回路开路诊断、压差统计
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 电芯抽头 → R22~R25(1kΩ) → U9.VC1..VC5；各脚对 AGND 挂 C12~C15(100nF)
 *           4S 映射：电芯1/2/3/4 → AFE 槽 1/2/3/5（VC4-VC3 短接，第 4 槽是空槽）
 * 参考手册: TI SLUSBK2I（VC1..VC5 = 0x0C~0x15；BAT = 0x2A）
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_CELLS_H
#define __BMS_CELLS_H

#include "bms_config.h"

/* ---------------- 采样回路状态 ---------------- */
typedef enum {
    CELLS_OK = 0,           /* 采样正常 */
    CELLS_ERR_SUM,          /* Σ(单节) 与组端电压不符 → 采样回路异常 */
    CELLS_ERR_LOW,          /* 某节读数低于合理性下限 → 疑采样线开路 */
    CELLS_ERR_HIGH,         /* 某节读数高于合理性上限 → 疑接错/串入高压 */
    CELLS_ERR_BLIND,        /* 长期拿不到可信读数（均衡干扰或其他原因） */
    CELLS_ERR_STALE         /* 采样数据过期（AFE 通信异常） */
} Cells_Err_t;

/* ---------------- 单节判定级别 ---------------- */
typedef enum {
    CELL_LVL_NORMAL = 0,    /* 正常 */
    CELL_LVL_WARN,          /* 预警：接近阈值，AFE 尚未跳闸 */
    CELL_LVL_TRIP,          /* 越限：已达 AFE 跳闸阈值 */
    CELL_LVL_HOLD           /* 被均衡干扰，正在沿用上次可信值（不参与判定） */
} Cell_Level_t;

/* ---------------- 检测结果 ---------------- */
typedef struct {
    uint16_t     raw_mv[BMS_CELL_COUNT];      /* AFE 本次原始读数（可能被均衡电流压低） */
    uint16_t     mv[BMS_CELL_COUNT];          /* 本次采用值（被均衡的节 = 上次可信值） */
    Cell_Level_t level[BMS_CELL_COUNT];       /* 逐节级别 */
    bool         trusted[BMS_CELL_COUNT];     /* 本轮的读数是否可信（可参与判定/统计） */

    uint16_t     min_mv;                      /* 可信电芯中的最低值 */
    uint16_t     max_mv;
    uint16_t     avg_mv;
    uint16_t     delta_mv;                    /* max - min */
    uint32_t     sum_mv;                      /* 可信电芯电压之和（总和校验用） */
    uint8_t      idx_max;                     /* 最高电芯编号（0 起） */
    uint8_t      idx_min;

    uint16_t     ov_warn_mv;                  /* 当前使用的预警阈值（便于打印） */
    uint16_t     uv_warn_mv;

    int16_t      sum_err_mv;                  /* Σ(单节) − 组端电压 */
    bool         sum_checked;                 /* 本轮是否做了总和校验（均衡中不做） */

    Cells_Err_t  err;                         /* 采样回路状态 */
    bool         wire_ok;                     /* 采样回路是否可信 */
    bool         unbalance;                   /* 压差长时间超标 → 真的不均衡 */
    uint32_t     samples;                     /* 累计有效采样次数 */
} Cells_Info_t;

extern Cells_Info_t g_cells;

/* 采样线自检进行中（均衡模块收到此标志会暂停自己的调度，避免互相打架） */
extern bool g_cells_diag_active;

void        Cells_Init(void);   /* 模块初始化：清历史/计数/统计，阈值取 bms_config.h 的配置值 */
void        Cells_Update(const uint16_t *real_mv, uint16_t pack_mv);   /* 单体电压检测主函数（App 每 250ms 调用一次）（详见函数实现） */
bool        Cells_WireOk(void);   /* 采样回路是否可信（供保护模块决定是否闭锁充放电） */
bool        Cells_Unbalanced(void);   /* 压差是否长时间超标（仅告警，不闭锁） */
Cell_Level_t Cells_Level(uint8_t idx);   /* 取第 idx 节的判定级别（0 起） */

const char *Cells_ErrName(Cells_Err_t e);   /* 采样状态码 → 字符串（打印用） */
const char *Cells_LevelName(Cell_Level_t l);   /* 判定级别 → 字符串（打印用） */
void        Cells_Print(void);   /* 打印一页单体电压检测结果：逐节读数、级别、压差、采样回路结论 */
void        Cells_OpenWireTest(void);   /* 采样线开路自检（CELLDIAG 命令调用）：逐节施加均衡，看该节读数是否被压低 */

#endif /* __BMS_CELLS_H */
