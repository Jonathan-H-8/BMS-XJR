/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bq76920.h
 * 描述    ：BQ76920 驱动头文件：寄存器地址、寄存器位定义、对外接口声明
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: PB6=I2C1_SCL; PB7=I2C1_SDA; PA1=ALERT(EXTI 上升沿)
 * 参考手册: TI SLUSBK2I
 * 寄存器参考: SYS_STAT=0x00 ... CC=0x32/0x33; ADCGAIN1=0x50; ADCOFFSET=0x51; ADCGAIN2=0x59
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BQ76920_H
#define __BQ76920_H

#include "bms_config.h"

/* ---------------- 寄存器地址 ---------------- */
#define BQ_REG_SYS_STAT     0x00U
#define BQ_REG_CELLBAL1     0x01U
#define BQ_REG_SYS_CTRL1    0x04U
#define BQ_REG_SYS_CTRL2    0x05U
#define BQ_REG_PROTECT1     0x06U
#define BQ_REG_PROTECT2     0x07U
#define BQ_REG_PROTECT3     0x08U
#define BQ_REG_OV_TRIP      0x09U
#define BQ_REG_UV_TRIP      0x0AU
#define BQ_REG_CC_CFG       0x0BU
#define BQ_REG_VC1_HI       0x0CU      /* VC1..VC5 = 0x0C..0x15，每节 2 字节 */
#define BQ_REG_BAT_HI       0x2AU
#define BQ_REG_TS1_HI       0x2CU
#define BQ_REG_CC_HI        0x32U      /* 库仑计 16bit 有符号，读完自动复位 */
#define BQ_REG_CC_LO        0x33U
#define BQ_REG_ADCGAIN1     0x50U      /* bit3:2 = ADCGAIN[4:3] */
#define BQ_REG_ADCOFFSET    0x51U      /* 有符号 8bit，单位 mV */
#define BQ_REG_ADCGAIN2     0x59U      /* bit7:5 = ADCGAIN[2:0] */

/* ---------------- SYS_STAT 位（写 1 清除） ---------------- */
#define BQ_STAT_CC_READY    0x80U      /* D7 库仑计数据就绪 */
#define BQ_STAT_DEVICE_XREADY 0x20U    /* D5 芯片内部故障 */
#define BQ_STAT_OVRD_ALERT  0x10U      /* D4 ALERT 被外部拉高 */
#define BQ_STAT_UV          0x08U      /* D3 欠压 */
#define BQ_STAT_OV          0x04U      /* D2 过压 */
#define BQ_STAT_SCD         0x02U      /* D1 放电短路 */
#define BQ_STAT_OCD         0x01U      /* D0 放电过流 */

/* ---------------- SYS_CTRL1 / SYS_CTRL2 ---------------- */
#define BQ_CTRL1_LOAD_PRESENT 0x80U    /* D7 负载检测状态（只读） */
#define BQ_CTRL1_ADC_EN       0x10U    /* D4 使能 ADC（OV/UV 保护依赖它） */
#define BQ_CTRL1_TEMP_SEL     0x08U    /* D3 1=外部热敏电阻，0=芯片内部温度 */
#define BQ_CTRL1_SHUT_A       0x02U
#define BQ_CTRL1_SHUT_B       0x01U
#define BQ_CTRL1_NORMAL       0x18U    /* ADC_EN | TEMP_SEL */

#define BQ_CTRL2_DELAY_DIS    0x80U
#define BQ_CTRL2_CC_EN        0x40U    /* D6 库仑计常开 */
#define BQ_CTRL2_CC_ONESHOT   0x20U
#define BQ_CTRL2_DSG_ON       0x02U    /* D1 放电 FET */
#define BQ_CTRL2_CHG_ON       0x01U    /* D0 充电 FET */

#define BQ_CC_CFG_VALUE       0x19U    /* 数据手册：开机需写 0x19 */

/* ---------------- TS1 温度通道状态（BQ_ReadTs1 返回） ---------------- */
#define BQ_TS_OK        0x00U   /* 正常 */
#define BQ_TS_OPEN      0x01U   /* 开路：TS1 被内部上拉到接近 VREF（读数会假像“极低温”） */
#define BQ_TS_SHORT     0x02U   /* 短路到地：TS1 接近 0V（读数会假像“极高温”） */
#define BQ_TS_RANGE     0x03U   /* 换算出的阻值超出 BMS_NTC_R_xxx 的合理范围 */
#define BQ_TS_IO_ERR    0x04U   /* I2C 读取失败 */

/* ---------------- TS1 通道换算用宏（数值在 bms_config.h 第 15 节） ---------------- */
#define BQ_TS1_LSB_V    (BMS_TS1_LSB_UV / 1000000.0f)   /* 1 LSB 折算电压 V */

/* ---------------- 数据 ---------------- */
typedef struct {
    uint16_t cell_mv[5];        /* AFE 原始 5 个槽位电压（槽 3 恒为 0，是空槽） */
    uint16_t real_mv[BMS_CELL_COUNT]; /* 映射后的真实 4 节电芯电压 */
    uint16_t real_min_mv;
    uint16_t real_max_mv;
    uint16_t real_avg_mv;
    uint16_t pack_mv;           /* BAT 寄存器 */
    int16_t  cc_raw;            /* 本次 CC 读数（LSB） */
    float    current_a;         /* +充电 / -放电 */
    int8_t   temp_c;            /* 外部 NTC 温度 */
    int8_t   die_temp_c;        /* 芯片内部温度 */
    uint8_t  sys_stat;
    uint8_t  bal_mask;
    bool     chg_on;
    bool     dsg_on;
} BQ_Data_t;

extern BQ_Data_t g_bq;
extern bool      g_bq_i2c_ok;   /* 最近一次 I2C 事务是否成功（看门狗用） */

/* ---------------- API ---------------- */
HAL_StatusTypeDef BQ_Init(void);   /* BQ76920 上电初始化（详见函数实现） */
HAL_StatusTypeDef BQ_ReadReg(uint8_t reg, uint8_t *val);   /* 读 BQ76920 单个寄存器 */
HAL_StatusTypeDef BQ_WriteReg(uint8_t reg, uint8_t val);   /* 写 BQ76920 单个寄存器（1 字节） */
HAL_StatusTypeDef BQ_ReadBlock(uint8_t reg, uint8_t *buf, uint16_t len);   /* 从 BQ76920 连续读若干字节（一次事务保证数据同帧） */

void     BQ_ClearSysStat(uint8_t mask);   /* 清 SYS_STAT 指定位（该寄存器"写 1 清除、写 0 保持"，所以只能写要清的那些位） */
uint8_t  BQ_GetSysStat(void);   /* 读系统状态寄存器 SYS_STAT（含 CC_READY 与各类故障位） */

void     BQ_ReadGainOffset(void);   /* 从 OTP 读 14 位 ADC 的校准系数：GAIN(µV/LSB) 与 OFFSET(mV) */
uint16_t BQ_GetGainUV(void);   /* 取当前 ADC 增益 */
int8_t   BQ_GetOffsetMV(void);   /* 取当前 ADC 偏移 */

void     BQ_ReadCells(void);   /* 刷新 g_bq.cell_mv / real_mv */
HAL_StatusTypeDef BQ_ReadCellsRaw(uint16_t *adc5);   /* 读 VC1..VC5 的 14 位 ADC 码（一次块读，保证 5 节同帧） */
uint16_t BQ_GetPackMv(void);   /* 读电池组总电压：V(BAT) = 4 × GAIN × ADC + N × OFFSET */
int16_t  BQ_GetTs1Adc(void);   /* 读 TS1 温度通道的 14 位 ADC 码 */

/* TS1 完整诊断读：一次给出 ADC 码、引脚电压、NTC 阻值，并判断开路/短路/超范围。
 * 注意：TS1 是「外部 NTC」与「芯片内部温度传感器」共用的 ADC 通道，
 *       由 SYS_CTRL1.TEMP_SEL 选择，本板 TEMP_SEL=1（外部 NTC）。 */
HAL_StatusTypeDef BQ_ReadTs1(int16_t *adc, float *volt, float *r_ntc, uint8_t *status);   /* 读 TS1 并做开路/短路诊断（详见函数实现） */
int8_t   BQ_TempFromNtcR(float r_ntc);   /* NTC 阻值 → 温度（B 参数模型） */
int8_t   BQ_GetTs1Temp(void);   /* 由 TS1 外接 NTC 换算温度（详见函数实现） */
int8_t   BQ_GetDieTemp(void);   /* ★仅在 TEMP_SEL=0 时才有意义★：TEMPDIE = 25 − (V(TS1)−1.2)/0.0042 */
int8_t   BQ_ReadDieTempOnce(void);   /* 临时切 TEMP_SEL=0 读一次芯片内部温度，读完自动切回外部 NTC */
bool     BQ_IsExtTempSel(void);   /* 当前 TS1 通道是否选择的是外部 NTC（TEMP_SEL=1） */

int16_t  BQ_ReadCc(void);   /* 读并复位库仑计 */
float    BQ_GetCurrentA(void);   /* 取最近一次换算出的电流 */
float    BQ_GetCcLsbA(void);   /* 1 LSB 对应多少安培 */

void     BQ_SetFets(bool chg, bool dsg);   /* 同时设置 CHG 与 DSG 两个 MOS 驱动，并保持库仑计常开（SYS_CTRL2） */
void     BQ_SetChg(bool on);   /* 单独开/关充电管（保持放电管状态不变） */
void     BQ_SetDsg(bool on);   /* 单独开/关放电管（保持充电管状态不变） */
void     BQ_SetBalanceMask(uint8_t mask);   /* bit0=槽1 ... bit4=槽5 */
void     BQ_ConfigProtection(void);   /* 配置三级保护寄存器（详见函数实现） */
void     BQ_SetOvUvTrip(uint16_t ov_mv, uint16_t uv_mv);   /* 设置过压/欠压跳闸阈值。寄存器只放 14 位 ADC 码的「中间 8 位」， */
void     BQ_EnterShipMode(void);   /* 进入 SHIP 低功耗模式（先把两个 MOS 关掉，再按 SHUT_A/SHUT_B 时序写 SYS_C… */
bool     BQ_IsLoadPresent(void);   /* 读负载检测状态：CHG 关闭时该位表示 PACK 端是否挂着负载/充电器 */

#endif /* __BQ76920_H */
