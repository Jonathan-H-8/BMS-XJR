/******************** (C) 2026  BMS for 12V Battery  ********************************
 * 文件名  ：bms_soc.h
 * 描述    ：电量（SOC）估算接口：库仑计积分 + OCV 静置修正 + 满充满放学习容量
 * 芯片    ：TI BQ76920（BQ7692003PWR） / STM32F103C8T6
 * 库      ：STM32F10x HAL 库
 * 硬件连接: 无（算法模块）
 * 参考手册: BQ76920 库仑计章节
 * 版本更新: V1.0    2026-09-15
 * 调试方式：Keil5 + ST-Link
 **********************************************************************************/
#ifndef __BMS_SOC_H
#define __BMS_SOC_H

#include "bms_config.h"

typedef struct {
    float   soc_pct;          /* 剩余电量 0..100（未对齐时无物理意义，见 valid） */
    float   remain_ah;        /* 剩余容量 Ah */
    float   capacity_ah;      /* 当前使用的可用容量（会随学习更新） */
    float   rated_ah;         /* 额定容量（配置值） */
    float   learned_ah;       /* 最近一次学习结果 */
    uint16_t charge_count;    /* 满充次数 */
    bool    full_flag;        /* 当前处于“已满”状态 */
    bool    valid;            /* SOC 是否可信（未对齐前恒为 false，不要采信 soc_pct） */
} Soc_Info_t;

extern Soc_Info_t g_soc;

/* SOC 可信度分级（★ 上电真值问题的显式表达，避免用 50% 冒充真实电量） */
typedef enum {
    SOC_STATE_UNKNOWN = 0,   /* 电量不可知：EEPROM 无记录且尚未由 OCV 对齐。
                                调用方必须把 soc_pct 当作"无意义"，禁止显示/上报具体数字。
                                典型场景：全新板首次上电、换电池后、EEPROM 数据损坏。 */
    SOC_STATE_RESTORED,      /* 由 EEPROM 掉电记录恢复。不受极化影响，最可信 */
    SOC_STATE_OCV_ALIGNED    /* 由 OCV 对齐得到（冷启动静置稳定后） */
} Soc_State_t;

void  Soc_Init(float capacity_ah);   /* SOC 模块初始化。真实电量未知 → 置 UNKNOWN，随后由
                                         EEPROM 记录 / 上电 OCV 对齐修正；未对齐前 soc_pct 无意义 */
void  Soc_OnCcSample(int16_t cc_raw);   /* 每 250ms 调用一次 */
void  Soc_OnRest(uint16_t avg_cell_mv);   /* 静置时用 OCV 修正 */
void  Soc_NotifyCharging(bool charging);   /* 告知充放电方向（用于学习统计） */
void  Soc_MarkFull(void);   /* 判定满充：SOC→100% 并学习容量 */
void  Soc_MarkEmpty(void);   /* 判定放空：SOC→0% 并学习容量 */
void  Soc_SetCapacity(float capacity_ah);   /* 手动设置容量（或从 EEPROM 载入） */
float Soc_GetPercent(void);   /* 取当前电量百分比 */
float Soc_GetRemainAh(void);   /* 取当前剩余容量 */

/* ---- 上电 SOC 对齐（解决"上电固定按 50% 起步、显示假电量"的问题）---- */
void     Soc_SetInitialSoc(float soc_pct);   /* 用 EEPROM 里存的电量设定上电初值（0~100） */
bool     Soc_OnBootOcv(uint16_t avg_cell_mv);/* 上电快速 OCV 对齐：稳定静置后直接采信 OCV，返回 true=已对齐 */
bool     Soc_IsAligned(void);   /* SOC 是否已对齐到真实值（false = 电量未知，别采信 soc_pct） */
Soc_State_t Soc_GetState(void); /* 取 SOC 可信度分级：UNKNOWN / RESTORED / OCV_ALIGNED */
bool     Soc_IsColdBoot(void);  /* 本次上电是否为"待测电芯确认的冷启动"（由 App 层在初始化时告知） */
uint16_t Soc_GetPermille(void);   /* 取 SOC 千分比（0~1000），供掉电保存使用 */

/* 容量学习结果持久化钩子：由用户用 AT24C02 实现（可留空） */
__weak void Soc_SaveCapacityCb(float capacity_ah);

#endif /* __BMS_SOC_H */
