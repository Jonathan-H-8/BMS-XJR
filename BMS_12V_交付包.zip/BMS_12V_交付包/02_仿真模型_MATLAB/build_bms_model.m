function build_bms_model(cfg, P, modelName)
%BUILD_BMS_MODEL  用脚本搭建 C33 2P4S BMS 仿真模型（BMS_C33_2P4S.slx）
%
%   模型结构（全部由本脚本生成，可重复执行、可进版本管理）：
%
%     [From Workspace: SCEN]  →  Demux
%        SCEN 列：t | scen | chgLim | dsgLim | clr | inj1..4 | injNTC | t_amb | rst | soc0(1..4)
%        Demux 输出：1 scen / 2 cmd(3) / 3 inj_cell(4) / 4 inj_ntc / 5 t_amb / 6 rst / 7 soc0(4)
%            │
%            ├─ scen ─────────────►┌──────────────┐  i_cmd
%            │                     │ 工况+充电机   │────────┐
%            │        v_pack ─────►│ (CC-CV 等)   │        │
%            │                     └──────────────┘        ▼
%            │                                     ┌──────────────┐
%            │                                     │ Plant        │
%            │                                     │ 4×2P 等效 ECM│
%            │                                     └───┬──────┬───┘
%            │                        i_pack/v_true/t   │      │ v_pack
%            │                     ┌───────────────────┘      └──►[Mem]→ 工况块
%            │                     ▼
%            │              ┌──────────────┐
%            │              │ AFE BQ76920  │  寄存器级仿真
%            │              └──────┬───────┘
%            │                     │ 寄存器读数
%            │                     ▼
%            │              ┌──────────────┐
%            └─────────────►│ BMS 固件逻辑 │
%                           │ (bms_*.c移植)│
%                           └──────┬───────┘
%                                  │ chg/dsg/bal/cc_read/clr
%                             [Memory]  ← ★打断代数环
%
%   ★ 两处 Memory（都是物理上成立的"一拍延迟"）：
%     ① BMS 输出的 MOS 状态 → Memory → Plant/AFE：
%        否则 电流→AFE→BMS→MOS→电流 构成代数环，Simulink 会报 algebraic loop；
%        真实系统里 MOS 状态本来就是下一拍才作用于电流的。
%     ② Plant 的组端电压 → Memory → 工况块（CC-CV 需要上一拍的电压）。
%
%   用法：
%       cfg = load_bms_config();  P = c33_2p4s_params(cfg);
%       build_bms_model(cfg, P);

if nargin < 3 || isempty(modelName)
    modelName = 'BMS_C33_2P4S';
end
here = fileparts(mfilename('fullpath'));

%% ---------- 1) 解析块路径 ----------
% 全部用标准库块的规范路径（最稳、最快）。
% 注意：不要用 find_system 遍历整个 Simulink 库去找块——那要几分钟。
blkMFcn   = 'simulink/User-Defined Functions/MATLAB Function';
blkFromWS = 'simulink/Sources/From Workspace';
blkDemux  = 'simulink/Signal Routing/Demux';
blkMux    = 'simulink/Signal Routing/Mux';
blkToWS   = 'simulink/Sinks/To Workspace';
blkScope  = 'simulink/Sinks/Scope';
blkClock  = 'simulink/Sources/Clock';
blkMemory = 'simulink/Discrete/Memory';
blkTerm   = 'simulink/Sinks/Terminator';
load_system('simulink');      % 标准库，加载很快；不加载的话 get_param 检查路径会失败
fprintf('[build] 块路径检查...\n');
for c = {blkMFcn, blkFromWS, blkDemux, blkMux, blkToWS, blkScope, blkClock, blkMemory, blkTerm}
    try
        get_param(c{1}, 'BlockType');
    catch
        error('build_bms_model:块路径不可用: %s', c{1});
    end
end
fprintf('[build] 8 个块路径全部可用\n');

%% ---------- 2) 新建模型 ----------
slx = fullfile(here, [modelName '.slx']);
if bdIsLoaded(modelName)
    close_system(modelName, 0);
end
if isfile(slx)
    delete(slx);
end
new_system(modelName);
load_system(modelName);
mdl = modelName;

set_param(mdl, 'SolverType', 'Fixed-step', 'Solver', 'FixedStepDiscrete', ...
               'FixedStep', '0.01', 'StopTime', '60');

%% ---------- 3) 放块 ----------
add_block(blkFromWS, [mdl '/SCEN'], 'VariableName', 'SCEN', ...
          'OutputAfterFinalValue', 'HoldingFinalValue', 'Position', [20 260 90 400]);
add_block(blkDemux, [mdl '/Demux_in'], 'Outputs', '[1 3 4 1 1 1 4]', 'Position', [130 260 140 400]);

add_block(blkMFcn, [mdl '/Profile'],          'Position', [190 60 300 180]);
add_block(blkMFcn, [mdl '/Plant_4Group_ECM'], 'Position', [370 200 510 380]);
add_block(blkMFcn, [mdl '/AFE_BQ76920'],      'Position', [580 200 720 380]);
add_block(blkMFcn, [mdl '/BMS_Firmware'],     'Position', [790 180 950 400]);

% MOS 状态回路的 Memory（打断代数环）
add_block(blkMux,    [mdl '/Mux_ctl'],     'Inputs', '3', 'Position', [1000 420 1005 500]);
add_block(blkMemory, [mdl '/Mem_ctl'],     'Position', [1040 440 1080 480]);
add_block(blkDemux,  [mdl '/Demux_ctl'],   'Outputs', '3', 'Position', [1120 420 1125 500]);
add_block(blkMux,    [mdl '/Mux_afein'],   'Inputs', '3', 'Position', [1000 530 1005 610]);
add_block(blkMemory, [mdl '/Mem_afein'],   'Position', [1040 550 1080 590]);
add_block(blkDemux,  [mdl '/Demux_afein'], 'Outputs', '3', 'Position', [1120 530 1125 610]);
% 组端电压 → 工况块 的 Memory
add_block(blkMemory, [mdl '/Mem_vpack'],   'Position', [370 120 410 160]);

% ★ 终结器：Simulink 不允许「输出端口悬空」，不参与运算的输出必须接 Terminator。
%   这里有两个这样的端口：
%     · Profile/2  scen_name  —— 只是工况编号的日志编码，没人用
%     · Plant/7    age_fac    —— 老化系数，只给纯 MATLAB 长跑分析用
%   不接的话整机编译会报「输出端口未连接」。
add_block(blkTerm, [mdl '/Term_plan'], 'Position', [200 200 220 220]);
add_block(blkTerm, [mdl '/Term_age'],  'Position', [540 250 560 270]);

% 时间
add_block(blkClock, [mdl '/t'], 'Position', [20 40 60 70]);

% 日志
add_block(blkMux, [mdl '/MuxPlant'], 'Inputs', '[1 1 1 4 1 4 1]', 'Position', [1220 60 1225 220]);
add_block(blkMux, [mdl '/MuxAfe'],   'Inputs', '[4 1 1 1 1 1 1]', 'Position', [1220 260 1225 400]);
add_block(blkMux, [mdl '/MuxBms'],   'Inputs', '9',               'Position', [1220 440 1225 600]);
add_block(blkToWS, [mdl '/LOG_PLANT'], 'VariableName', 'LOG_PLANT', ...
          'SaveFormat', 'Structure With Time', 'Position', [1290 60 1360 120]);
add_block(blkToWS, [mdl '/LOG_AFE'],   'VariableName', 'LOG_AFE', ...
          'SaveFormat', 'Structure With Time', 'Position', [1290 260 1360 320]);
add_block(blkToWS, [mdl '/LOG_BMS'],   'VariableName', 'LOG_BMS', ...
          'SaveFormat', 'Structure With Time', 'Position', [1290 440 1360 500]);
add_block(blkToWS, [mdl '/LOG_DBG'],   'VariableName', 'LOG_DBG', ...
          'SaveFormat', 'Structure With Time', 'Position', [1290 540 1360 600]);

% 示波器
add_block(blkScope, [mdl '/Scope_V_I'],   'NumInputPorts', '4', 'Position', [1440 60 1480 140]);
add_block(blkScope, [mdl '/Scope_Cells'], 'NumInputPorts', '4', 'Position', [1440 200 1480 280]);
add_block(blkScope, [mdl '/Scope_SOC'],   'NumInputPorts', '3', 'Position', [1440 340 1480 420]);
add_block(blkScope, [mdl '/Scope_FET'],   'NumInputPorts', '4', 'Position', [1440 480 1480 560]);

%% ---------- 4) 注入 MATLAB Function 代码 ----------
% 端口规格：端口名 → {尺寸, 类型}。尺寸用的是 Stateflow 的写法（逗号分隔，标量写 '1'）
spProfile = struct('scen','{1,''double''}','v_pack','{1,''double''}','t','{1,''double''}', ...
                   'i_cmd','{1,''double''}','scen_name','{1,''double''}');
% ★ 注意 age_fac：长跑改造时 Plant 多加了第 7 个输出（老化系数），
%   这里是它的端口规格。Simulink 不允许输出端口悬空，必须接 Terminator
%   （见下面 ---------- 5) 连线 ---------- 里的 Term_age）。
spPlant = struct('i_cmd','{1,''double''}','chg_en','{1,''double''}','dsg_en','{1,''double''}', ...
                 'bal_mask','{1,''double''}','t_amb','{1,''double''}','t','{1,''double''}', ...
                 'rst','{1,''double''}','soc0','{4,''double''}', ...
                 'i_pack','{1,''double''}','v_true','{4,''double''}', ...
                 'v_pack_true','{1,''double''}','t_cell','{1,''double''}', ...
                 'soc_true','{4,''double''}','p_loss','{1,''double''}', ...
                 'age_fac','{2,''double''}');
% ★ AFE 块也是「单一向量输出」（1×10），理由与 BMS 块相同：
%   输出端口多、类型混着 uint8 与 double 时，Stateflow 的尺寸推断会失败，
%   报「Simulink 无法确定模块的输出大小和/或类型」。
%   打包约定见 bms_afe_model.m 末尾。
spAfe = struct('i_pack','{1,''double''}','v_true','{4,''double''}','t_cell','{1,''double''}', ...
               'bal_mask','{1,''double''}','cc_read','{1,''double''}','clr_mask','{1,''double''}', ...
               'inj_cell','{4,''double''}','inj_ntc','{1,''double''}','t','{1,''double''}', ...
               'rst','{1,''double''}','y','{10,''double''}');
% ★ sys_stat 用 double 而不是 uint8：AFE 块把输出打包成向量后，
%   Demux 出来的必然是 double。固件块内部对 SYS_STAT 的位操作本来就写了
%   显式转换（bms_ctrl_model.m 里是 uint8(sys_stat)），所以收 double 没问题。
%   如果这里仍写 uint8，Simulink 会因为类型不匹配报错。
spBms = struct('cc_raw','{1,''double''}','sys_stat','{1,''double''}','v_meas','{4,''double''}', ...
               'v_pack_meas','{1,''double''}','ts1_adc','{1,''double''}', ...
               'cmd','{3,''double''}','t','{1,''double''}','rst','{1,''double''}', ...
               'y','{26,''double''}');
for bb = {'spProfile','spPlant','spAfe','spBms'}
    f = bb{1}; v = eval(f);
    fns = fieldnames(v);
    for q = 1:numel(fns)
        val = v.(fns{q});
        if ischar(val), v.(fns{q}) = eval(val); end
    end
    eval([f ' = v;']);
end
fillMFcn(mdl, 'Profile',          fullfile(here, 'bms_profile_model.m'), spProfile);
fillMFcn(mdl, 'Plant_4Group_ECM', fullfile(here, 'bms_plant_model.m'), spPlant);
fillMFcn(mdl, 'AFE_BQ76920',      fullfile(here, 'bms_afe_model.m'),    spAfe);
fillMFcn(mdl, 'BMS_Firmware',     fullfile(here, 'bms_ctrl_model.m'),   spBms);

%% ---------- 5) 连线 ----------
L = @(a,b) add_line(mdl, a, b, 'autorouting', 'on');

% 工况注入
L('SCEN/1', 'Demux_in/1');
L('Demux_in/1', 'Profile/1');                 % scen
L('Demux_in/2', 'BMS_Firmware/6');            % cmd(3)
L('Demux_in/3', 'AFE_BQ76920/7');             % inj_cell(4)
L('Demux_in/4', 'AFE_BQ76920/8');             % inj_ntc
L('Demux_in/5', 'Plant_4Group_ECM/5');        % t_amb
L('Demux_in/6', 'Plant_4Group_ECM/7');        % rst
L('Demux_in/7', 'Plant_4Group_ECM/8');        % soc0
L('Demux_in/6', 'AFE_BQ76920/10');            % rst
L('Demux_in/6', 'BMS_Firmware/8');            % rst

% 时间
L('t/1', 'Profile/3');
L('t/1', 'Plant_4Group_ECM/6');
L('t/1', 'AFE_BQ76920/9');
L('t/1', 'BMS_Firmware/7');

% 工况块 → Plant
L('Profile/1', 'Plant_4Group_ECM/1');         % i_cmd
L('Plant_4Group_ECM/3', 'Mem_vpack/1');       % v_pack_true
L('Mem_vpack/1', 'Profile/2');                % 上一拍电压给 CC-CV

% 不参与运算的输出 → 终结器（否则整机编译报"输出端口未连接"）
L('Profile/2', 'Term_plan/1');                % scen_name
L('Plant_4Group_ECM/7', 'Term_age/1');        % age_fac

% Plant → AFE
L('Plant_4Group_ECM/1', 'AFE_BQ76920/1');     % i_pack
L('Plant_4Group_ECM/2', 'AFE_BQ76920/2');     % v_true(4)
L('Plant_4Group_ECM/4', 'AFE_BQ76920/3');     % t_cell

% AFE 输出是 1×10 打包向量（原因见 bms_afe_model.m 末尾）→ 用 Demux 拆开
%   下标约定：1 cc_raw / 2 cc_ready / 3 sys_stat / 4..7 v_meas(1..4)
%             8 v_pack_meas / 9 ts1_adc / 10 bal_drop
add_block(blkDemux, [mdl '/Demux_afe'],  'Outputs', '10', 'Position', [740 190 745 390]);
add_block(blkMux,   [mdl '/Mux_vmeas'],  'Inputs',  '4',  'Position', [800 250 805 330]);
L('AFE_BQ76920/1', 'Demux_afe/1');
% v_meas 是 4 个相邻标量 → 用 Mux 合成 4 维向量再给固件（固件要的是 1×4）
L('Demux_afe/4', 'Mux_vmeas/1');
L('Demux_afe/5', 'Mux_vmeas/2');
L('Demux_afe/6', 'Mux_vmeas/3');
L('Demux_afe/7', 'Mux_vmeas/4');

% AFE → BMS（固件只看得到这几个"寄存器读数"）
L('Demux_afe/1', 'BMS_Firmware/1');           % cc_raw
L('Demux_afe/3', 'BMS_Firmware/2');           % sys_stat
L('Mux_vmeas/1', 'BMS_Firmware/3');           % v_meas(4)
L('Demux_afe/8', 'BMS_Firmware/4');           % v_pack_meas
L('Demux_afe/9', 'BMS_Firmware/5');           % ts1_adc

% BMS 输出是 1×26 的向量（原因见 bms_ctrl_model.m 里的说明）→ 用 Demux 拆开
add_block(blkDemux, [mdl '/Demux_bms'], 'Outputs', '26', 'Position', [980 150 985 520]);
add_block(blkMux,   [mdl '/Mux_dbg'],   'Inputs', '15', 'Position', [1020 560 1025 700]);
L('BMS_Firmware/1', 'Demux_bms/1');
for kk = 1:15
    L(sprintf('Demux_bms/%d', 11+kk), sprintf('Mux_dbg/%d', kk));
end

% ① 控制量 → Memory → Plant（chg_en / dsg_en / bal_mask）
L('Demux_bms/1', 'Mux_ctl/1');
L('Demux_bms/2', 'Mux_ctl/2');
L('Demux_bms/3', 'Mux_ctl/3');
L('Mux_ctl/1', 'Mem_ctl/1');
L('Mem_ctl/1', 'Demux_ctl/1');
L('Demux_ctl/1', 'Plant_4Group_ECM/2');
L('Demux_ctl/2', 'Plant_4Group_ECM/3');
L('Demux_ctl/3', 'Plant_4Group_ECM/4');

% ② 给 AFE 的控制量 → Memory（bal_mask / cc_read / clr_mask）
L('Demux_bms/3', 'Mux_afein/1');
L('Demux_bms/4', 'Mux_afein/2');
L('Demux_bms/5', 'Mux_afein/3');
L('Mux_afein/1', 'Mem_afein/1');
L('Mem_afein/1', 'Demux_afein/1');
L('Demux_afein/1', 'AFE_BQ76920/4');
L('Demux_afein/2', 'AFE_BQ76920/5');
L('Demux_afein/3', 'AFE_BQ76920/6');

% 日志：LOG_PLANT = [i_cmd, i_pack, v_pack_true, v_true(1..4), t_cell, soc_true(1..4), p_loss]
L('Profile/1',          'MuxPlant/1');
L('Plant_4Group_ECM/1', 'MuxPlant/2');
L('Plant_4Group_ECM/3', 'MuxPlant/3');
L('Plant_4Group_ECM/2', 'MuxPlant/4');
L('Plant_4Group_ECM/4', 'MuxPlant/5');
L('Plant_4Group_ECM/5', 'MuxPlant/6');
L('Plant_4Group_ECM/6', 'MuxPlant/7');
L('MuxPlant/1', 'LOG_PLANT/1');

% LOG_AFE = [v_meas(1..4), v_pack_meas, cc_raw, cc_ready, sys_stat, ts1_adc, bal_drop]
% 注意：这些量现在都要从 Demux_afe / Mux_vmeas 取，AFE 块本身只有一个输出端口
L('Mux_vmeas/1',  'MuxAfe/1');        % v_meas(1..4)
L('Demux_afe/8',  'MuxAfe/2');        % v_pack_meas
L('Demux_afe/1',  'MuxAfe/3');        % cc_raw
L('Demux_afe/2',  'MuxAfe/4');        % cc_ready
L('Demux_afe/3',  'MuxAfe/5');        % sys_stat
L('Demux_afe/9',  'MuxAfe/6');        % ts1_adc
L('Demux_afe/10', 'MuxAfe/7');        % bal_drop
L('MuxAfe/1', 'LOG_AFE/1');

% LOG_BMS = [chg_en, dsg_en, bal_mask, soc, remain, cap, fault, led, temp]
L('Demux_bms/1',  'MuxBms/1');
L('Demux_bms/2',  'MuxBms/2');
L('Demux_bms/3',  'MuxBms/3');
L('Demux_bms/6',  'MuxBms/4');
L('Demux_bms/7',  'MuxBms/5');
L('Demux_bms/8',  'MuxBms/6');
L('Demux_bms/9',  'MuxBms/7');
L('Demux_bms/10', 'MuxBms/8');
L('Demux_bms/11', 'MuxBms/9');
L('MuxBms/1', 'LOG_BMS/1');
L('Mux_dbg/1', 'LOG_DBG/1');           % dbg(15)

% 示波器
L('Plant_4Group_ECM/1', 'Scope_V_I/1');       % i_pack
L('Plant_4Group_ECM/3', 'Scope_V_I/2');       % v_pack_true
L('Mux_vmeas/1',        'Scope_V_I/3');       % v_meas
L('Demux_afe/8',        'Scope_V_I/4');       % v_pack_meas
L('Plant_4Group_ECM/2', 'Scope_Cells/1');     % v_true
L('Mux_vmeas/1',        'Scope_Cells/2');     % v_meas
L('Demux_bms/3',        'Scope_Cells/3');     % bal_mask
L('Demux_afe/10',       'Scope_Cells/4');     % bal_drop
L('Demux_bms/6',        'Scope_SOC/1');       % soc
L('Plant_4Group_ECM/5', 'Scope_SOC/2');       % soc_true
L('Demux_bms/7',        'Scope_SOC/3');       % remain
L('Demux_bms/1',        'Scope_FET/1');       % chg_en
L('Demux_bms/2',        'Scope_FET/2');       % dsg_en
L('Demux_bms/9',        'Scope_FET/3');       % fault
L('Demux_bms/10',       'Scope_FET/4');       % led

%% ---------- 6) 保存 ----------
save_system(mdl, slx);
fprintf('[build] 模型已保存: %s\n', slx);
fprintf('[build] 端口约定：\n');
fprintf('         Profile: scen, v_pack, t                 -> i_cmd\n');
fprintf('         Plant  : i_cmd, chg_en, dsg_en, bal_mask, t_amb, t, rst, soc0\n');
fprintf('         AFE    : i_pack, v_true, t_cell, bal_mask, cc_read, clr_mask, inj_cell, inj_ntc, t, rst\n');
fprintf('         BMS    : cc_raw, sys_stat, v_meas, v_pack_meas, ts1_adc, cmd, t, rst\n');
end

%% ================= 辅助函数 =================
function fillMFcn(mdl, blkName, mfile, spec)
    % 把 .m 正文写进 MATLAB Function 块，并**显式指定每个端口的数据尺寸与类型**。
    % 为什么必须显式指定：Simulink 的代码生成器对较复杂的块（尤其带 persist 状态、
    % 多输出的块）有时推不出输出尺寸，会报
    %   「Simulink 无法确定模块的输出大小和/或类型」
    % 报错信息本身也提示了解决办法：显式指定尺寸和类型。这里就是干这个的。
    txt = fileread(mfile);
    rt  = sfroot;
    ch  = rt.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/' blkName]);
    if isempty(ch)
        error('build_bms_model:找不到 MATLAB Function 块: %s/%s', mdl, blkName);
    end
    ch(1).Script = txt;

    d = ch(1).find('-isa', 'Stateflow.Data');
    nset = 0;
    for k = 1:numel(d)
        nm = d(k).Name;
        if isfield(spec, nm)
            try
                d(k).Props.Array.Size = num2str(spec.(nm){1});   % 必须是字符向量，不能直接给数字
                d(k).Props.Array.IsDynamic = false;
                d(k).DataType = spec.(nm){2};
                nset = nset + 1;
            catch e
                fprintf('[build]   ! %s.%s 设置失败: %s\n', blkName, nm, e.message);
            end
        end
    end
    fprintf('[build] 已注入代码: %-16s ← %s  (显式指定了 %d 个端口尺寸)\n', blkName, mfile, nset);
end
