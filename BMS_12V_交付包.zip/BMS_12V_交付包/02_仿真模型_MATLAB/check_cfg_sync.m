function nbad = check_cfg_sync(verbose)
%CHECK_CFG_SYNC  核对 MATLAB Function 块里的常量与固件 bms_config.h 是否一致
%
%   MATLAB Function 块不能 include C 头文件，所以 bms_ctrl_model.m / bms_afe_model.m
%   里的阈值是 bms_config.h 的"手抄版"。手抄就会漂移——改了 C 忘了改 MATLAB，
%   仿真就变成在测另一套参数，白测。
%
%   本函数把两边逐个对照，不一致就列出来。**改完固件阈值请务必跑一次**。
%
%   用法：
%       check_cfg_sync        % 只报不一致项
%       check_cfg_sync(true)  % 把所有对照项都打出来

if nargin < 1, verbose = false; end
here = fileparts(mfilename('fullpath'));
cfg  = load_bms_config(fullfile(here,'..','bms_firmware','Core','Inc','bms_config.h'));

% MATLAB 常量名 → C 宏名
MAP = {
    'CAP_AH',          'BMS_CAPACITY_AH'
    'COULOMB_EFF',     'BMS_COULOMB_EFF'
    'CELL_N',          'BMS_CELL_COUNT'
    'OV_MV',           'BMS_CELL_OV_MV'
    'UV_MV',           'BMS_CELL_UV_MV'
    'OV_WARN_MV',      'BMS_CELL_OV_WARN_MV'
    'UV_WARN_MV',      'BMS_CELL_UV_WARN_MV'
    'OV_DEB',          'BMS_CELL_OV_DEBOUNCE'
    'UV_DEB',          'BMS_CELL_UV_DEBOUNCE'
    'HYST_MV',         'BMS_CELL_HYST_MV'
    'PLAUS_MIN',       'BMS_CELL_PLAUSIBLE_MIN_MV'
    'PLAUS_MAX',       'BMS_CELL_PLAUSIBLE_MAX_MV'
    'SUM_TOL_MV',      'BMS_CELL_SUM_TOL_MV'
    'SUM_BAD_CNT',     'BMS_CELL_SUM_BAD_CNT'
    'DELTA_WARN_MV',   'BMS_CELL_DELTA_WARN_MV'
    'DELTA_HOLD_MS',   'BMS_CELL_DELTA_HOLD_MS'
    'BAL_SETTLE_MS',   'BMS_CELL_BAL_SETTLE_MS'
    'HOLD_MAX_MS',     'BMS_CELL_HOLD_MAX_MS'
    'CHG_MIN',         'BMS_TEMP_CHG_MIN'
    'CHG_MAX',         'BMS_TEMP_CHG_MAX'
    'DSG_MAX',         'BMS_TEMP_DSG_MAX'
    'CRIT_LOW',        'BMS_TEMP_DSG_MIN'
    'VALID_MIN',       'BMS_TEMP_VALID_MIN'
    'VALID_MAX',       'BMS_TEMP_VALID_MAX'
    'NTC_R0',          'BMS_NTC_R0_OHM'
    'NTC_B',           'BMS_NTC_B'
    'PULLUP',          'BMS_NTC_PULLUP_OHM'
    'VREF',            'BMS_NTC_VREF'
    'TS_LSB_UV',       'BMS_TS1_LSB_UV'
    'TEMP_FILT_N',     'BMS_TEMP_FILTER_N'
    'TEMP_RATE_MAX',   'BMS_TEMP_RATE_MAX'
    'TEMP_REJ_MAX',    'BMS_TEMP_REJECT_MAX'
    'TEMP_BOOT_GRACE', 'BMS_TEMP_BOOT_GRACE_MS'
    'BAL_START_MV',    'BMS_BAL_START_MV'
    'BAL_DELTA_MV',    'BMS_BAL_DELTA_MV'
    'BAL_MIN_MV',      'BMS_BAL_MIN_MV'
    'BAL_TMIN',        'BMS_BAL_TEMP_MIN'
    'BAL_TMAX',        'BMS_BAL_TEMP_MAX'
    'BAL_IMAX',        'BMS_BAL_MAX_CURRENT_A'
    'BAL_OV_GUARD',    'BMS_BAL_OV_GUARD_MV'
    'BAL_ON_MS',       'BMS_BAL_ON_MS'
    'BAL_PAUSE_MS',    'BMS_BAL_PAUSE_MS'
    'OC_SW_DELAY_MS',  'BMS_OC_SW_DELAY_MS'
    'OC_RETRY_MS',     'BMS_OC_RETRY_MS'
    'OC_MAX_RETRY',    'BMS_OC_MAX_RETRY'
    'OC_RECOVER',      'BMS_OC_RECOVER_RATIO'
    'DEF_CHG_LIM',     'BMS_CHARGE_MAX_A'
    'DEF_DSG_LIM',     'BMS_DISCHARGE_MAX_A'
    'FULL_DETECT_MV',  'BMS_FULL_DETECT_MV'
    'FULL_DETECT_A',   'BMS_FULL_DETECT_A'
    'FULL_HOLD_MS',    'BMS_FULL_HOLD_MS'
    'EMPTY_DETECT_MV', 'BMS_EMPTY_DETECT_MV'
    'EMPTY_HOLD_MS',   'BMS_EMPTY_HOLD_MS'
    'OCV_REST_A',      'BMS_OCV_REST_A'
    'OCV_REST_MS',     'BMS_OCV_REST_MS'
    'OCV_W',           'BMS_OCV_WEIGHT'
    };

files = {'bms_ctrl_model.m','bms_afe_model.m','bms_plant_model.m'};
vals = struct();
for f = 1:numel(files)
    txt = fileread(fullfile(here, files{f}));
    tk  = regexp(txt, '([A-Z][A-Z0-9_]{2,})\s*=\s*(-?\d+\.?\d*(?:[eE][-+]?\d+)?)', 'tokens');
    for k = 1:numel(tk)
        nm = tk{k}{1};
        if ~isfield(vals, nm)                 % 取第一次出现（常量段）
            vals.(nm) = str2double(tk{k}{2});
        end
    end
end

fprintf('\n===== 固件常量 ↔ Simulink 块常量 对照 =====\n');
nbad = 0;
for k = 1:size(MAP,1)
    mn = MAP{k,1}; cn = MAP{k,2};
    if ~isfield(vals, mn)
        fprintf('  [--] %-16s 块内未定义（跳过）\n', mn);
        continue;
    end
    if ~isfield(cfg, cn)
        fprintf('  [--] %-16s 头文件里没有 %s\n', mn, cn);
        continue;
    end
    a = vals.(mn); b = cfg.(cn);
    if abs(a-b) <= max(1e-9, 1e-6*max(abs(a),abs(b)))
        if verbose, fprintf('  [OK] %-16s = %-12g (%s)\n', mn, a, cn); end
    else
        nbad = nbad + 1;
        fprintf('  [!!] %-16s 块内 %g  ≠  头文件 %s = %g\n', mn, a, cn, b);
    end
end

% 派生量单独校验
fprintf('\n--- 派生量 ---\n');
cc = cfg.BMS_CC_LSB_UV/1000/cfg.BMS_RSENSE_MOHM;
if isfield(vals,'CC_LSB_A')
    if abs(vals.CC_LSB_A - cc) > 1e-9*cc
        nbad = nbad + 1;
        fprintf('  [!!] CC_LSB_A 块内 %g ≠ 由头文件算得 %g (8.44µV/1mΩ)\n', vals.CC_LSB_A, cc);
    else
        fprintf('  [OK] CC_LSB_A = %g A/LSB\n', cc);
    end
end
if isfield(vals,'CAP_GROUP')
    if abs(vals.CAP_GROUP - cfg.BMS_CAPACITY_AH) > 1e-6
        nbad = nbad + 1;
        fprintf('  [!!] Plant 里的 CAP_GROUP %g ≠ BMS_CAPACITY_AH %g\n', ...
                vals.CAP_GROUP, cfg.BMS_CAPACITY_AH);
    else
        fprintf('  [OK] CAP_GROUP = %g Ah\n', vals.CAP_GROUP);
    end
end

if nbad == 0
    fprintf('\n结果：一致（0 处差异）\n');
else
    fprintf('\n结果：**%d 处不一致**，请同步 bms_ctrl_model.m 后重建模型\n', nbad);
    fprintf('提示：改固件阈值 → 改 bms_config.h → 跑本函数 → 按提示改 MATLAB 常量 → build_bms_model\n');
end
end
