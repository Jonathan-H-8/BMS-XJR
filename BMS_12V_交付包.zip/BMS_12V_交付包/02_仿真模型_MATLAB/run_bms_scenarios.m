function results = run_bms_scenarios(whichScen, makePlot)
%RUN_BMS_SCENARIOS  跑 BMS 回归场景，逐条给通过/不通过结论
%
%   每个场景都是对固件逻辑的一次"实机等效"考验：
%   用 SCEN 矩阵描述工况（电流曲线、限值、故障注入、环境温度、初始 SOC），
%   仿真后按预期判据给出 PASS/FAIL。
%
%   用法：
%       run_bms_scenarios                 % 全部 12 个场景
%       run_bms_scenarios([2 4 5])        % 只跑指定编号
%       run_bms_scenarios('all', false)   % 不画图（只出结论，最快）
%
%   结果结构体数组 results(k).name / .pass / .metrics / .notes

if nargin < 1 || isempty(whichScen), whichScen = 'all'; end
if nargin < 2 || isempty(makePlot),  makePlot = true;  end

here = fileparts(mfilename('fullpath'));
cd(here); addpath(here);

cfg = load_bms_config(fullfile(here,'..','bms_firmware','Core','Inc','bms_config.h'));
P   = c33_2p4s_params(cfg);

mdl = 'BMS_C33_2P4S';
if ~bdIsLoaded(mdl) || ~isfile(fullfile(here,[mdl '.slx']))
    build_bms_model(cfg, P);
end

FIG = fullfile(here, 'figs');
if makePlot && ~isfolder(FIG), mkdir(FIG); end

% ---------------- 场景定义 ----------------
% 字段：name, scen, T, t_amb, soc0, chgLim, dsgLim, inj_cell, inj_ntc, note
S = {};
S{end+1} = mk('S01_静置基线',      1,  300,  25, [60 60 57 60], 30, 50, [0 0 0 0], 0, ...
              '静置：验证采样与 SOC 不漂移、无故障');
S{end+1} = mk('S02_放电到空(1C)',  2,  1800, 25, [60 60 57 60], 30, 50, [0 0 0 0], 0, ...
              '30A 放电 0.5h：SOC 应降约 50%，并观察低压保护是否触发');
S{end+1} = mk('S03_CC-CV充电',     3,  3600, 25, [10 10 7 10], 30, 50, [0 0 0 0], 0, ...
              '从 10% 充电：验证过压保护与满充判定/容量学习');
S{end+1} = mk('S04_放电过流60A',   4,  60,   25, [60 60 57 60], 50, 50, [0 0 0 0], 0, ...
              '60A 超 50A 限值：软件二级 + AFE OCD 应切断放电');
S{end+1} = mk('S05_充电过流35A',   5,  60,   25, [60 60 57 60], 30, 50, [0 0 0 0], 0, ...
              '35A 超 30A 限值：充电侧只有软件保护，必须切断 CHG');
S{end+1} = mk('S06_循环工况',      6,  1440, 25, [60 60 57 60], 30, 50, [0 0 0 0], 0, ...
              '放/静/充/静循环 2 轮：SOC 来回摆，验证无故障与均衡动作');
S{end+1} = mk('S07_短路脉冲150A',  7,  90,   25, [60 60 57 60], 30, 50, [0 0 0 0], 0, ...
              '每 30s 一个 150A/50ms 脉冲：AFE 短路保护应触发');
S{end+1} = mk('S08_低温禁充(-10)', 8,  600, -10, [60 60 57 60], 30, 50, [0 0 0 0], 0, ...
              '环境 -10℃ 充电：应判低温禁充（CHG 关断）');
S{end+1} = mk('S09_高温禁放(65)',  9,  900,  65, [60 60 57 60], 30, 50, [0 0 0 0], 0, ...
              '环境 65℃ 放电：应判过温禁充放');
S{end+1} = mk('S10_NTC开路',       1,  120,  25, [60 60 57 60], 30, 50, [0 0 0 0], 6, ...
              '注入 NTC 开路：应判传感器故障并闭锁（不能把 3.3V 当成 -40℃ 用）');
S{end+1} = mk('S11_采样线开路',    1,  120,  25, [60 60 57 60], 30, 50, [0 0 3 0], 0, ...
              '注入第 3 组采样线开路：应判采样回路异常并闭锁');
S{end+1} = mk('S12_均衡测量窗口',  6,  900,  25, [60 60 60 60], 30, 50, [0 0 0 0], 0, ...
              '压差场景：验证均衡开/停相位与"被均衡节读数被压低"的处理');

idx = 1:numel(S);
if ~(ischar(whichScen) && strcmp(whichScen,'all'))
    idx = whichScen;
end

results = struct('name',{},'pass',{},'metrics',{},'notes',{});
fprintf('\n================ BMS 场景回归 ================\n');

for k = idx
    sc = S{k};
    fprintf('\n----------- [%02d] %s -----------\n', k, sc.name);
    fprintf('  工况: scen=%d  %.0f s  环境 %.0f℃  初始SOC %s\n', ...
            sc.scen, sc.T, sc.t_amb, mat2str(sc.soc0));
    fprintf('  意图: %s\n', sc.note);

    SCEN = build_scen(sc);
    assignin('base','SCEN',SCEN);
    set_param(mdl, 'StopTime', num2str(sc.T));

    try
        out = sim(mdl);
    catch e
        fprintf('  ★ 仿真失败: %s\n', e.message);
        results(end+1) = struct('name',sc.name,'pass',false,'metrics',struct(), ...
                                'notes',['仿真失败: ' e.message]); %#ok<SAGROW>
        continue;
    end

    m = analyse(out, sc);
    [ok, notes] = verdict(m, sc);
    results(end+1) = struct('name',sc.name,'pass',ok,'metrics',m,'notes',notes); %#ok<SAGROW>
    prt_metrics(m);
    fprintf('  结论: %s\n', notes);
    fprintf('  >>> %s\n', tern(ok,'PASS','FAIL'));

    if makePlot
        save_fig(m, sc, FIG);
    end
end

fprintf('\n================ 汇总 ================\n');
fprintf('%-24s %-6s %s\n','场景','结果','说明');
for k = 1:numel(results)
    fprintf('%-24s %-6s %s\n', results(k).name, tern(results(k).pass,'PASS','FAIL'), ...
            results(k).notes);
end
n_pass = sum([results.pass]);
fprintf('\n通过 %d / %d\n', n_pass, numel(results));
end

%% ================= 场景构造 =================
function s = mk(name, scen, T, t_amb, soc0, chgLim, dsgLim, inj_cell, inj_ntc, note)
s = struct('name',name,'scen',scen,'T',T,'t_amb',t_amb,'soc0',soc0, ...
           'chgLim',chgLim,'dsgLim',dsgLim,'inj_cell',inj_cell,'inj_ntc',inj_ntc,'note',note);
end

function SCEN = build_scen(sc)
dt   = 0.05;
tt   = (0:dt:sc.T)';
n    = numel(tt);
rst  = zeros(n,1);  rst(1:2) = 1;             % 开头给复位脉冲
soc0 = repmat(sc.soc0, n, 1);
inj  = repmat(sc.inj_cell, n, 1);
ntc  = repmat(sc.inj_ntc, n, 1);
SCEN = [tt, sc.scen*ones(n,1), sc.chgLim*ones(n,1), sc.dsgLim*ones(n,1), ...
        zeros(n,1), inj, ntc, sc.t_amb*ones(n,1), rst, soc0];
end

%% ================= 结果解析 =================
function m = analyse(out, sc)
lp = out.LOG_PLANT; la = out.LOG_AFE; lb = out.LOG_BMS; ld = out.LOG_DBG;
Vp = lp.signals.values; Va = la.signals.values; Vb = lb.signals.values; Vd = ld.signals.values;
t  = lp.time;

m = struct();
m.t = t;
m.i_cmd   = Vp(:,1);   m.i_pack = Vp(:,2);
m.v_pack  = Vp(:,3);   m.v_true = Vp(:,4:7);
m.t_cell  = Vp(:,8);   m.soc_true = Vp(:,9:12);   m.p_loss = Vp(:,13);
m.v_meas  = Va(:,1:4); m.v_pack_meas = Va(:,5);
m.cc_raw  = Va(:,6);   m.sys_stat = Va(:,8);      m.bal_drop = Va(:,10);
m.chg_en  = Vb(:,1);   m.dsg_en = Vb(:,2);        m.bal_mask = Vb(:,3);
m.soc     = Vb(:,4);   m.fault = Vb(:,7);         m.led = Vb(:,8);   m.temp = Vb(:,9);
m.dbg     = Vd;

m.soc_err_end = m.soc(end) - mean(m.soc_true(end,:));
m.faults = unique(m.fault(m.fault > 0));
m.min_vmeas = min(m.v_meas(:));
m.max_vmeas = max(m.v_meas(:));
m.min_temp = min(m.temp); m.max_temp = max(m.temp);
m.fault_cnt = sum(diff([0; m.fault]) ~= 0);
m.dsg_off_t = m.t(find(m.dsg_en == 0, 1));
m.chg_off_t = m.t(find(m.chg_en == 0, 1));
m.bal_on_frac = mean(m.bal_mask > 0);
m.sys_any = any(m.sys_stat > 0);
m.wire_ok_min = min(m.dbg(:,10));
m.tzone_set = unique(m.dbg(:,8))';
m.sens_set = unique(m.dbg(:,9))';
m.i_pack_end = m.i_pack(end);
m.led_end = m.led(end);
end

%% ================= 判据 =================
function [ok, notes] = verdict(m, sc)
ok = true; notes = {};

switch sc.scen
case 1   % 静置
    if abs(m.soc_err_end) > 0.5
        ok = false; notes{end+1} = sprintf('静置时 SOC 漂了 %.2f%%（应 <0.5%%）', m.soc_err_end);
    end
    if ~isempty(m.faults)
        ok = false; notes{end+1} = sprintf('静置时出现故障码 %s', mat2str(m.faults));
    end
    if m.wire_ok_min < 1
        ok = false; notes{end+1} = '采样回路被误判为异常';
    end
    notes{end+1} = sprintf('SOC %.2f%% / 偏差 %+.3f%% / LED %d 灯', m.soc(end), m.soc_err_end, ...
                           sum(bitget(uint8(m.led_end),1:5)));

case 2   % 放电到空
    if abs(m.i_pack_end + 30) > 2
        ok = false; notes{end+1} = sprintf('末拍电流 %.1f A 不是 -30A（说明被保护切断了）', m.i_pack_end);
    end
    if abs(m.soc_err_end) > 3
        ok = false; notes{end+1} = sprintf('库仑计 SOC 偏差 %.2f%%（应 <3%%）', m.soc_err_end);
    end
    if m.min_vmeas <= 2500
        notes{end+1} = '★电压确实跌到 2500mV 以下，UV 保护会触发';
    else
        notes{end+1} = sprintf('★注意：最低单体只到 %.0f mV，UV(2500mV) 根本没触发——', m.min_vmeas);
        notes{end+1} = '   说明该组内阻小(16mΩ)，1C 放电压不出来，低压保护形同虚设，';
        notes{end+1} = '   实际防过放只能靠库仑计 SOC 与"放空判定"（2650mV 门槛同理难达到）';
    end

case 3   % 充电
    if m.max_vmeas >= 3650
        notes{end+1} = sprintf('充电把单体推到 %.0f mV，已到 OV 阈值 3650mV → CHG 被切断', m.max_vmeas);
    end
    if ~isempty(m.faults)
        notes{end+1} = sprintf('充电过程故障码：%s（满充/过压属预期）', mat2str(m.faults));
    end
    if m.soc(end) < 90
        notes{end+1} = sprintf('末拍 SOC 仅 %.1f%%（未充满，可能是 OV 提前切断）', m.soc(end));
    else
        notes{end+1} = sprintf('末拍 SOC %.1f%%，容量学习值 %.3f Ah', ...
                               m.soc(end), m.dbg(end,15)*0+NaN);
    end

case 4   % 放电过流
    if isempty(m.dsg_off_t)
        ok = false; notes{end+1} = '60A 过流时 DSG 一直没有关断 —— 保护失效！';
    else
        notes{end+1} = sprintf('DSG 在 %.2f s 关断（60A 起流后 %.0f ms）', m.dsg_off_t, m.dsg_off_t*1000);
    end
    if m.sys_any
        notes{end+1} = 'AFE 硬件状态位有置位（OCD/SCD）';
    end

case 5   % 充电过流
    if isempty(m.chg_off_t)
        ok = false; notes{end+1} = '35A 充电过流时 CHG 没有关断 —— 软件保护失效！';
    else
        notes{end+1} = sprintf('CHG 在 %.2f s 关断（35A 起流后 %.0f ms，去抖设定 100ms）', ...
                               m.chg_off_t, m.chg_off_t*1000);
    end

case 6   % 循环
    if ~isempty(m.faults)
        ok = false; notes{end+1} = sprintf('循环工况出现故障码 %s', mat2str(m.faults));
    end
    notes{end+1} = sprintf('SOC %.1f%%→%.1f%%，SOC 偏差 %+.2f%%，均衡占空比 %.1f%%', ...
                           m.soc(1), m.soc(end), m.soc_err_end, m.bal_on_frac*100);
    notes{end+1} = sprintf('压差范围 %s mV', mat2str(round([min(m.dbg(:,4)) max(m.dbg(:,4))])));

case 7   % 短路脉冲
    if ~m.sys_any
        ok = false; notes{end+1} = '150A 短路脉冲没有触发 AFE 状态位';
    else
        notes{end+1} = 'AFE 短路保护触发（SYS_STAT 有置位）';
    end
    if isempty(m.dsg_off_t)
        ok = false; notes{end+1} = '短路后 DSG 未关断';
    else
        notes{end+1} = sprintf('DSG 在 %.3f s 关断', m.dsg_off_t);
    end
    if m.fault_cnt > 20
        notes{end+1} = sprintf('故障状态来回切换 %d 次，建议检查重试逻辑是否会抖动', m.fault_cnt);
    end

case 8   % 低温充电
    if isempty(m.chg_off_t)
        ok = false; notes{end+1} = '-10℃ 下 CHG 没被关断 —— 低温禁充失效！';
    else
        notes{end+1} = sprintf('CHG 在 %.2f s 关断（低温禁充生效），温度 %.1f℃', ...
                               m.chg_off_t, m.temp(min(numel(m.temp), round(m.chg_off_t/0.01)+10)));
    end
    if m.max_temp > 5
        notes{end+1} = sprintf('★注意：热模型下温度只升到 %.1f℃，仍低于 0℃ 阈值', m.max_temp);
    end

case 9   % 高温放电
    if isempty(m.dsg_off_t) && isempty(m.chg_off_t)
        ok = false; notes{end+1} = '65℃ 下充放电都没被限制 —— 过温保护失效！';
    else
        notes{end+1} = sprintf('65℃ 下 CHG 首次关断于 %.2f s，DSG 首次关断于 %s s', ...
                               m.chg_off_t, mat2str(m.dsg_off_t));
    end
    if ~any(m.tzone_set >= 3)
        ok = false; notes{end+1} = '温度分区没有进入高温区';
    else
        notes{end+1} = sprintf('温度分区经历 %s（0正常/1低温/2极低温/3禁充/4过温/5故障）', ...
                               mat2str(m.tzone_set));
    end

case 10  % NTC 开路
    if ~any(m.sens_set >= 1)
        ok = false; notes{end+1} = 'NTC 开路没有识别成传感器故障';
    else
        notes{end+1} = sprintf('识别为传感器状态 %s（1开路/2短路/4不稳定）', mat2str(m.sens_set));
    end
    if isempty(m.dsg_off_t) || isempty(m.chg_off_t)
        ok = false; notes{end+1} = '传感器故障没有闭锁充放电（fail-safe 未生效）';
    else
        notes{end+1} = sprintf('充放电均闭锁于 %.2f s / %.2f s', m.chg_off_t, m.dsg_off_t);
    end
    notes{end+1} = sprintf('★关键：温度没有被当成 -40℃ 的假温度用（本次最高 %.1f℃）', m.max_temp);
end

% 通用检查：采样回路异常在 S11 里必须闭锁
if sc.scen == 1 && sc.inj_cell(3) == 3
    if m.wire_ok_min > 0
        ok = false; notes{end+1} = '采样线开路没有判成采样回路异常';
    else
        notes{end+1} = '采样回路判为异常（wire_ok=0）';
    end
    if isempty(m.dsg_off_t)
        ok = false; notes{end+1} = '采样异常没有闭锁放电';
    else
        notes{end+1} = sprintf('充放电在 %.2f s / %.2f s 被闭锁', m.chg_off_t, m.dsg_off_t);
    end
end

if isempty(notes), notes{end+1} = '符合预期'; end
notes = strjoin(notes, ' | ');
end

function prt_metrics(m)
fprintf('  SOC(BMS) %.2f%%  SOC(真值) %.2f%%  偏差 %+.3f%%\n', ...
        m.soc(end), mean(m.soc_true(end,:)), m.soc_err_end);
fprintf('  电压: 测量 %.0f~%.0f mV  组端 %.2f→%.2f V\n', ...
        m.min_vmeas, m.max_vmeas, m.v_pack(1)/1000, m.v_pack(end)/1000);
fprintf('  温度 %.1f~%.1f℃  电流 %.1f→%.1f A\n', m.min_temp, m.max_temp, ...
        m.i_pack(1), m.i_pack_end);
fprintf('  CHG首次关断 %s  DSG首次关断 %s  故障码 %s\n', ...
        fmt_t(m.chg_off_t), fmt_t(m.dsg_off_t), mat2str(m.faults));
fprintf('  均衡占空比 %.2f%%  采样异常? %d  温度分区 %s\n', ...
        m.bal_on_frac*100, 1-m.wire_ok_min, mat2str(m.tzone_set));
end

function s = fmt_t(t)
if isempty(t), s = '——'; else, s = sprintf('%.2fs', t); end
end

function s = tern(c,a,b)
if c, s = a; else, s = b; end
end

%% ================= 出图 =================
function save_fig(m, sc, FIG)
f = figure('Visible','off','Position',[100 100 1200 800]);
subplot(4,1,1);
plot(m.t, m.i_cmd, '--', m.t, m.i_pack, 'LineWidth',1); grid on;
legend('要求电流','实际电流'); ylabel('电流 A'); title(sc.name);
subplot(4,1,2);
plot(m.t, m.v_true, m.t, m.v_meas,'--'); grid on; ylabel('单体电压 mV');
legend('组1真','组2真','组3真','组4真','组1测','组2测','组3测','组4测','Location','best');
subplot(4,1,3);
plot(m.t, m.soc, m.t, mean(m.soc_true,2),'--'); grid on; ylabel('SOC %'); legend('BMS','真值');
subplot(4,1,4);
plot(m.t, m.chg_en, m.t, m.dsg_en, m.t, m.bal_mask/16, m.t, m.fault/12); grid on;
ylabel('状态'); xlabel('时间 s');
legend('CHG','DSG','均衡(归一)','故障(归一)','Location','best');
name = regexprep(sc.name, '[\\/:*?"<>|]', '_');
exportgraphics(f, fullfile(FIG, [name '.png']), 'Resolution', 110);
close(f);
end
