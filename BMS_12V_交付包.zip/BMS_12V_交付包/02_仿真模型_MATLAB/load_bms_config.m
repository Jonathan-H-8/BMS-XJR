function cfg = load_bms_config(headerPath)
%LOAD_BMS_CONFIG  解析固件头文件 bms_config.h，取出所有数值型 #define
%
%   目的是让 Simulink 模型与固件**共用同一套常量**：
%   改了 C 里的阈值，重跑一次本函数，仿真就跟着变，不会出现
%   "仿真通过、板上行为不同" 这种对不上的情况。
%
%   只解析纯数字字面量（十进制/十六进制/浮点，可带 U/L/F 后缀或外层括号），
%   凡是引用了标识符或表达式的宏（如 BQ_I2C、BMS_TS1_LSB_V）会被自动跳过。
%
%   用法：
%       cfg = load_bms_config('../../bms_firmware/Core/Inc/bms_config.h');
%       cfg.BMS_CELL_OV_MV      % 3650
%       cfg.BMS_CAPACITY_AH     % 30

if nargin < 1 || isempty(headerPath)
    % 默认路径：相对本文件定位到固件头文件
    here = fileparts(mfilename('fullpath'));
    headerPath = fullfile(here, '..', 'bms_firmware', 'Core', 'Inc', 'bms_config.h');
end
if ~isfile(headerPath)
    error('load_bms_config:找不到头文件: %s', headerPath);
end

txt  = fileread(headerPath);
% 去掉块注释与行注释，避免注释里的数字被误当成宏值
txt  = regexprep(txt, '/\*.*?\*/', ' ', 'dotall');
txt  = regexprep(txt, '//[^\n]*', ' ');

tok = regexp(txt, '#\s*define\s+([A-Za-z_]\w*)[ \t]+([^\r\n]+)', 'tokens');

cfg = struct();
cfg.cfg_src_file = headerPath;   % MATLAB 标识符不能以 _ 开头，所以不叫 __file__
n_ok = 0; n_skip = 0;

for k = 1:numel(tok)
    name = tok{k}{1};
    val  = strtrim(tok{k}{2});

    % 去掉可能的行尾残留
    val = regexprep(val, '/[/*].*$', '');
    val = strtrim(val);

    % 去掉外层括号：  (-40)  ->  -40
    for rep = 1:3
        if numel(val) > 2 && val(1) == '(' && val(end) == ')'
            val = strtrim(val(2:end-1));
        else
            break;
        end
    end

    % 去掉整型/浮点后缀
    val = regexprep(val, '[uUlLfF]+$', '');

    if ~isempty(regexpi(val, '^0x[0-9a-f]+$'))
        num = double(hex2dec(val(3:end)));
    elseif ~isempty(regexp(val, '^-?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$', 'once'))
        num = str2double(val);
    else
        n_skip = n_skip + 1;
        continue;       % 引用标识符/表达式的宏，跳过
    end
    if isnan(num)
        n_skip = n_skip + 1;
        continue;
    end

    cfg.(name) = num;
    n_ok = n_ok + 1;
end

fprintf('[load_bms_config] %s\n', headerPath);
fprintf('                  解析到 %d 个数值宏，跳过 %d 个（表达式/非数值）\n', n_ok, n_skip);

% ---- 关键项自检：缺失或明显异常就报警，避免仿真悄悄用了错参数 ----
must = {'BMS_CELL_COUNT','BMS_CAPACITY_AH','BMS_CELL_OV_MV','BMS_CELL_UV_MV', ...
        'BMS_CHARGE_MAX_A','BMS_DISCHARGE_MAX_A','BMS_RSENSE_MOHM', ...
        'BMS_TEMP_CHG_MIN','BMS_TEMP_CHG_MAX','BMS_TEMP_DSG_MAX', ...
        'BMS_BAL_DELTA_MV','BMS_BAL_START_MV','BMS_OC_SW_DELAY_MS'};
miss = must(~isfield(cfg, must));
if ~isempty(miss)
    warning('load_bms_config:缺少宏: %s', strjoin(miss, ', '));
end

fprintf('                  %dS / %.0f Ah / 充 %.0f A / 放 %.0f A / Rsense %.3f mΩ\n', ...
        cfg.BMS_CELL_COUNT, cfg.BMS_CAPACITY_AH, cfg.BMS_CHARGE_MAX_A, ...
        cfg.BMS_DISCHARGE_MAX_A, cfg.BMS_RSENSE_MOHM);
end
