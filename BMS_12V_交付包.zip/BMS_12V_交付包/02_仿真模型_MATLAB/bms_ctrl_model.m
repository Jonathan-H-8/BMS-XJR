function y = bms_ctrl_model(cc_raw, sys_stat, v_meas, v_pack_meas, ts1_adc, cmd, t, rst)
%%#codegen
%BMS_CTRL_MODEL  固件逻辑移植（作为 Simulink MATLAB Function 块使用）
%
%   这是 bms_firmware/Core/Src 下 bms_soc / bms_cells / bms_temp / bms_balance /
%   bms_protect / bms_led / bms_app 的 MATLAB 等价实现，逐条对应，
%   用来在 Simulink 里跑固件逻辑（真机烧录前的回归测试）。
%
%   调度（与 bms_app.c 的 BMS_Loop 一致，模型固定步长必须取 10ms）：
%     10ms  : 保护评估 + LED + 均衡相位(Bal_Task)
%     250ms : 单体检测 + SOC 库仑积分 + 满充/放空/静置判定
%     1000ms: 温度检测
%     5000ms: 均衡策略
%
%   输入：
%     cc_raw        库仑计读数（LSB，+充电/−放电）
%     sys_stat      AFE 的 SYS_STAT
%     v_meas        1×4 单体测量电压 mV
%     v_pack_meas   组端测量电压 mV
%     ts1_adc       TS1 通道 ADC 码
%     cmd           1×6 运行命令：[chg限流A, dsg限流A, 清故障脉冲, 上电SOC%, 预留, 冷启动标志]
%                   ★ 第 4 项模拟 EEPROM 里存的"掉电前电量"：
%                     ≥ 0  → 有记录，上电直接恢复该值（不受极化影响，最准）
%                     < 0  → 无记录，改走"上电快速 OCV 对齐"（需静置 15~21s）
%                   ★ 第 5 项预留给后续扩展（当前恒 0），保持第 6 项固定为冷启动标志
%                   ★ 第 6 项 = 1 表示待测电芯判定为冷启动，用于标注 SOC 来源
%     t             仿真时间 s
%     rst           复位脉冲（每个仿真开头给 1，清所有持久状态）
%
%   输出：
%     chg_en/dsg_en 充电/放电管允许      bal_mask  均衡掩码（AFE 槽位）
%     cc_read       读库仑计脉冲          clr_mask  写 SYS_STAT 的清除掩码
%     soc_pct / remain_ah / cap_ah / fault / led_mask / temp_c
%     soc_aligned   SOC 是否已对齐真实值（0 = 仍是 50% 占位值，别采信）
%     dbg           1×15 诊断：[max,min,avg,delta,sumErr,trusted,balApplied,zone,
%                    sens,wire_ok,unbal,chgLim,dsgLim,errCode,samples]
%
%   ★ 本块内的常量与 bms_config.h 一一对应；跑 check_cfg_sync.m 可自动核对。

%% ==================== 常量（来自 bms_config.h）====================
CELL_N      = 4;
CAP_AH      = 30.0;          % 2P4S：C33 15Ah × 2P
COULOMB_EFF = 0.99;

OV_MV = 3650;  UV_MV = 2500;              % AFE 硬跳闸
OV_WARN_MV = 3550;  UV_WARN_MV = 2700;    % 软件预警
OV_DEB = 3;  UV_DEB = 3;                  % ×250ms
HYST_MV = 100;

PLAUS_MIN = 1200;  PLAUS_MAX = 4300;
SUM_TOL_MV = 150;  SUM_BAD_CNT = 4;
DELTA_WARN_MV = 80;  DELTA_HOLD_MS = 60000;
BAL_SETTLE_MS = 300;  HOLD_MAX_MS = 30000;

CHG_MIN = 0;  CHG_MAX = 50;  DSG_MAX = 60;
CRIT_LOW = -20;  VALID_MIN = -40;  VALID_MAX = 100;
NTC_R0 = 10000;  NTC_B = 3435;  PULLUP = 10000;  VREF = 3.3;  TS_LSB_UV = 382;
TEMP_FILT_N = 4;  TEMP_RATE_MAX = 8;  TEMP_REJ_MAX = 3;  TEMP_BOOT_GRACE = 3000;

BAL_START_MV = 3400;  BAL_DELTA_MV = 30;  BAL_MIN_MV = 2800;
BAL_TMIN = 5;  BAL_TMAX = 45;  BAL_IMAX = 1.0;  BAL_OV_GUARD = 200;
BAL_ON_MS = 5000;  BAL_PAUSE_MS = 900;

OC_SW_DELAY_MS = 100;  OC_RETRY_MS = 5000;  OC_MAX_RETRY = 3;  OC_RECOVER = 0.80;
DEF_CHG_LIM = 30.0;  DEF_DSG_LIM = 50.0;

FULL_DETECT_MV = 3550;  FULL_DETECT_A = 1.0;  FULL_HOLD_MS = 30000;
EMPTY_DETECT_MV = 2650;  EMPTY_HOLD_MS = 5000;
OCV_REST_A = 0.05;  OCV_REST_MS = 1800000;  OCV_W = 0.10;

% ---- 上电 SOC 对齐（与 bms_config.h 一一对应）----
%   解决"上电固定按 50% 起步、仪表显示假电量"的问题：
%   ① EEPROM 掉电记忆（cmd(4) 给入）—— 主路径，不受极化影响，最可信
%   ② 上电快速 OCV 对齐（本块内实现）—— 仅在无记录时需要
%   ★ 两条都不成立时，SOC 保持 UNKNOWN，上层禁止显示具体数字（不再有 50% 占位）
BMS_OCV_BOOT_MS        = 15000;
BMS_OCV_BOOT_WIN       = 8;
BMS_OCV_BOOT_STABLE_MV = 20;
BMS_OCV_BOOT_HOLD      = 3;
BMS_OCV_BOOT_WEIGHT    = 0.50;
BMS_OCV_BOOT_SNAP_PCT  = 8.0;

% SOC 可信度分级（与 C 固件 Soc_State_t 同序）
SOC_UNKNOWN      = 0;      % 电量不可知，禁止显示具体数字
SOC_RESTORED     = 1;      % 由 EEPROM 掉电记录恢复（最可信）
SOC_OCV_ALIGNED  = 2;      % 由 OCV 对齐得到

% ★ "电量未知"时对外输出的哨兵值（与 bms_config.h 的 BMS_SOC_UNKNOWN_X10 一致）
BMS_SOC_UNKNOWN_X10 = 65535;

CC_LSB_A   = 8.44e-3;
CC_LSB_NAH = CC_LSB_A * (250/3600000) * 1e9;      % 586.1 nAh/LSB

LEARN_MIN_AH = 9.0;                                % 0.3 × 30Ah

% OCV 表（与 bms_soc.c 的 s_ocv 完全相同：mV 由高到低）
OCV_MV  = [3400 3360 3340 3325 3315 3308 3300 3292 3285 3275 3262 3240 3180 3000];
OCV_SOC = [ 100   97   90   80   70   60   50   40   30   20   12    7    3    0];

% 组号 → CELLBAL1 的 bit（本板 4S：组1..4 → 槽1,2,3,5）
SLOTBIT = [1 2 4 16];

% 故障码（与 Bms_Fault_t 同序）
F_NONE=0; F_OV=1; F_UV=2; F_OCDSG=3; F_SCD=4; F_OCCHG=5;
F_THIGH=6; F_TLOW=7; F_TSENS=8; F_WIRE=9; F_AFE=10; F_LOCKED=11;

%% ==================== 持久状态 ====================
persistent led_m socp S_remain S_cap S_valid S_seen_full S_seen_empty S_q_empty S_q_full S_charge_count S_full_flag S_learned P_ov P_uv P_ocd P_scd P_occhg P_ocdsg_ms P_occhg_ms P_retry_at P_retry_cnt P_locked P_fault P_counts P_retry_reset P_wire_lat P_tsens_lat P_thigh_lat P_tlow_lat P_tsens_init P_chg_lim P_dsg_lim P_cur C_hist C_hn C_hold C_holdms C_trust C_mv C_ovst C_uvst C_thi C_tlo C_whi C_wlo C_sumbad C_sumerr C_unbal_ms C_unbal C_wire_ok C_err C_app_prev C_untrust C_untrust_until C_min C_max C_avg C_delta C_sum C_samples C_imax C_imin C_rest_ms C_full_hold C_empty_hold T_buf T_idx T_cnt T_last T_rej T_zone T_valid T_sens T_cellc T_raw T_boot T_samples T_rejects T_keymask B_mask B_applied B_active B_phase_ms B_inpause B_delta B_target R_tick R_tprev R_acc_f R_acc_c R_acc_s R_acc_b s_aligned s_boot_win s_boot_idx s_boot_cnt s_boot_rest_ms s_boot_hold s_boot_done s_soc_state s_cold_boot
if isempty(S_remain)
    S_remain = 0;
    S_cap = CAP_AH*1e9;
    S_valid = false;
    S_seen_full = false;
    S_seen_empty = false;
    S_q_empty = 0;
    S_q_full = 0;
    S_charge_count = 0;
    S_full_flag = false;
    S_learned = 0;
    P_ov = false;
    P_uv = false;
    P_ocd = false;
    P_scd = false;
    P_occhg = false;
    P_ocdsg_ms = 0;
    P_occhg_ms = 0;
    P_retry_at = 0;
    P_retry_cnt = 0;
    P_locked = false;
    P_fault = F_NONE;
    P_counts = zeros(1,12);
    P_retry_reset = 0;
    P_wire_lat = false;
    P_tsens_lat = false;
    P_thigh_lat = false;
    P_tlow_lat = false;
    P_tsens_init = false;
    P_chg_lim = DEF_CHG_LIM;
    P_dsg_lim = DEF_DSG_LIM;
    P_cur = 0;
    C_hist = zeros(3,CELL_N);
    C_hn = zeros(1,CELL_N);
    C_hold = zeros(1,CELL_N);
    C_holdms = zeros(1,CELL_N);
    C_trust = false(1,CELL_N);
    C_mv = zeros(1,CELL_N);
    C_ovst = false(1,CELL_N);
    C_uvst = false(1,CELL_N);
    C_thi = zeros(1,CELL_N);
    C_tlo = zeros(1,CELL_N);
    C_whi = zeros(1,CELL_N);
    C_wlo = zeros(1,CELL_N);
    C_sumbad = 0;
    C_sumerr = 0;
    C_unbal_ms = 0;
    C_unbal = false;
    C_wire_ok = true;
    C_err = 0;
    C_app_prev = 0;
    C_untrust = 0;
    C_untrust_until = 0;
    C_min = 0;
    C_max = 0;
    C_avg = 0;
    C_delta = 0;
    C_sum = 0;
    C_samples = 0;
    C_imax = 0;
    C_imin = 0;
    C_rest_ms = 0;
    C_full_hold = 0;
    C_empty_hold = 0;
    T_buf = zeros(1,4);
    T_idx = 0;
    T_cnt = 0;
    T_last = 25;
    T_rej = 0;
    T_zone = 0;
    T_valid = false;
    T_sens = 0;
    T_cellc = 25;
    T_raw = 25;
    T_boot = 0;
    T_samples = 0;
    T_rejects = 0;
    T_keymask = false;
    B_mask = 0;
    B_applied = 0;
    B_active = false;
    B_phase_ms = 0;
    B_inpause = false;
    B_delta = 0;
    B_target = 0;
    R_tick = 0;
    R_tprev = -1;
    R_acc_f = 0; R_acc_c = 0; R_acc_s = 0; R_acc_b = 0;
    % 上电 SOC 对齐状态
    s_aligned = false;
    s_boot_done = false;
    s_boot_rest_ms = 0;
    s_boot_hold = 0;
    s_boot_cnt = 0;
    s_boot_idx = 1;
    s_boot_win = zeros(1, BMS_OCV_BOOT_WIN);
end

% ★ MATLAB Function 块的 persistent 状态跨 sim 不会自动清零，必须用 rst 显式复位
if rst > 0
    % ★ 与 C 固件 Soc_Init() 一致：不写 50% 占位值。
    %   真实电量未知就是未知 —— S_remain = 0 只是"还没开始积分"的内部起点，
    %   对外由 s_aligned / s_soc_state 标记为不可信（上层禁止显示具体数字）。
    S_remain = 0; S_cap = CAP_AH*1e9; S_valid = false;
    S_seen_full = false; S_seen_empty = false; S_q_empty = 0; S_q_full = 0;
    S_charge_count = 0; S_full_flag = false; S_learned = 0;
    P_ov = false; P_uv = false; P_ocd = false; P_scd = false; P_occhg = false;
    P_ocdsg_ms = 0; P_occhg_ms = 0; P_retry_at = 0; P_retry_cnt = 0;
    P_locked = false; P_fault = F_NONE; P_counts = zeros(1,12);
    P_retry_reset = 0; P_wire_lat = false; P_tsens_lat = false;
    P_thigh_lat = false; P_tlow_lat = false;
    P_chg_lim = DEF_CHG_LIM; P_dsg_lim = DEF_DSG_LIM; P_cur = 0;
    C_hist = zeros(3,CELL_N); C_hn = zeros(1,CELL_N);
    C_hold = zeros(1,CELL_N); C_holdms = zeros(1,CELL_N);
    C_trust = false(1,CELL_N); C_mv = zeros(1,CELL_N);
    C_ovst = false(1,CELL_N); C_uvst = false(1,CELL_N);
    C_thi = zeros(1,CELL_N); C_tlo = zeros(1,CELL_N);
    C_whi = zeros(1,CELL_N); C_wlo = zeros(1,CELL_N);
    C_sumbad = 0; C_sumerr = 0; C_unbal_ms = 0; C_unbal = false;
    C_wire_ok = true; C_err = 0; C_app_prev = 0; C_untrust = 0; C_untrust_until = 0;
    C_min = 0; C_max = 0; C_avg = 0; C_delta = 0; C_sum = 0; C_samples = 0;
    C_imax = 0; C_imin = 0; C_rest_ms = 0; C_full_hold = 0; C_empty_hold = 0;
    T_buf = zeros(1,4); T_idx = 0; T_cnt = 0; T_last = 25; T_rej = 0;
    T_zone = 0; T_valid = false; T_sens = 0; T_cellc = 25; T_raw = 25;
    T_boot = 0; T_samples = 0; T_rejects = 0; T_keymask = false;
    B_mask = 0; B_applied = 0; B_active = false; B_phase_ms = 0;
    B_inpause = false; B_delta = 0; B_target = 0;
    R_tick = 0; R_tprev = -1;
    R_acc_f = 0; R_acc_c = 0; R_acc_s = 0; R_acc_b = 0;
    % 上电 SOC 对齐状态（复位后由下面的"上电 SOC 对齐"段重新决定）
    s_aligned = false; s_boot_done = false;
    s_boot_rest_ms = 0; s_boot_hold = 0; s_boot_cnt = 0; s_boot_idx = 1;
    s_boot_win = zeros(1, BMS_OCV_BOOT_WIN);
    s_soc_state = SOC_UNKNOWN;      % ★ 与 C 固件 SOC_STATE_UNKNOWN 对应
    s_cold_boot = false;            % ★ 冷启动标志（由 cmd(6) 告知，仿真里可注入）
    led_m = 0; socp = 0;            % ★ socp 不再是 50%，未对齐时上层不使用它
end

% 步长（不假设固定步长）
% ★ 本块用「计数器周期」而不是「绝对 tick 取模」，这样两种跑法都成立：
%   · dt = 0.01s（10ms，正式仿真）：计数器每 25 / 100 / 500 拍 = 250ms/1s/5s，与固件一致
%   · dt = 0.1~0.5s（纯逻辑长跑）：计数器会按步长折算，周期仍是 250ms/1s/5s 的
%     「时间等价」值，不会因为步长变大就 25 步才采一次（那会变成 2.5s 才采一次）
%   早期版本写的是 mod(R_tick,25)==0，一旦把步长放宽就会整片乱掉，故改为此写法。
if R_tprev < 0
    DT_MS = 10;
else
    DT_MS = (t - R_tprev) * 1000;
    if DT_MS <= 0
        DT_MS = 10;
    end
end
R_tprev = t;
R_tick = R_tick + 1;

% 周期计数器（用浮点累加，避免大 T 时整数溢出；0.5 的容差足以判"到点"）
% ★ 累加量取整（round）的原因：DT_MS = (t - R_tprev)*1000 是浮点减法的结果，
%   可能是 9.999999999999998 这种值，累加 25 次够不到 250 → 任务周期被撑长。
%   真实固件用的是 HAL_GetTick()（整数毫秒），所以这里对齐到整数才等价。
DTS = round(DT_MS);
R_acc_f = R_acc_f + DTS;         % 对应 TASK_FAST(10ms) 基准
R_acc_c = R_acc_c + DTS;         % 对应 TASK_CELL(250ms)
R_acc_s = R_acc_s + DTS;         % 对应 TASK_SLOW(1000ms)
R_acc_b = R_acc_b + DTS;         % 对应 BAL_PERIOD(5000ms)
d_fast = 0; d_cell = 0; d_slow = 0; d_bal = 0;
if R_acc_f >= 10    , d_fast = 1; R_acc_f = R_acc_f - 10;    end
if R_acc_c >= 250   , d_cell = 1; R_acc_c = R_acc_c - 250;   end
if R_acc_s >= 1000  , d_slow = 1; R_acc_s = R_acc_s - 1000;  end
if R_acc_b >= 5000  , d_bal  = 1; R_acc_b = R_acc_b - 5000;  end

% 当前 SOC（后面多处要用）
if S_cap > 0
    socp = S_remain * 100 / S_cap;
else
    socp = 0;
end

cur = cc_raw * CC_LSB_A;
P_cur = cur;

%% ==================== 10ms：库仑计积分（★ 必须与 bms_app.c 逐字一致）====================
% C 固件 bms_app.c 里 fast_task() 的原文：
%     stat = BQ_GetSysStat();
%     if ((stat & BQ_STAT_CC_READY) != 0U) {
%         BQ_ReadCc();                       /* 读走即复位 */
%         Soc_OnCcSample(g_bq.cc_raw);
%         BQ_ClearSysStat(BQ_STAT_CC_READY);
%     }
%
% ★★ 关键：触发源是 AFE 的 CC_READY 位，不是固件自己的 250ms 计数器。
%    250ms 软件周期与 AFE 的 250ms 转换周期是两套独立时钟。若改用软件计数器
%    触发，两者相位一旦错开，固件就会在**电流阶跃点**读到"上一个窗口"的值 ——
%    恒流时无害（值本来相同），电流一突变就少算/多算一整个窗口的电荷。
%    （本移植的早期版本正是漏了这一点，凭空造出 +0.18% 的虚假偏差，
%      详见 FSAE耐力赛工况测试报告.md 的"结论更正"一节。）
cc_read = uint8(0);
if bitand(uint8(sys_stat), uint8(128)) ~= 0       % CC_READY = SYS_STAT bit7
    q = round(cc_raw * CC_LSB_NAH);
    if q > 0
        q = round(q * COULOMB_EFF);               % 充电按库仑效率打折
        S_q_empty = S_q_empty + q;
    else
        S_q_full = S_q_full - q;
    end
    S_remain = S_remain + q;
    S_remain = max(0, min(S_cap, S_remain));
    if S_cap > 0, socp = S_remain * 100 / S_cap; end
    cc_read = uint8(1);                           % 通知 AFE：库仑计已读走
end

%% ==================== 10ms：上电 SOC 对齐 ====================
% 对应 C 固件 bms_app.c 里 BMS_Init() + cell_task() 的新增逻辑。
% 目标：让 SOC 始终有真值来源，而不是固定 50% 骗人。
% 两条路，优先走第一条：
%   ① boot_soc ≥ 0  → 视作"EEPROM 里存了掉电前的电量"，直接恢复（最准，不受极化影响）
%   ② boot_soc < 0  → 无记录，等"静置 + 电压稳定"后由 OCV 对齐（约 15~21 s）
%   两条都不成立 → 保持 SOC_UNKNOWN，对外不报数字
if rst > 0
    s_aligned     = false;
    s_boot_done   = false;
    s_boot_rest_ms = 0;
    s_boot_hold   = 0;
    s_boot_cnt    = 0;
    s_boot_idx    = 1;
    s_soc_state   = SOC_UNKNOWN;      % ★ 与 C 固件的 SOC_STATE_UNKNOWN 一致
    s_cold_boot   = (cmd(6) > 0);     % ★ 冷启动标志（由入参告知；仿真中用于标注来源）
    for i = 1:BMS_OCV_BOOT_WIN
        s_boot_win(i) = 0;
    end
    % ★ 第一条路：EEPROM 掉电记忆恢复
    if cmd(4) >= 0
        ss_pct = cmd(4);
        if ss_pct > 100, ss_pct = 100; end
        S_remain = S_cap * ss_pct / 100;
        S_remain = max(0, min(S_cap, S_remain));
        s_aligned   = true;
        s_soc_state = SOC_RESTORED;   % ★ 来源标记：EEPROM（最可信）
        if S_cap > 0, socp = S_remain * 100 / S_cap; end
    end
    % ★ 未对齐时 socp 保持 0：上层看 s_aligned / s_soc_state 决定要不要用
end

% ★ 第二条路：上电快速 OCV 对齐（仅当还没对齐过、且本次上电还没做过）
%   三个条件同时满足才采信，缺一不可：
%     ① 电流接近 0     —— 确实静置，不是带载测量
%     ② 电压稳定       —— 窗口内极差 < BMS_OCV_BOOT_STABLE_MV，说明极化已恢复完
%     ③ ①② 持续够久    —— ≥ BMS_OCV_BOOT_MS
%   ★ 为什么要 ②：刚跑完车立刻重启，端电压还带着极化（放电后偏低），
%     只看"电流小"会把极化电压误当成 OCV，反而把 SOC 拉错。
if ~s_boot_done && ~s_aligned
    if abs(cur) < OCV_REST_A
        % 推入窗口（普通数组 + 固定次数循环，避免 Simulink 尺寸推断失败）
        s_boot_win(s_boot_idx) = C_avg;
        s_boot_idx = s_boot_idx + 1;
        if s_boot_idx > BMS_OCV_BOOT_WIN, s_boot_idx = 1; end
        if s_boot_cnt < BMS_OCV_BOOT_WIN, s_boot_cnt = s_boot_cnt + 1; end

        % ★ 用浮点时间累加，不用 mod(tick,N)：后者只在步长恰好匹配时成立
        s_boot_rest_ms = s_boot_rest_ms + round(DT_MS);

        if s_boot_cnt >= BMS_OCV_BOOT_WIN
            vlo = 1e9; vhi = 0;
            for i = 1:BMS_OCV_BOOT_WIN
                if s_boot_win(i) < vlo, vlo = s_boot_win(i); end
                if s_boot_win(i) > vhi, vhi = s_boot_win(i); end
            end
            if (vhi - vlo) < BMS_OCV_BOOT_STABLE_MV
                if s_boot_hold < BMS_OCV_BOOT_HOLD
                    s_boot_hold = s_boot_hold + 1;
                end
            else
                s_boot_hold = 0;            % 电压还在动：重新数，不能采信
            end
        end

        if s_boot_rest_ms >= BMS_OCV_BOOT_MS && s_boot_hold >= BMS_OCV_BOOT_HOLD
            % ---- 采信 OCV（对应 C 的 Soc_OnBootOcv）----
            ocv_s = 0;
            mv = C_avg;
            if mv >= OCV_MV(1)
                ocv_s = 100;
            else
                for i = 2:numel(OCV_MV)
                    if mv >= OCV_MV(i)
                        vh = OCV_MV(i-1); vl = OCV_MV(i);
                        sh = OCV_SOC(i-1); sl = OCV_SOC(i);
                        ocv_s = sl + (mv - vl)/(vh - vl)*(sh - sl);
                        break;
                    end
                end
            end
            diff = ocv_s - socp;
            if diff > BMS_OCV_BOOT_SNAP_PCT || diff < -BMS_OCV_BOOT_SNAP_PCT
                % 差异过大 → 认为原有记录不可信，物理量优先
                S_remain = S_cap * ocv_s / 100;
            else
                % 差异不大 → 按较激进的权重融合
                S_remain = S_cap * (socp + BMS_OCV_BOOT_WEIGHT*(ocv_s - socp))/100;
            end
            S_remain = max(0, min(S_cap, S_remain));
            if S_cap > 0, socp = S_remain * 100 / S_cap; end
            s_aligned   = true;
            s_soc_state = SOC_OCV_ALIGNED;   % ★ 来源标记：OCV 对齐
            s_boot_done = true;
            S_valid     = true;
        end
    else
        % 有电流：极化还在，窗口与计时全部作废，等下次真正停下来
        s_boot_rest_ms = 0;
        s_boot_hold    = 0;
        s_boot_cnt     = 0;
        s_boot_idx     = 1;
    end
end

%% ==================== 10ms：Prot_Task ====================
vmax = 0; vmin = 1e9;
for g = 1:CELL_N
    if v_meas(g) > vmax, vmax = v_meas(g); end
    if v_meas(g) < vmin, vmin = v_meas(g); end
end

% 1) AFE 硬件故障位锁存（条件消失后按回差自动解除）
if bitand(uint8(sys_stat), uint8(4)) ~= 0, P_ov = true; end
if bitand(uint8(sys_stat), uint8(8)) ~= 0, P_uv = true; end
if bitand(uint8(sys_stat), uint8(1)) ~= 0, P_ocd = true; end
if bitand(uint8(sys_stat), uint8(2)) ~= 0, P_scd = true; end
if P_ov && vmax < (OV_MV - HYST_MV), P_ov = false; end
if P_uv && vmin > (UV_MV + HYST_MV), P_uv = false; end

% 2) 软件过流（放电为二级补充，充电是唯一保护）
if -cur >= P_dsg_lim
    P_ocdsg_ms = P_ocdsg_ms + DT_MS;
    if P_ocdsg_ms >= OC_SW_DELAY_MS
        if ~P_ocd, P_counts(F_OCDSG+1) = P_counts(F_OCDSG+1) + 1; end
        P_ocd = true; P_ocdsg_ms = 0;
    end
elseif -cur < (P_dsg_lim * OC_RECOVER)
    P_ocdsg_ms = 0;
end
if cur >= P_chg_lim
    P_occhg_ms = P_occhg_ms + DT_MS;
    if P_occhg_ms >= OC_SW_DELAY_MS
        if ~P_occhg, P_counts(F_OCCHG+1) = P_counts(F_OCCHG+1) + 1; end
        P_occhg = true; P_occhg_ms = 0;
    end
elseif cur < (P_chg_lim * OC_RECOVER)
    P_occhg_ms = 0;
end

% 3) 温度限值（用温度模块的结论：zone 0 正常 / 1 低温 / 2 极低温 / 3 高温禁充 / 4 过温 / 5 故障）
chg_ok = true; dsg_ok = true;
if T_valid
    if T_zone ~= 0, chg_ok = false; end
    if T_zone == 2 || T_zone == 4, dsg_ok = false; end
    if T_zone == 3 || T_zone == 4
        if ~P_thigh_lat
            P_thigh_lat = true;
            P_counts(F_THIGH+1) = P_counts(F_THIGH+1) + 1;
        end
        if P_fault == F_NONE, P_fault = F_THIGH; end
    else
        P_thigh_lat = false;
    end
    if T_zone == 1 || T_zone == 2
        if ~P_tlow_lat
            P_tlow_lat = true;
            P_counts(F_TLOW+1) = P_counts(F_TLOW+1) + 1;
        end
        if P_fault == F_NONE, P_fault = F_TLOW; end
    else
        P_tlow_lat = false;
    end
    P_tsens_lat = false;
else
    % 传感器故障：开机 3s 内不判（第一次采样还没完成）
    if (t*1000 - T_boot) >= TEMP_BOOT_GRACE
        chg_ok = false; dsg_ok = false;
        if ~P_tsens_lat
            P_tsens_lat = true;
            P_counts(F_TSENS+1) = P_counts(F_TSENS+1) + 1;
        end
        if P_fault == F_NONE, P_fault = F_TSENS; end
    end
end

% 4) 采样回路异常 → 闭锁充放电
if ~C_wire_ok
    if ~P_wire_lat
        P_wire_lat = true;
        P_counts(F_WIRE+1) = P_counts(F_WIRE+1) + 1;
    end
    if P_fault == F_NONE, P_fault = F_WIRE; end
    chg_ok = false; dsg_ok = false;
else
    P_wire_lat = false;
end

% 5) 汇总允许状态
if P_ov || P_occhg, chg_ok = false; end
if P_uv || P_ocd || P_scd, dsg_ok = false; end
if P_ov
    if P_fault == F_NONE
        P_fault = F_OV;
    end
end
if P_uv
    if P_fault == F_NONE
        P_fault = F_UV;
    end
end
if P_occhg
    if P_fault == F_NONE
        P_fault = F_OCCHG;
    end
end
if P_ocd
    if P_fault == F_NONE
        P_fault = F_OCDSG;
    end
end
if P_scd
    if P_fault == F_NONE
        P_fault = F_SCD;
    end
end
if P_locked, chg_ok = false; dsg_ok = false; end

% 6) 过流重试与锁定
retry_cleared = false;
if P_ocd || P_scd || P_occhg
    if P_retry_at == 0
        P_retry_at = t*1000 + OC_RETRY_MS;
        P_retry_cnt = P_retry_cnt + 1;
        if P_retry_cnt > OC_MAX_RETRY
            P_locked = true;
            P_fault = F_LOCKED;
        end
    end
    if ~P_locked && (t*1000) >= P_retry_at && abs(cur) < P_dsg_lim*0.5
        P_ocd = false; P_scd = false; P_occhg = false;
        P_retry_at = 0; P_retry_reset = t*1000; P_fault = F_NONE;
        retry_cleared = true;
    end
end
if (t*1000 - P_retry_reset) > 60000
    P_retry_cnt = 0; P_retry_reset = t*1000;
end

% 7) 串口命令（模拟 SET CHG/DSG 与 CLR）
if cmd(1) > 0, P_chg_lim = min(cmd(1), 55); end
if cmd(2) > 0, P_dsg_lim = min(cmd(2), 55); end
if cmd(3) > 0
    P_ov = false; P_uv = false; P_ocd = false; P_scd = false; P_occhg = false;
    P_locked = false; P_retry_cnt = 0; P_fault = F_NONE;
    P_counts = zeros(1,12);
    P_wire_lat = false; P_tsens_lat = false;
    P_thigh_lat = false; P_tlow_lat = false;
end

% 8) 写 SYS_STAT 清位（只在条件消失后清，才符合真芯片的锁存行为）
clr_mask = uint8(0);
if ~P_ov && ~P_uv
    clr_mask = bitor(clr_mask, uint8(12));      % 0x0C = OV|UV
end
if retry_cleared
    clr_mask = bitor(clr_mask, uint8(3));       % 0x03 = OCD|SCD
end

P_chg_ok = chg_ok; P_dsg_ok = dsg_ok;
chg_en = chg_ok;  dsg_en = dsg_ok;

%% ==================== 10ms：Bal_Task（均衡相位 / 测量窗口）====================
if B_mask == 0
    B_applied = 0; B_active = false; B_phase_ms = 0; B_inpause = false;
else
    B_phase_ms = B_phase_ms + DT_MS;
    if ~B_inpause
        B_applied = B_mask; B_active = true;
        if B_phase_ms >= BAL_ON_MS, B_phase_ms = 0; B_inpause = true; end
    else
        B_applied = 0; B_active = false;
        if B_phase_ms >= BAL_PAUSE_MS, B_phase_ms = 0; B_inpause = false; end
    end
end
bal_mask = B_applied;

%% ==================== 10ms：LED ====================
% ★ 优先级：故障 > 电量未确定 > 低电量 > 正常电量条
%   "电量未确定"排在低电量之前：既然不知道电量，就不能断言它低。
%   未确定时 led_m = 0，由上层/看板显示"跑马灯"（不冒充任何固定档位）。
if P_fault ~= F_NONE || P_locked
    led_m = 0;                                    % 故障：由上层做闪烁
elseif ~s_aligned
    led_m = 0;                                    % ★ 电量未知：不点亮固定档位
elseif socp < 10
    led_m = 31;                                   % 低电量：全亮闪烁
else
    n = floor(socp / 20);
    if n > 5, n = 5; end
    if n < 0, n = 0; end
    if n == 0, led_m = 0; else, led_m = bitshift(1, n) - 1; end
end
led_mask = led_m;

%% ==================== 250ms：单体检测 + SOC ====================
if d_cell > 0
    % ---- (a) 均衡干扰屏蔽窗口 ----
    if B_applied ~= C_app_prev
        C_untrust = bitor(uint8(B_applied), uint8(C_app_prev));
        C_untrust_until = t*1000 + BAL_SETTLE_MS;
        C_app_prev = B_applied;
    end
    if (t*1000) >= C_untrust_until
        C_untrust = uint8(B_applied);
    end

    % ---- (b) 逐节处理 ----
    n_trust = 0; sumv = 0; mn = 1e9; mx = 0; imx = 1; imn = 1;
    lowf = false; highf = false; blind = false;
    for g = 1:CELL_N
        raw = v_meas(g);
        if bitand(uint8(C_untrust), uint8(SLOTBIT(g))) ~= 0
            % 被均衡污染：沿用上次可信值（最多 30s）
            C_holdms(g) = C_holdms(g) + 250;
            if C_holdms(g) > HOLD_MAX_MS
                blind = true;
                held = raw;              % 太久没真值：退回原始读数，统计别停
            else
                held = C_hold(g);
            end
            C_mv(g) = held;
            C_trust(g) = false;          % 不可信 → 不参与 OV/UV 跳闸
            % ★ 但保持值要进统计：否则均衡一开压差就塌，均衡会来回抖
            n_trust = n_trust + 1;
            sumv = sumv + held;
            if held < mn, mn = held; imn = g; end
            if held > mx, mx = held; imx = g; end
            continue;
        end
        if raw < PLAUS_MIN
            lowf = true; C_mv(g) = raw; C_trust(g) = false; continue;
        end
        if raw > PLAUS_MAX
            highf = true; C_mv(g) = raw; C_trust(g) = false; continue;
        end
        % 3 点中值滤波
        C_hist(3,g) = C_hist(2,g); C_hist(2,g) = C_hist(1,g); C_hist(1,g) = raw;
        if C_hn(g) < 3, C_hn(g) = C_hn(g) + 1; end
        if C_hn(g) >= 3
            a1 = C_hist(1,g); b1 = C_hist(2,g); c1 = C_hist(3,g);
            if a1 > b1, tmp = a1; a1 = b1; b1 = tmp; end
            if b1 > c1, b1 = c1; end
            if a1 > b1, v = a1; else, v = b1; end
        else
            v = raw;
        end
        C_mv(g) = v; C_trust(g) = true; C_hold(g) = v; C_holdms(g) = 0;
        n_trust = n_trust + 1; sumv = sumv + v;
        if v < mn, mn = v; imn = g; end
        if v > mx, mx = v; imx = g; end
    end
    if n_trust > 0
        C_min = mn; C_max = mx; C_avg = sumv/n_trust; C_sum = sumv;
        C_delta = mx - mn; C_imax = imx; C_imin = imn;
        C_samples = C_samples + 1;
    end

    % ---- (c) 总和校验（有均衡时不校验：被压低的读数必然误报）----
    C_sumerr = 0;
    if n_trust == CELL_N && B_applied == 0 && v_pack_meas > 0
        C_sumerr = sumv - v_pack_meas;
        if abs(C_sumerr) > SUM_TOL_MV, C_sumbad = C_sumbad + 1; else, C_sumbad = 0; end
    else
        C_sumbad = 0;
    end

    % ---- (d) 逐节两级判定 ----
    for g = 1:CELL_N
        if ~C_trust(g), continue; end
        v = C_mv(g);
        if ~C_ovst(g)
            if v >= OV_MV
                C_thi(g) = C_thi(g) + 1;
                if C_thi(g) >= OV_DEB, C_ovst(g) = true; C_thi(g) = 0; end
            else
                C_thi(g) = 0;
            end
        elseif v < (OV_MV - HYST_MV)
            C_ovst(g) = false; C_thi(g) = 0;
        end
        if ~C_uvst(g)
            if v <= UV_MV
                C_tlo(g) = C_tlo(g) + 1;
                if C_tlo(g) >= UV_DEB, C_uvst(g) = true; C_tlo(g) = 0; end
            else
                C_tlo(g) = 0;
            end
        elseif v > (UV_MV + HYST_MV)
            C_uvst(g) = false; C_tlo(g) = 0;
        end
        if v >= OV_WARN_MV, C_whi(g) = C_whi(g) + 1; else, C_whi(g) = 0; end
        if v <= UV_WARN_MV, C_wlo(g) = C_wlo(g) + 1; else, C_wlo(g) = 0; end
    end

    % ---- (e) 压差（不均衡）判定 ----
    if n_trust == CELL_N && C_delta > DELTA_WARN_MV
        C_unbal_ms = C_unbal_ms + 250;
        if C_unbal_ms >= DELTA_HOLD_MS, C_unbal = true; end
    elseif n_trust == CELL_N && C_delta < DELTA_WARN_MV
        C_unbal_ms = 0; C_unbal = false;
    end

    % ---- (f) 采样回路状态 ----
    if lowf,        C_err = 2; C_wire_ok = false;
    elseif highf,   C_err = 3; C_wire_ok = false;
    elseif C_sumbad >= SUM_BAD_CNT, C_err = 1; C_wire_ok = false;
    elseif blind,   C_err = 4; C_wire_ok = false;
    else,           C_err = 0; C_wire_ok = true;
    end

    % ---- (g) 库仑积分已移到 10ms 区（由 CC_READY 触发，与 bms_app.c 一致）----
    % 早期版本把积分放在这里（用固件自己的 250ms 计数器触发），
    % 会与 AFE 的 250ms 转换窗口相位错开，在电流阶跃点读到陈旧值。

    % ---- (h) 满充 / 放空 / 静置判定 ----
    charging = (cur > 0.02);
    if charging && C_max >= FULL_DETECT_MV && cur < FULL_DETECT_A
        C_full_hold = C_full_hold + 250;
        if C_full_hold >= FULL_HOLD_MS
            if S_seen_empty && S_q_empty > LEARN_MIN_AH*1e9
                cand = S_q_empty/1e9; old = S_cap/1e9;
                newc = old*0.7 + cand*0.3;
                newc = max(0.3*CAP_AH, min(1.5*CAP_AH, newc));
                S_learned = cand; S_cap = newc*1e9;
            end
            S_remain = S_cap; S_q_full = 0; S_q_empty = 0;
            S_seen_full = true; S_full_flag = true; S_valid = true;
            S_charge_count = S_charge_count + 1;
            C_full_hold = 0;
        end
    else
        C_full_hold = 0;
    end
    if ~charging && cur < -0.05 && C_min <= EMPTY_DETECT_MV
        C_empty_hold = C_empty_hold + 250;
        if C_empty_hold >= EMPTY_HOLD_MS
            if S_seen_full && S_q_full > LEARN_MIN_AH*1e9
                cand = S_q_full/1e9; old = S_cap/1e9;
                newc = old*0.7 + cand*0.3;
                newc = max(0.3*CAP_AH, min(1.5*CAP_AH, newc));
                S_learned = cand; S_cap = newc*1e9;
            end
            S_remain = 0; S_q_empty = 0; S_q_full = 0;
            S_seen_empty = true; S_full_flag = false; S_valid = true;
            C_empty_hold = 0;
        end
    else
        C_empty_hold = 0;
    end
    if abs(cur) < OCV_REST_A
        C_rest_ms = C_rest_ms + 250;
        if C_rest_ms >= OCV_REST_MS
            % 单体平均电压 → OCV → SOC（与固件 ocv_to_soc 同一张表）
            mv = C_avg; ocv_soc = 0;
            if mv >= OCV_MV(1)
                ocv_soc = 100;
            else
                for i = 2:numel(OCV_MV)
                    if mv >= OCV_MV(i)
                        vh = OCV_MV(i-1); vl = OCV_MV(i);
                        sh = OCV_SOC(i-1); sl = OCV_SOC(i);
                        ocv_soc = sl + (mv - vl)/(vh - vl)*(sh - sl);
                        break;
                    end
                end
            end
            if ~S_valid
                S_remain = S_cap * ocv_soc/100; S_valid = true;
            else
                S_remain = S_cap * (socp + OCV_W*(ocv_soc - socp))/100;
            end
            S_remain = max(0, min(S_cap, S_remain));
            if S_cap > 0, socp = S_remain * 100 / S_cap; end
            C_rest_ms = 0;
        end
    else
        C_rest_ms = 0;
    end
end

%% ==================== 1000ms：Temp_Update ====================
if d_slow > 0
    T_samples = T_samples + 1;
    if T_boot == 0, T_boot = t*1000; end
    v_ts1 = ts1_adc * TS_LSB_UV * 1e-6;
    if v_ts1 <= 0.02
        st = 2; r_ntc = 0;
    elseif v_ts1 >= (VREF - 0.02)
        st = 1; r_ntc = 1e6;
    else
        r_ntc = PULLUP * v_ts1 / (VREF - v_ts1);
        if r_ntc >= 200000
            st = 1;
        elseif r_ntc <= 300
            st = 2;
        else
            st = 0;
        end
    end
    if st ~= 0
        T_sens = st; T_valid = false; T_zone = 5; T_rejects = T_rejects + 1;
    else
        tt = 1/(1/298.15 + log(r_ntc/NTC_R0)/NTC_B) - 273.15;
        tt = max(VALID_MIN, min(VALID_MAX, tt));
        if T_valid && abs(tt - T_last) > TEMP_RATE_MAX
            % 跳变剔除（本板 TS1 兼作 SHIP 唤醒键，按键会瞬间抬高）
            T_rej = T_rej + 1; T_rejects = T_rejects + 1; T_keymask = true;
            if T_rej >= TEMP_REJ_MAX
                T_sens = 4; T_valid = false; T_zone = 5;
            end
        else
            T_rej = 0; T_keymask = false; T_raw = tt; T_last = tt;
            T_idx = T_idx + 1;
            if T_idx > TEMP_FILT_N
                T_idx = 1;
            end
            if T_idx == 1
                T_buf(1) = tt;
            elseif T_idx == 2
                T_buf(2) = tt;
            elseif T_idx == 3
                T_buf(3) = tt;
            else
                T_buf(4) = tt;
            end
            if T_cnt < TEMP_FILT_N
                T_cnt = T_cnt + 1;
            end
            % 用固定次数的循环求和：不用 sum(T_buf(1:T_cnt))，
            % 那是「变尺寸切片」，会让 Simulink 无法推断输出尺寸
            tsum = 0;
            for z = 1:TEMP_FILT_N
                if z <= T_cnt
                    tsum = tsum + T_buf(z);
                end
            end
            T_cellc = tsum / T_cnt;
            T_valid = true; T_sens = 0;
            if T_zone == 0, h = 0; else, h = 2; end
            if T_cellc < (CRIT_LOW - h)
                T_zone = 2;
            elseif T_cellc < (CHG_MIN - h)
                T_zone = 1;
            elseif T_cellc >= (DSG_MAX + h)
                T_zone = 4;
            elseif T_cellc >= (CHG_MAX + h)
                T_zone = 3;
            else
                T_zone = 0;
            end
        end
    end
end

%% ==================== 5000ms：Bal_Update ====================
if d_bal > 0
    if C_samples > 0 && C_max >= (OV_MV - BAL_OV_GUARD)
        B_mask = 0;                                  % 逼近 OV 阈值：停手
    elseif (P_fault ~= F_NONE) || P_locked || T_cellc < BAL_TMIN || T_cellc > BAL_TMAX || ...
           C_min < BAL_MIN_MV || C_max < BAL_START_MV || C_delta < BAL_DELTA_MV
        B_mask = 0;
    elseif cur < -BAL_IMAX
        B_mask = 0;
    else
        % 用固定长度数组：used(g)=0 未处理 / 1 已考虑但被跳过 / 2 已选中
        used = zeros(1, CELL_N);
        m = 0;
        for a = 1:CELL_N
            % 每轮挑「还没处理过、且电压最高、且超过门槛」的那一节
            best = 0; bv = 0;
            for g = 1:CELL_N
                if used(g) == 0 && C_mv(g) > bv && C_mv(g) > (C_min + BAL_DELTA_MV)
                    bv = C_mv(g); best = g;
                end
            end
            if best == 0
                break;
            end
            used(best) = 1;
            % 相邻电芯不同时均衡（AFE 相邻通道共用采样电阻与泄放通路）
            blocked = 0;
            if best > 1
                if used(best-1) == 2
                    blocked = 1;
                end
            end
            if best < CELL_N
                if used(best+1) == 2
                    blocked = 1;
                end
            end
            if blocked == 0
                used(best) = 2;
                m = bitor(m, SLOTBIT(best));
            end
        end
        B_mask = m;
    end
    B_delta = C_delta; B_target = C_min;
end

%% ==================== 输出 ====================
% ★ 为什么把所有输出打包成一个 1×28 的向量：
%   Simulink 的 MATLAB Function 块对本块这种规模（400+ 行、几十个持久状态、
%   12 个独立输出）做「输出尺寸/类型推断」会失败，报
%   「Simulink 无法确定模块的输出大小和/或类型」。
%   改成单一向量输出后推断是确定的，外部用 Demux 拆开即可（接线见 build_bms_model.m）。
%
%   打包约定（下标 → 含义）：
%     1 chg_en   2 dsg_en   3 bal_mask  4 cc_read  5 clr_mask
%     6 soc%     7 remainAh 8 capAh     9 fault   10 led_mask  11 temp_c
%     12..26  dbg = [max, min, avg, delta, sumErr, ntrust, balApplied, tempZone,
%                    tempSens, wire_ok, unbalance, chgLim, dsgLim, cellsErr, samples]
%     27 soc_aligned = SOC 是否已对齐真实值（1=可信；0=电量未知，禁止显示数字）
%     28 soc_state   = 可信度来源（0=UNKNOWN / 1=EEPROM 恢复 / 2=OCV 对齐）
%   ★ y(6) 在未对齐时输出哨兵值 BMS_SOC_UNKNOWN_X10，不是内部运算数字。
if socp > 100, socp = 100; end
if socp < 0,   socp = 0;   end
ntrust = 0;
for g = 1:CELL_N
    if C_trust(g), ntrust = ntrust + 1; end
end
y = zeros(1, 28);
y(1)  = double(chg_ok);
y(2)  = double(dsg_ok);
y(3)  = B_applied;
y(4)  = double(cc_read);
y(5)  = double(clr_mask);
% ★ 第 6 路：只有已对齐才输出真实百分比；否则输出哨兵值
if s_aligned
    y(6) = socp;
else
    y(6) = BMS_SOC_UNKNOWN_X10;
end
y(7)  = S_remain / 1e9;
y(8)  = S_cap / 1e9;
y(9)  = P_fault;
y(10) = led_m;
y(11) = T_cellc;
y(12) = C_max;
y(13) = C_min;
y(14) = C_avg;
y(15) = C_delta;
y(16) = C_sumerr;
y(17) = ntrust;
y(18) = B_applied;
y(19) = T_zone;
y(20) = T_sens;
y(21) = double(C_wire_ok);
y(22) = double(C_unbal);
y(23) = P_chg_lim;
y(24) = P_dsg_lim;
y(25) = C_err;
y(26) = C_samples;
y(27) = double(s_aligned);      % ★ 上电 SOC 对齐状态
y(28) = s_soc_state;            % ★ SOC 可信度来源分级

end
