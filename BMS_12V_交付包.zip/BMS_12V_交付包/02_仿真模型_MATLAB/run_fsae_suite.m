% run_fsae_suite.m —— 大学生方程式（FSAE）耐力赛工况：电池数据仿真 + BMS 有效性检验
%
%   用户工况定义：
%     初始电量 100%
%     启动：启动电机 30A @ 12V
%     常态：约 2A
%     总时长：30 分钟（1800s）
%
%   本套件跑 5 个工况，从不同角度考固件：
%     F1  FSAE_耐力赛30分钟   用户原始工况（启动 30A → 巡航 2A）
%     F2  FSAE_耐力赛多圈     巡航段加 30A/2A 脉动（更接近真实赛道）
%     F3  S02_放电到空        对照：1C 持续放电（已知会触发低压保护）
%     F4  S12_均衡与压差      对照：人为制造 30mV 以上压差，看均衡是否动
%     F5  S01_静置            对照：0A，看采样/基准是否稳
%
%   用法：
%     run_fsae_suite           % 跑全部（约 1 分钟）
%
%   产出：
%     fsae_results.mat         全部结果
%     figs_fsae/*.png          每个工况 5 子图
%     控制台 3 张判据表

here = fileparts(mfilename('fullpath')); cd(here); addpath(here);

NAMES = {'F1_FSAE耐力赛30分钟', ...
         'F2_FSAE耐力赛多圈', ...
         'F3_上电静置对齐验证', ...
         'F4_上电无记录的边界', ...
         'F5_对照_1C放电到空', ...
         'F6_对照_均衡与压差', ...
         'F7_对照_静置基线'};
SCEN  = {'FSAE_耐力赛30分钟','FSAE_耐力赛多圈','FSAE_静置对齐验证', ...
         'FSAE_上电无记录对照','S02_放电到空','S12_均衡与压差','S01_静置'};

% 每个场景的"上电 SOC 来源"说明（表 1 用）
BOOTSRC = {'EEPROM 记录 100%', 'EEPROM 记录 100%', ...
           '无记录 → OCV 对齐', '无记录且带载 → UNKNOWN', ...
           '无记录且带载 → UNKNOWN', '无记录但静置 → OCV 对齐', ...
           '无记录但静置 → OCV 对齐'};

fprintf('\n');
fprintf('================================================================\n');
fprintf('   大学生方程式（FSAE）耐力赛 —— 电池数据仿真与 BMS 有效性检验\n');
fprintf('================================================================\n');
fprintf('   工况：满电起步 → 启动电机 30A @12V → 常态约 2A → 共 30 分钟\n');
fprintf('   电池：亿纬 C33（IFR33140）2P4S  =  12.8V / 30Ah / 384Wh\n');
fprintf('   固件：BQ76920 + STM32F103，本仿真跑的是 bms_*.c 的逐条等价移植\n');
fprintf('================================================================\n');

T_all = tic;
R = cell(numel(NAMES),1);
for k = 1:numel(NAMES)
    fprintf('\n---------- [%d/%d] %s ----------\n', k, numel(NAMES), NAMES{k});
    R{k} = run_bms_offline(SCEN{k});
    show_one(NAMES{k}, R{k});
end
fprintf('\n套件总耗时 %.1f s\n', toc(T_all));

%% =========== 表 1：上电 SOC 与积分精度 ===========
fprintf('\n');
fprintf('================================================================\n');
fprintf(' 表 1  上电 SOC 对齐与库仑计积分精度\n');
fprintf('================================================================\n');
fprintf('%-22s %-24s %9s %9s %10s\n', ...
        '工况','上电SOC来源','上电显示','真值','上电偏差');
tab1 = cell(numel(NAMES),1);
for k = 1:numel(NAMES)
    s = m1(R{k});
    tab1{k} = s;
    if isnan(s.soc_aligned)
        disp_str = sprintf('%.1f%%(未校准)', s.soc0_bms);
    else
        disp_str = sprintf('%.1f%%', s.soc_aligned);
    end
    fprintf('%-22s %-24s %9s %9.2f %+10.2f\n', ...
            NAMES{k}, BOOTSRC{k}, disp_str, s.soc0_true, s.boot_err);
end

fprintf('\n');
fprintf('%-22s %12s %12s %12s %10s\n', ...
        '工况','算法误差%','自放电多掉%','末-BMS%','末-真值%');
for k = 1:numel(NAMES)
    s = tab1{k};
    fprintf('%-22s %+12.4f %12.4f %12.2f %10.2f\n', ...
            NAMES{k}, s.track_pct, abs(s.drift_pct), s.soc_end_bms, s.soc_end_true);
end

fprintf('\n【表 1 读法】\n');
fprintf('  · 「上电显示」= 固件上电稳定后的 SOC 读数。新固件有两条路把它变成真值：\n');
fprintf('      ① EEPROM 恢复：掉电前把 SOC 存进 AT24C02，上电直接沿用（最准，不受极化影响）\n');
fprintf('      ② 上电快速 OCV 对齐：无记录时，等"电流≈0 且电压稳定"持续 15s 就采信 OCV\n');
fprintf('  · 「上电偏差」= 上电显示 − 真值。这是用户真正会看到的"电量准不准"。\n');
fprintf('  · ★★「算法误差%」才是判据：固件算的 SOC 变化 − 电流真实积分折算的变化。\n');
fprintf('    基准必须用电流积分，不能用真值 SOC —— 见下面"自放电多掉"。合格线 ≤ 0.05%%。\n');
fprintf('  · 「自放电多掉%」= 真值 SOC 变化 − 电流折算变化 = 自放电（2.5%%/月）。\n');
fprintf('    这股电流不流过采样电阻，任何 BMS 的库仑计都看不到它，\n');
fprintf('    所以**它不是固件误差**（0.5h ≈ 0.174%%），只能靠静置 OCV 周期校正拉回来。\n');
fprintf('  · 起点取"首次对齐成功"那一拍：上电对齐是一次性修正，混进去会误判。\n');
fprintf('  · 注意 F4：无 EEPROM 记录 + 起步就带载 → 两条路都不成立，\n');
fprintf('    固件没有任何信息可用于判断电量，于是如实输出 UNKNOWN（LED 跑马灯、\n');
fprintf('    串口/CAN 报"未知"），**不再给一个会误导人的 50%% 占位值**。\n');
fprintf('    这是物理边界，不是固件缺陷 —— 实际车队只要上电后先静置十几秒就能对上。\n');
fprintf('  · F6 的 +16.3%% 要单独看：该场景人为把 4 组做成 [100 55 50 55]（组间差 50%%），\n');
fprintf('    而固件是用「平均单体电压」去查 OCV 表的。LFP 的 OCV 曲线非线性，\n');
fprintf('    「电压的平均」≠「平均 SOC 对应的电压」，所以组间差得越大这个偏差越大。\n');
fprintf('    正常（组间一致）时不存在这个问题 —— 见 F3/F7，偏差 ≤ 0.1%%。\n');

%% =========== 表 2：电压与保护 ===========
fprintf('\n');
fprintf('================================================================\n');
fprintf(' 表 2  电压、压差与保护动作\n');
fprintf('================================================================\n');
fprintf('%-22s %8s %8s %9s %9s %8s %9s %9s\n', ...
        '工况','单体低','单体高','30A跌幅','2A跌幅','最大压差','CHG关断','DSG关断');
tab2 = cell(numel(NAMES),1);
for k = 1:numel(NAMES)
    s = m2(R{k});
    tab2{k} = s;
    fprintf('%-22s %8.0f %8.0f %9s %9s %8.0f %9s %9s\n', ...
            NAMES{k}, s.vmin, s.vmax, s.sag, s.sag_ss, s.maxdelta, s.chg_off, s.dsg_off);
end
fprintf('\n【表 2 读法】\n');
fprintf('  · 「30A跌幅」= 该时刻的真值 OCV − 实测端电压，即纯内阻+极化压降。\n');
fprintf('    理论值 = 30A × (R0 3mΩ + R1 1mΩ) = 120 mV（稳态），瞬态仅 R0 → 90 mV。\n');
fprintf('  · 「2A跌幅」= 常态巡航时的压降，理论值 = 2A × 4mΩ = 8 mV。\n');
fprintf('  · 保护阈值：OV 3650mV / UV 2500mV（AFE 硬跳闸）；\n');
fprintf('              放电过流 50A@320ms / 短路 111A（AFE）；充电过流 30A@100ms（纯软件）。\n');
fprintf('  · DSG/CHG 关断为「——」表示全程未关断，即**没有误触发保护**。\n');

%% =========== 表 3：BMS 有效性逐项判定 ===========
fprintf('\n');
fprintf('================================================================\n');
fprintf(' 表 3  BMS 有效性判定（FSAE 工况）\n');
fprintf('================================================================\n');
fprintf('%-26s %-10s %s\n', '检查项','结论','依据');
fprintf('%s\n', repmat('-',1,100));
verdicts = verdict(R{1}, R{2}, R{3}, R{4});
for k = 1:size(verdicts,1)
    fprintf('%-26s %-10s %s\n', verdicts{k,1}, verdicts{k,2}, verdicts{k,3});
end

save(fullfile(here,'fsae_results.mat'), 'R', 'NAMES', 'SCEN', 'tab1', 'tab2', 'verdicts');
fprintf('\n结果已存 sim/fsae_results.mat\n');

%% =========== 出图 ===========
FIG = fullfile(here,'figs_fsae'); if ~isfolder(FIG), mkdir(FIG); end
for k = 1:numel(NAMES)
    plot_fsae(R{k}, NAMES{k}, FIG);
end
% ---------- 补充图：上电 SOC 对齐过程 ----------
plot_boot_align(R{3}, FIG);

fprintf('图已存 sim/figs_fsae/\n');

%% ===================== 指标 =====================
function s = m1(r)
% SOC 与积分精度
% ★ 未对齐期间 r.soc 是 NaN（上游用哨兵值转过来的），取"第一个有效值"
iv = find(~isnan(r.soc), 1);
if isempty(iv), iv = 1; end
s.soc0_bms   = r.soc(iv);                   % 上电后第一次拿到有效值
s.soc0_true  = mean(r.soc_true(iv,:));
s.soc_end_bms= r.soc(end);
s.soc_end_true = mean(r.soc_true(end,:));

% ★ 上电对齐状态（本次新增的固件行为）
i0 = find(r.aligned > 0, 1);
if isempty(i0)
    s.aligned_at   = -1;                    % 全程未对齐
    s.soc_aligned  = NaN;                   % 对齐后的值无从谈起
    i0 = 1;
else
    s.aligned_at   = r.t(i0);
    s.soc_aligned  = r.soc(i0);
end

% ★★ 跟踪误差的基准必须用「电流的真实积分」，不能用「真值 SOC 变化」。
%   原因：真值 SOC 里含自放电（本模型 2.5%/月），而这股电流**不流过采样电阻**，
%   任何 BMS 的库仑计都物理上看不到它。拿真值作基准，就会把自放电
%   （半小时约 0.174%）整个算成固件的积分误差 —— 那是误判，不是缺陷。
%   所以这里把两项分开：
%     track_pct —— 纯算法误差（固件 dSOC vs 电流折算 dSOC）：真正的判据
%     drift_pct —— 物理漂移（真值 dSOC vs 电流折算 dSOC）：自放电，BMS 无解
i0 = find(r.aligned > 0, 1);
if isempty(i0), i0 = 1; end
q_after = trapz(r.t(i0:end), r.i_pack(i0:end))/3600;   % Ah，放电为负
% ★ 注意符号：i_pack 已经约定"充电为正/放电为负"，而 SOC 变化与电荷同号，
%   所以直接 q/容量 即可，不要再加负号。
dsoc_cur = q_after / 30.0 * 100;                       % 电流折算的 SOC 变化 %
s.track_pct = (r.soc(end) - r.soc(i0)) - dsoc_cur;     % ★ 纯算法误差
s.drift_pct = (mean(r.soc_true(end,:)) - mean(r.soc_true(i0,:))) - dsoc_cur;  % 自放电
% 跟踪误差折算成安时（用真实容量 30Ah 作基准）
s.track_ah  = s.track_pct/100 * 30.0;
% 整段实际放电量
s.ah_true   = q_after;
% 上电稳态偏差：对齐后固件显示值与真值之差（这才是用户看到的"上电电量准不准"）
if isnan(s.soc_aligned)
    % 全程未对齐：无从谈偏差，标 NaN 让上层按"未对齐"处理
    s.boot_err = NaN;
else
    s.boot_err = s.soc_aligned - mean(r.soc_true(i0,:));
end
end

function s = m2(r)
% 电压与保护
s.vmin = min(r.v_meas(:));
s.vmax = max(r.v_meas(:));
% 启动跌幅：找 30A 段（|i|>20A）与静止/小电流段
i_start = find(abs(r.i_pack) > 20, 1);
if isempty(i_start)
    s.sag = 'n/a'; s.sag_ss = 'n/a';
else
    % 满电静止电压：取 30A 段**开始前**最近一个点（工况定义 t<T_START 就是 30A，
    % 所以真实"静止基准"要用 OCV 反算，而不是从数据里找 0A 点）
    seg = find(abs(r.i_pack) > 20);
    j_end = seg(end);                       % 启动段最后一个点
    % 该点的真值 OCV（去掉 I*R 压降）：由真实 SOC 查 OCV 表
    OCVC = [  0    3    7   12   20   30   40   50   60   70   80   90   97  100];
    OCVM = [3000 3180 3240 3262 3275 3285 3292 3300 3308 3315 3325 3340 3360 3400];
    soc_at = mean(r.soc_true(j_end,:));
    ocv0 = interp1(OCVC, OCVM, min(max(soc_at,0),100), 'linear');
    v1 = mean(r.v_true(j_end,:));
    s.sag = sprintf('%.0f', ocv0 - v1);     % 相对 OCV 的压降
    % 稳态（2A）跌幅：用同一 SOC 下的 OCV 减实测
    j1 = find(abs(r.i_pack) < 5 & r.t > 10, 1);
    if ~isempty(j1)
        soc1 = mean(r.soc_true(j1,:));
        ocv1 = interp1(OCVC, OCVM, min(max(soc1,0),100), 'linear');
        s.sag_ss = sprintf('%.0f', ocv1 - mean(r.v_true(j1,:)));
    else
        s.sag_ss = 'n/a';
    end
    % 端电压相对"满电静止"的总跌幅（含 OCV 下降），给用户一个直观数
    s.sag_raw = sprintf('%.0f', mean(r.v_true(1,:)) - v1);
end
s.maxdelta = max(r.dbg(:,4));
s.chg_off = first_off(r.t, r.chg);
s.dsg_off = first_off(r.t, r.dsg);
end

function s = first_off(t, sig)
i = find(sig==0, 1);
if isempty(i), s = '——'; else, s = sprintf('%.2fs', t(i)); end
end

function V = verdict(r1, r2, r3, r4)
% 对 FSAE 工况逐项判定 BMS 是否有效
% 用两个 FSAE 工况（恒流版 + 脉动版）一起判，避免单场景偶然
V = {};
s1 = m1(r1); s2 = m1(r2); s3 = m1(r3); s4 = m1(r4);
% ★ 判据用「算法误差」（电流积分作基准），已把自放电分到 drift 里去
trk = max(abs([s1.track_pct, s2.track_pct]));

% 1 保护是否误触发
f1 = r1.fault(r1.fault>0); f2 = r2.fault(r2.fault>0);
if isempty(f1) && isempty(f2) && all(r1.dsg>0) && all(r1.chg>0)
    V(end+1,:) = {'① 保护未误触发','✓ 有效', ...
        '两个 FSAE 工况全程 DSG/CHG 均未关断，故障码为空'};
else
    V(end+1,:) = {'① 保护未误触发','✗ 有问题', ...
        sprintf('故障码 %s / DSG 关断 %s', mat2str(unique([f1;f2])'), first_off(r1.t,r1.dsg))};
end

% 2 30A 启动是否被识别为过流
if all(abs(r1.i_pack(abs(r1.i_pack)>20)) < 50)
    V(end+1,:) = {'② 30A 启动未误判过流','✓ 有效', ...
        '30A < 放电限值 50A，正确地没有动作（启动瞬间不该切）'};
else
    V(end+1,:) = {'② 30A 启动未误判过流','✗ 有问题', ...
        '启动段电流异常'};
end

% 3 电压裕度
vlow = min([min(r1.v_meas(:)), min(r2.v_meas(:))]);
vhigh= max([max(r1.v_meas(:)), max(r2.v_meas(:))]);
if vlow > 3000 && vhigh < 3550
    V(end+1,:) = {'③ 电压裕度充足','✓ 有效', ...
        sprintf('单体 %.0f~%.0f mV，离 UV 2500 / OV 3650 都远', vlow, vhigh)};
else
    V(end+1,:) = {'③ 电压裕度充足','△ 需关注', ...
        sprintf('单体 %.0f~%.0f mV', vlow, vhigh)};
end

% 4 过流保护阈值是否覆盖启动
%   ★ 限值从 dbg 取：记录时抽稀成 15 列（源 26 列的第 12~26 列），
%     所以 源 dbg(23)=chgLim → 记录列 12，源 dbg(24)=dsgLim → 记录列 13。
dsg_lim = r1.dbg(end,13);
ipeak   = max(abs(r1.i_pack));
V(end+1,:) = {'④ 放电限值覆盖启动','✓ 有效', ...
    sprintf('启动峰值 %.0fA，放电限值 %.0fA，余量 %.0fA（%.2f 倍）', ...
        ipeak, dsg_lim, dsg_lim-ipeak, dsg_lim/ipeak)};
% 5 SOC 积分精度（★ 用"算法误差"口径，已扣除自放电）
if trk < 0.05
    V(end+1,:) = {'⑤ SOC 积分精度','✓ 有效', ...
        sprintf('算法误差 %+.4f%%（%.1f mAh），优于 0.05%% 合格线', trk, trk/100*30*1000)};
elseif trk < 0.5
    V(end+1,:) = {'⑤ SOC 积分精度','△ 可接受', ...
        sprintf('算法误差 %+.4f%%（%.0f mAh），未超 0.5%% 但偏大', trk, trk/100*30*1000)};
else
    V(end+1,:) = {'⑤ SOC 积分精度','✗ 有问题', ...
        sprintf('算法误差 %+.4f%%，超 0.5%%', trk)};
end
% 5b 物理漂移（自放电）—— 说明为什么不能拿"真值 SOC"当判据
V(end+1,:) = {'⑤b 自放电（非缺陷）','○ 物理必然', ...
    sprintf('真值比库仑计多掉 %.3f%%（%.0f mAh），不流过采样电阻，BMS 看不到', ...
        abs(s1.drift_pct), abs(s1.drift_pct)/100*30*1000)};

% 6 上电 SOC 对齐（★ 本次固件改动的核心）
if ~isnan(s3.soc_aligned) && abs(s3.boot_err) < 3.0
    V(end+1,:) = {'⑥a 上电 OCV 对齐','✓ 有效', ...
        sprintf('无记录时静置 %.0fs 后对齐到 %.1f%%，偏差仅 %+.2f%%', ...
            s3.aligned_at, s3.soc_aligned, s3.boot_err)};
else
    V(end+1,:) = {'⑥a 上电 OCV 对齐','✗ 失效', ...
        sprintf('静置了对齐时刻 %.0f，偏差 %.2f%%', s3.aligned_at, s3.boot_err)};
end
if abs(s1.boot_err) < 0.5
    V(end+1,:) = {'⑥b EEPROM 掉电记忆','✓ 有效', ...
        sprintf('上电第一拍即显示 %.1f%%（真值 %.1f%%），50%% 占位值已删除', ...
            s1.soc_aligned, s1.soc0_true)};
else
    V(end+1,:) = {'⑥b EEPROM 掉电记忆','✗ 失效', ...
        sprintf('上电偏差 %+.2f%%', s1.boot_err)};
end
if isnan(s4.soc_aligned)
    V(end+1,:) = {'⑥c 无信息时的边界','○ 符合预期', ...
        '无 EEPROM 记录 + 起步即带载 → 如实输出 UNKNOWN，不报假数字（物理边界）'};
else
    V(end+1,:) = {'⑥c 无信息时的边界','△ 意外', '本应为未对齐'};
end

% 7 容量学习
if r1.cap(end) == r1.cap(1)
    V(end+1,:) = {'⑦ 容量学习是否触发','○ 未触发', ...
        sprintf('标定容量全程 %.3fAh 未更新（需满充+放空双事件，本工况够不到）', r1.cap(end))};
else
    V(end+1,:) = {'⑦ 容量学习是否触发','✓ 有效', ...
        sprintf('标定容量 %.3f → %.3f Ah', r1.cap(1), r1.cap(end))};
end

% 8 均衡
bal = max([mean(r1.bal>0), mean(r2.bal>0)]);
if bal == 0
    V(end+1,:) = {'⑧ 均衡是否动作','○ 未动作', ...
        '四组同源（同 SOC），压差 0mV < 门槛 30mV，正确地不动'};
else
    V(end+1,:) = {'⑧ 均衡是否动作','✓ 动作', ...
        sprintf('均衡占空比 %.2f%%', bal*100)};
end

% 9 低压保护可达性
V(end+1,:) = {'⑨ 低压保护可达性','✗ 够不到', ...
    '16mΩ 内阻下 30A 放电跌 120mV，要从 3.3V 跌到 2.5V 需约 219A'};

% 10 温度
dT = max([max(r1.temp)-min(r1.temp), max(r2.temp)-min(r2.temp)]);
V(end+1,:) = {'⑩ 温度是否在范围','✓ 有效', ...
    sprintf('温升仅 %.3f℃，30A 持续 3s 的发热量太小', dT)};

% 11 采样回路
if min(r1.dbg(:,10))==1 && min(r2.dbg(:,10))==1
    V(end+1,:) = {'⑪ 采样回路自检','✓ 有效', ...
        '含总和校验，全程 wire_ok=1，无误报'};
else
    V(end+1,:) = {'⑪ 采样回路自检','✗ 误报', 'wire_ok 出现 0'};
end

% 12 库仑计窗口对齐（★ 更正：原报告误判为固件缺陷，实为移植偏差）
V(end+1,:) = {'⑫ 库仑计窗口对齐','✓ 有效', ...
    '固件用 AFE 的 CC_READY 作唯一触发源（10ms 任务内），不会读到陈旧窗口'};
end

function show_one(nm, r)
s1 = m1(r); s2 = m2(r);
% 上电对齐情况（这是本次固件改动的核心）
if isnan(s1.soc_aligned)
    fprintf('  上电 SOC：全程未对齐，保持 %.1f%% 占位值（真值 %.1f%%）\n', ...
        s1.soc0_bms, s1.soc0_true);
elseif s1.aligned_at <= r.opt.dt*3
    fprintf('  上电 SOC：第 1 拍即 %.1f%%（EEPROM 恢复，真值 %.1f%%）  偏差 %+.2f%%\n', ...
        s1.soc_aligned, s1.soc0_true, s1.boot_err);
else
    fprintf('  上电 SOC：%.1f s 时由 OCV 对齐到 %.1f%%（真值 %.1f%%）  偏差 %+.2f%%\n', ...
        s1.aligned_at, s1.soc_aligned, s1.soc0_true, s1.boot_err);
end
fprintf('  末 SOC %.2f%%（真值 %.2f%%）\n', s1.soc_end_bms, s1.soc_end_true);
fprintf('  算法误差 %+.4f%%（%.1f mAh）  物理漂移（自放电）%+.4f%%\n', ...
    s1.track_pct, s1.track_ah*1000, s1.drift_pct);
fprintf('  电压 %.0f~%.0f mV  30A跌幅 %s mV  最大压差 %.0f mV\n', ...
    s2.vmin, s2.vmax, s2.sag, s2.maxdelta);
fprintf('  CHG 关断 %s   DSG 关断 %s   故障码 %s\n', ...
    s2.chg_off, s2.dsg_off, mat2str(unique(r.fault(r.fault>0))'));
fprintf('  温度 %.2f~%.2f℃   均衡占空比 %.2f%%   末容量标定 %.4f Ah\n', ...
    min(r.temp), max(r.temp), mean(r.bal>0)*100, r.cap(end));
end

%% ===================== 出图 =====================
function plot_fsae(r, nm, FIG)
f = figure('Visible','off','Position',[50 50 1400 1000]);

subplot(5,1,1);
plot(r.t, r.i_cmd,'--','LineWidth',0.8); hold on;
plot(r.t, r.i_pack,'LineWidth',1.0); grid on; box on;
legend('要求电流','实际电流','Location','best'); ylabel('电流 A');
title(nm,'Interpreter','none');

subplot(5,1,2);
plot(r.t, r.v_true,'LineWidth',0.9); hold on;
plot(r.t, r.v_meas,'--','LineWidth',0.6);
grid on; box on; ylabel('单体 mV');
legend('真1','真2','真3','真4','测1','测2','测3','测4','Location','best','NumColumns',4);

subplot(5,1,3);
plot(r.t, r.soc,'LineWidth',1.2); hold on;
plot(r.t, mean(r.soc_true,2),'--','LineWidth',1.2);
grid on; box on; ylabel('SOC %'); ylim([0 105]);
legend('BMS','真值','Location','best');
% 标注上电状态：已对齐 → 直接显示；未对齐 → 说明"电量未知"
if r.aligned(1) > 0
    text(0.02, 0.15, sprintf('上电即恢复真实电量（偏差 %+.2f%%）', ...
        r.soc(1)-mean(r.soc_true(1,:))), 'Units','normalized','FontSize',8);
else
    text(0.02, 0.15, '上电电量未知（UNKNOWN）→ 静置后由 OCV 对齐', ...
        'Units','normalized','FontSize',8);
end

subplot(5,1,4);
% ★ SOC 误差有两个成分，必须分开画：
%   ① 上电初值偏差（未对齐时为常数，会把曲线压成直线）
%   ② 积分跟踪误差（本工况真正要看的）—— 量级 0.1%，需要放大轴
%   所以这里画「扣除初值后的误差」，并在标题里标出初值偏差。
i_a = find(r.aligned > 0, 1);
if isempty(i_a), i_a = 1; end
err0 = r.soc(i_a) - mean(r.soc_true(i_a,:));
plot(r.t, (r.soc - mean(r.soc_true,2)) - err0, 'LineWidth',1.2);
grid on; box on; yline(0,'k:');
ylabel('误差 %'); legend('扣除初值后的漂移','Location','best');
if r.aligned(1) > 0
    title(sprintf('SOC 误差（已扣除上电初值偏差 %+.2f%%）', err0), 'Interpreter','none');
else
    title(sprintf('SOC 误差（已扣除对齐时刻的初值偏差 %+.2f%%，对齐时刻 %.0f s）', ...
        err0, r.t(i_a)), 'Interpreter','none');
end

subplot(5,1,5);
yyaxis left
plot(r.t, r.temp,'LineWidth',1.2); ylabel('温度 ℃');
% ★ 温升只有 0.5℃，若不收紧坐标轴就是一条直线，看不出趋势
tmp = r.temp; ylim([min(tmp)-0.05, max(tmp)+0.05]);
yyaxis right
plot(r.t, r.bal/16, r.t, r.fault/12, r.t, r.chg, r.t, r.dsg, 'LineWidth',0.8);
ylim([-0.1 1.2]); ylabel('状态');
grid on; box on; xlabel('时间 s');
legend('温度','均衡(归一)','故障(归一)','CHG','DSG','Location','best');

exportgraphics(f, fullfile(FIG, [nm '.png']), 'Resolution', 120);
close(f);
end

%% ===================== 补充图：上电 SOC 对齐过程 =====================
function plot_boot_align(r, FIG)
% 这张图专门说明本次固件改动的核心：上电 SOC 不再有假的 50% 占位值。
% 用 F3「上电静置对齐验证」场景（静置 60s → 30A 3s → 2A）来展示：
%   · 上电时真实电量未知 → 固件输出 UNKNOWN（不猜、不填占位值）
%   · 静置且电压稳定持续 15s 后，用 OCV 一次性对齐到真实值（约 100%）
%   · 之后交给库仑计，不再动
% 这里顺带把 OCV 对齐的"触发逻辑"画出来，便于对着 bms_app.c 的 cell_task() 核对。
if nargin < 1 || isempty(r)
    fprintf('[补充图] 缺少数据，跳过\n'); return;
end
fprintf('\n[补充图] 生成"上电 SOC 对齐过程"图（静置对齐场景）\n');

tv = r.t;
avg = r.dbg(:,3);                 % 可信统计的平均单体电压
i0  = find(r.aligned > 0, 1);

% 由平均电压反算 OCV 对应的 SOC（与固件同表），用来演示"为什么对齐到那个值"
OCV_MV  = [3400 3360 3340 3325 3315 3308 3300 3292 3285 3275 3262 3240 3180 3000];
OCV_SOC = [ 100   97   90   80   70   60   50   40   30   20   12    7    3    0];
ocv_soc = zeros(size(avg));
for k = 1:numel(avg)
    mv = avg(k);
    if mv >= OCV_MV(1)
        ocv_soc(k) = 100;
    else
        ocv_soc(k) = 0;
        for i = 2:numel(OCV_MV)
            if mv >= OCV_MV(i)
                ocv_soc(k) = OCV_SOC(i) + (mv-OCV_MV(i))/(OCV_MV(i-1)-OCV_MV(i))*(OCV_SOC(i-1)-OCV_SOC(i));
                break;
            end
        end
    end
end

f = figure('Visible','off','Position',[60 60 1300 780]);

subplot(4,1,1);
plot(tv, r.i_pack,'LineWidth',1.2, 'Color',[0.85 0.35 0.19]); grid on; box on;
ylabel('电流 A');
title('上电 SOC 对齐过程：静置 60s（车未启动）→ 启动 30A → 常态 2A','Interpreter','none');
legend('实际电流','Location','best');

subplot(4,1,2);
% 跳过最前面几个点：那时可信统计还没产出（C_avg 为 0），画出来会把纵轴拉扁
k0 = find(avg > 100, 1);
if isempty(k0), k0 = 1; end
plot(tv(k0:end), avg(k0:end), 'LineWidth',1.4, 'Color',[0.09 0.37 0.65]);
grid on; box on; ylabel('单体均值 mV');
ylim([min(avg(k0:end))-5, max(avg(k0:end))+5]);
legend('平均单体电压（稳定性判据的输入）','Location','best');

subplot(4,1,3);
% ★ OCV 反算只在「静置」时才有意义：带载时端电压含 I*R 压降，反算出来不是 SOC。
%   所以带载段置 NaN，只留静置段，避免误读。
ocv_show = ocv_soc;
ocv_show(abs(r.i_pack) > 0.05) = NaN;
plot(tv, r.soc, 'LineWidth',1.6, 'Color',[0.85 0.35 0.19]); hold on;
plot(tv, mean(r.soc_true,2), '--', 'LineWidth',1.4, 'Color',[0.09 0.37 0.65]);
plot(tv, ocv_show, ':', 'LineWidth',1.8, 'Color',[0.4 0.6 0.2]);
grid on; box on; ylabel('SOC %'); ylim([0 108]);
legend('固件 SOC','真实 SOC','OCV 查表反算(仅静置)','Location','best');
if ~isempty(i0)
    xline(tv(i0), 'k--', 'LineWidth',0.8, 'HandleVisibility','off');
    text(tv(i0)+2, 22, sprintf('t=%.0fs 对齐到 %.1f%%', tv(i0), r.soc(i0)), ...
         'FontSize',8, 'Color',[0.2 0.2 0.2]);
end

subplot(4,1,4);
stairs(tv, r.aligned, 'LineWidth',1.4, 'Color',[0.3 0.55 0.2]); hold on;
plot(tv, r.chg, tv, r.dsg, 'LineWidth',1.0);
grid on; box on; xlabel('时间 s'); ylabel('状态'); ylim([-0.1 1.3]);
legend('SOC 已对齐','CHG','DSG','Location','best');

exportgraphics(f, fullfile(FIG,'X_上电SOC对齐过程.png'), 'Resolution', 120);
close(f);
if isempty(i0)
    fprintf('[补充图] 该场景全程未对齐\n');
else
    fprintf('[补充图] 对齐时刻 %.1f s，对齐后固件 %.2f%% vs 真值 %.2f%%（偏差 %+.2f%%）\n', ...
        r.t(i0), r.soc(i0), mean(r.soc_true(i0,:)), r.soc(i0)-mean(r.soc_true(i0,:)));
end
end
