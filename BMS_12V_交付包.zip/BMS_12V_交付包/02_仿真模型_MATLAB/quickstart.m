function quickstart(stage)
%QUICKSTART  BMS C33 2P4S 仿真 —— 一键跑通
%
%   这是给"第一次上手"用的最短路径脚本。它会自己定位目录、自己检查环境、
%   按由小到大的顺序跑，每跑完一段就告诉你该看到什么。
%
%   ── 怎么用（就两步）────────────────────────────────────────
%     第 1 步：把 MATLAB 的当前目录切到 sim（见旁边教程"怎么切目录"）
%     第 2 步：在命令行敲下面任意一条，回车
%
%       quickstart        % ★ 最常用：自检 + 冒烟 + 短场景全套（约 1 分钟）
%       quickstart(1)     % 只做自检 + 1 个场景（约 10 秒，最快看到结果）
%       quickstart(2)     % 同默认，跑完 12 个短场景
%       quickstart(3)     % 再加长跑套件（7 个场景，约 45 分钟）
%
%   ── 跑完去哪看图 ───────────────────────────────────────────
%     短场景 → sim/figs/        长跑 → sim/figs_long/
%
%   ── 出问题了怎么办 ─────────────────────────────────────────
%     见 quickstart 最后打印的"下一步"，或读 sim/../手把手跑仿真教程.md

if nargin < 1 || isempty(stage), stage = 2; end
if ~ismember(stage, [1 2 3])
    error('quickstart:参数只能是 1 / 2 / 3');
end

here = fileparts(mfilename('fullpath'));
cd(here); addpath(here);

t_all = tic;
fprintf('\n');
fprintf('========================================================\n');
fprintf('   BMS C33 2P4S 仿真  一键跑通\n');
fprintf('========================================================\n');

%% ============ 阶段 0：环境自检 ============
fprintf('\n【0】环境自检\n');
fprintf('     工作目录 : %s\n', here);
fprintf('     MATLAB   : %s\n', version('-release'));

% 1) 固件头文件能不能解析到（这是"仿真与固件共用同一套阈值"的前提）
try
    cfg = load_bms_config();
catch e
    fprintf(2, '\n  ✗ 读不到固件头文件 bms_config.h\n     原因：%s\n', e.message);
    fprintf(2, '     → 确认 bms_firmware/Core/Inc/bms_config.h 还在\n\n');
    return;
end

% 2) 电池参数
P = c33_2p4s_params(cfg);

% 3) 模型文件是否齐全
need = {'bms_profile_model','bms_plant_model','bms_afe_model','bms_ctrl_model', ...
        'run_bms_offline','run_offline_suite'};
missing = {};
for k = 1:numel(need)
    if exist(need{k}, 'file') ~= 2, missing{end+1} = need{k}; end %#ok<SAGROW>
end
if ~isempty(missing)
    fprintf(2, '\n  ✗ 缺少模型文件：%s\n', strjoin(missing, ', '));
    return;
end
fprintf('     ✓ 环境就绪（%d 个模型文件齐全，阈值已从固件头文件读到）\n', numel(need));

%% ============ 阶段 1：冒烟测试（最短路径，先建立信心）============
fprintf('\n【1】冒烟测试：跑一个场景，确认整条链路通\n');
fprintf('     场景 S04 放电过流 60A（限值 50A），仿真 60 秒\n');
fprintf('     预期：DSG 在 0.33 秒左右关断，故障码含 3（放电过流）\n\n');

r = run_bms_offline('S04_放电过流');

i_off = find(r.dsg == 0, 1);
if isempty(i_off)
    fprintf(2, '\n  ✗ DSG 没有关断 —— 保护逻辑没生效，别往下跑了，先查这个\n\n');
    return;
end
fprintf('\n     ✓ 通过：DSG 在 %.2f 秒关断，故障码 %s\n', ...
        r.t(i_off), mat2str(unique(r.fault(r.fault>0))'));
fprintf('       这就是「保护动作对得上」的意思：60A 超限 → AFE 硬件过流 320ms → 切断\n');

if stage == 1
    fprintf('\n【完成】阶段 1 结束。想继续就跑 quickstart 或 quickstart(2)\n');
    show_fig(here, 'figs', 'S04_放电过流.png');
    fprintf('\n总耗时 %.1f 秒\n\n', toc(t_all));
    return;
end

%% ============ 阶段 2：短场景全套 ============
fprintf('\n【2】短场景全套：12 个场景（秒~分钟级，验保护动作）\n');
fprintf('     预计 1 分钟左右。每个场景会打印 SOC / 关键电压 / 保护动作 / 故障码\n\n');

run_offline_suite;

fprintf('\n     ✓ 12 个场景跑完，图已存 sim/figs/\n');
fprintf('       ★ 重点看这两个数（其余是背景信息）：\n');
fprintf('         · 积分跟踪误差：多数在 0.01~0.1%%，S02 为 0.2%%（那一档含 0.5h 自放电）\n');
fprintf('           → 库仑计算得准，没有系统性积分误差\n');
fprintf('         · DSG/CHG 关断时间：放电过流 0.33s / 充电过流 0.88s / 短路 0.00s\n');
fprintf('           → 保护动作快，且都能对上代码里的宏\n');

if stage == 2
    fprintf('\n【完成】短场景跑完。想加长时间测试就跑 quickstart(3)（约 45 分钟）\n');
    show_fig(here, 'figs', 'S02_放电到空.png');
    fprintf('\n总耗时 %.1f 秒\n\n', toc(t_all));
    return;
end

%% ============ 阶段 3：长跑套件 ============
fprintf('\n【3】长跑套件：11 个场景（小时~天级，验长期漂移）\n');
fprintf('     累计仿真 1722 小时 ≈ 72 天，实际计算约 45 分钟，请耐心等\n');
fprintf('     其中 30 天的两个场景最慢，每个约 10 分钟\n\n');

run_longrun_suite;

fprintf('\n     ✓ 长跑跑完，图已存 sim/figs_long/\n');
fprintf('       ★ 重点看「容量学习与真实衰减」那张表：\n');
fprintf('         固件标定容量如果一直是 30.000 Ah 不变，而真实容量在掉，\n');
fprintf('         说明容量学习没触发 —— 详见 长时间仿真测试报告.md\n');

show_fig(here, 'figs_long', 'LL7_深度循环30天.png');
fprintf('\n总耗时 %.1f 分钟\n\n', toc(t_all)/60);
end

%% ================= 辅助 =================
function show_fig(here, sub, fname)
% 在装了图形界面的 MATLAB 里直接把结果图打开，省得自己去翻目录
f = fullfile(here, sub, fname);
if ~isfile(f)
    return;
end
fprintf('\n     图：%s\n', f);
if usejava('desktop')
    try
        winopen(f);          % Windows：用系统默认看图程序打开
    catch
        % 打不开就算了，不打断流程
    end
end
end
