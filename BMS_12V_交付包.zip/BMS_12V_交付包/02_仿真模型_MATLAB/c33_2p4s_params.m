function P = c33_2p4s_params(cfg)
%C33_2P4S_PARAMS  亿纬动力 C33（33140 圆柱磷酸铁锂）2 并 4 串电池组参数
%
%   单体规格（亿纬官方 / 供货商资料，2026-09 核对）：
%     型号      C33 = IFR33140，圆柱磷酸铁锂
%     标称      3.2 V / 15 Ah（平均容量 15.2Ah @0.33C，最小 14.5Ah）
%     尺寸      φ33.3 × 140.8 mm，重量 267 g
%     内阻      交流 ≤3 mΩ，直流 ≤8 mΩ
%     截止      充电 3.65 V（截止电流 0.05C），放电 2.5 V（T>0℃）
%     倍率      最大持续充/放 2C / 3C（30 A / 45 A 每只）
%     温度      充电 0~55℃，放电 -20~60℃
%
%   2P4S 组合：
%     电压 12.8 V 标称，容量 30 Ah，能量 384 Wh
%     直流内阻 ≈ 8 mΩ ÷ 2P × 4S = 16 mΩ
%     电流能力：充电 60 A / 放电 90 A（★受采样电阻 R17 限制，见 bms_config.h）
%
%   ★ 建模口径（重要）：
%     本 BMS 只能测到"并联组"的电压，测不到 2 只并联单体之间的差异。
%     所以这里把每个 2P 组等效成一只 30Ah / 4mΩ 的电芯来建模——
%     在端子特性上与真实 2P 组等价，且正好是 BMS 能观测到的量。
%     需要看并联单体间的环流/温差时，才需要用 Simscape Battery 的
%     完整 8 电芯 Pack 模型（见 build_bms_pack_model.m）。
%
%   用法：
%       cfg = load_bms_config();
%       P   = c33_2p4s_params(cfg);
%       P.group.R0(2)  % 第 2 组的等效内阻

if nargin < 1 || isempty(cfg)
    cfg = load_bms_config();
end

%% ---------- 单体（datasheet） ----------
P.cell.model      = 'EVE C33 (IFR33140)';
P.cell.chem       = 'LiFePO4';
P.cell.Vnom       = 3.2;            % V
P.cell.Ah_nom     = 15.0;           % Ah（标称，平均 15.2 / 最小 14.5）
P.cell.Ah_avg     = 15.2;
P.cell.Ah_min     = 14.5;
P.cell.mass       = 0.267;          % kg
P.cell.cyl        = [33.3e-3 140.8e-3];   % [直径 高度] m
P.cell.Rac        = 3e-3;           % Ω 交流内阻
P.cell.Rdc        = 8e-3;           % Ω 直流内阻
P.cell.Vmax       = 3.65;           % V 充电截止
P.cell.Vmin       = 2.5;            % V 放电截止
P.cell.Cchg_max   = 2.0;            % C 最大持续充电
P.cell.Cdsg_max   = 3.0;            % C 最大持续放电
P.cell.Tchg       = [0 55];         % ℃ 充电温度范围
P.cell.Tdsg       = [-20 60];       % ℃ 放电温度范围
P.cell.cycle_life = 2500;           % 次（25℃，DOD 75%）
P.cell.energy_Whkg= 179;            % Wh/kg

%% ---------- 2P4S 组合 ----------
P.P = cfg.BMS_PACK_PARALLEL;        % 2
P.S = cfg.BMS_CELL_COUNT;           % 4
P.Vnom        = P.cell.Vnom * P.S;                       % 12.8 V
P.Ah          = P.cell.Ah_nom * P.P;                     % 30 Ah
P.Wh          = P.Vnom * P.Ah;                           % 384 Wh
P.Rdc_pack    = P.cell.Rdc / P.P * P.S;                  % 16 mΩ
P.Rac_pack    = P.cell.Rac / P.P * P.S;                  % 6 mΩ
P.Vmax_pack   = P.cell.Vmax * P.S;                       % 14.6 V
P.Vmin_pack   = P.cell.Vmin * P.S;                       % 10.0 V
P.I_chg_max   = P.cell.Cchg_max * P.cell.Ah_nom * P.P;   % 60 A（电芯能力）
P.I_dsg_max   = P.cell.Cdsg_max * P.cell.Ah_nom * P.P;   % 90 A（电芯能力）
P.mass        = P.cell.mass * P.P * P.S;                 % 2.136 kg
P.I_1C        = P.Ah;                                    % 30 A

% 硬件约束下的可用电流（与 bms_config.h 的限值一致，便于对比）
P.I_lim_chg   = cfg.BMS_CHARGE_MAX_A;
P.I_lim_dsg   = cfg.BMS_DISCHARGE_MAX_A;
P.I_shunt_max = sqrt(3.0 / (cfg.BMS_RSENSE_MOHM/1000));  % R17 额定 3W 对应的持续电流

%% ---------- 每组（2P 等效）的等效电路参数 ----------
% 2 只并联：容量 ×2，内阻 ÷2；OCV 曲线不变（并联单体电压相同）
P.group.Ah     = P.cell.Ah_nom * P.P;      % 30 Ah
P.group.R0     = (P.cell.Rdc * 0.75) / P.P;  % 欧姆内阻部分 ≈6mΩ/2 = 3mΩ
P.group.R1     = (P.cell.Rdc * 0.25) / P.P;  % 极化内阻部分 ≈2mΩ/2 = 1mΩ
P.group.tau1   = 30;                        % s，RC 时间常数（LFP 常用 20~60s）
P.group.C1     = P.group.tau1 / P.group.R1; % F
P.group.mass   = P.cell.mass * P.P;         % 0.534 kg
P.group.Cp     = 900;                       % J/(kg·K) 等效比热
P.group.hA     = 0.9;                       % W/K 每组到环境的等效散热（自然对流）

% 成组不一致（用于均衡/压差场景）：默认全部 1.0，跑场景时再按需覆盖
P.group.capScale = ones(1, P.S);
P.group.resScale = ones(1, P.S);
P.group.socInit  = 50 * ones(1, P.S);

%% ---------- OCV-SOC 表：与固件 bms_soc.c 的 s_ocv 完全一致 ----------
% 固件里是「单体 mV → SOC%」，这里给正反两个方向的插值函数，
% 保证仿真与固件用的是同一条曲线（否则 SOC 对不上就白测了）。
P.ocv.soc = [ 0    3    7   12   20   30   40   50   60   70   80   90   97  100];  % %
P.ocv.mv  = [3000 3180 3240 3262 3275 3285 3292 3300 3308 3315 3325 3340 3360 3400]; % mV/单体

P.fcn.ocvFromSoc = @(soc) ocv_from_soc(soc, P.ocv);
P.fcn.socFromOcv = @(mv)  soc_from_ocv(mv,  P.ocv);

%% ---------- 温度相关 ----------
P.thermal.T_amb   = 25;      % ℃ 环境
P.thermal.T_init  = 25;      % ℃ 初始
P.thermal.entropy = 0.0;     % V/K 熵热系数（先忽略，LFP ≈ -0.2~0.2 mV/K）

fprintf('[c33_2p4s] %dP%dS  %s\n', P.P, P.S, P.cell.model);
fprintf('            %.1f V / %.0f Ah / %.0f Wh / 直流内阻 %.1f mΩ / %.2f kg\n', ...
        P.Vnom, P.Ah, P.Wh, P.Rdc_pack*1000, P.mass);
fprintf('            电芯能力 充 %.0f A / 放 %.0f A；限值 充 %.0f A / 放 %.0f A；采样电阻上限 %.1f A\n', ...
        P.I_chg_max, P.I_dsg_max, P.I_lim_chg, P.I_lim_dsg, P.I_shunt_max);
end

%% ================= 插值函数 =================
function mv = ocv_from_soc(soc, ocv)
% SOC(%) → 单体 OCV(mV)，按 SOC 线性插值（两端钳位）
    s = min(max(soc, ocv.soc(1)), ocv.soc(end));
    mv = interp1(ocv.soc, ocv.mv, s, 'linear');
end

function s = soc_from_ocv(mv, ocv)
% 单体 OCV(mV) → SOC(%)，复刻固件 bms_soc.c 里 ocv_to_soc() 的查表逻辑：
% 表按 mV 递减，命中区间后按 (mv - v_lo)/(v_hi - v_lo) 线性插值
    v = min(max(mv, ocv.mv(1)), ocv.mv(end));
    s = interp1(ocv.mv, ocv.soc, v, 'linear');
end
