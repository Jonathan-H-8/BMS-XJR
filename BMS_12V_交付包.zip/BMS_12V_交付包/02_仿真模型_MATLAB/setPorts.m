function setPorts(blkName, pairs, mdlName)
%SETPORTS  批量设置 MATLAB Function 块的端口尺寸与类型（手工搭建时用）
%
%   为什么需要它：一个 MATLAB Function 块往往有十几个端口，在「编辑数据」
%   面板里一个个点很费事，而且默认大小是 -1（让 Simulink 自己推），
%   这正是报「无法确定模块的输出大小和/或类型」的根源。
%   本函数一次把整个块的端口设好。
%
%   用法：
%       setPorts('AFE_BQ76920', {'y','10', 'v_true','4', 'inj_cell','4'});
%       setPorts('Profile', {'scen','1', 'i_cmd','1'}, 'BMS_Manual');
%
%   规则：
%     · pairs 里列出的端口按指定大小设置
%     · 未列出的端口一律设为标量（大小 '1'）
%     · 类型统一设成 double
%       （本项目口径：AFE 输出打包成向量后，sys_stat 也是 double，
%         固件内部本来就有 uint8(sys_stat) 显式转换，逻辑不受影响）
%
%   参数：
%     blkName  块名（如 'AFE_BQ76920'），不需要带模型前缀
%     pairs    {'变量名','大小', '变量名','大小', ...} 交替的元胞数组
%     mdlName  模型名，默认 'BMS_Manual'
%
%   注意：Size 必须传字符（如 '10'），传数字会静默失败。

if nargin < 2 || isempty(pairs)
    error('setPorts: 至少给两个参数，例如 setPorts(''Profile'', {''i_cmd'',''1''})');
end
if nargin < 3 || isempty(mdlName)
    mdlName = 'BMS_Manual';
end
if mod(numel(pairs), 2) ~= 0
    error('setPorts: pairs 必须是「变量名, 大小」成对出现，当前 %d 个元素', numel(pairs));
end
if ~bdIsLoaded(mdlName) && ~isfile([mdlName '.slx'])
    error('setPorts: 模型 %s 既没打开也不存在', mdlName);
end

ch = sfroot().find('-isa', 'Stateflow.EMChart', 'Path', [mdlName '/' blkName]);
if isempty(ch)
    error('setPorts: 在 %s 里找不到 MATLAB Function 块 %s', mdlName, blkName);
end

d = ch(1).find('-isa', 'Stateflow.Data');
n = 0;
for k = 1:numel(d)
    nm = d(k).Name;
    sz = '1';                       % 默认标量
    for j = 1:2:numel(pairs)
        if strcmp(pairs{j}, nm)
            sz = pairs{j+1};
            break;
        end
    end
    d(k).Props.Array.Size = sz;     % ★ 必须是字符，不能传数字
    d(k).Props.Array.IsDynamic = false;
    d(k).DataType = 'double';
    n = n + 1;
end

fprintf('[setPorts] %s/%s：设好 %d 个端口（未列出的按标量 double）\n', ...
        mdlName, blkName, n);
end
