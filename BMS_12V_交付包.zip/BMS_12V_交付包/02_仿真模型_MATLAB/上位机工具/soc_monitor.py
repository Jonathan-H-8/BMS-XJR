#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ==============================================================================
#  BMS 电池容量实时监视程序（PC 端上位机）
#  ----------------------------------------------------------------------------
#  文件名  ：soc_monitor.py
#  描述    ：读固件每秒推送的 $BMS,... 数据帧，实时显示电池容量（SOC）
#  芯片    ：STM32F103C8T6 + BQ76920 的 BMS 板（本工程 bms_firmware）
#  数据来源: 固件 bms_debug.c 里的 BMS_PrintCsv()，1Hz 推送
#  参考手册: 无（协议见 bms_debug.c 的注释与 tools/README.md）
#  依赖    : 串口模式需要 pyserial（pip install pyserial）；网页看板只用标准库
#  版本更新: V1.0    2026-09-15
#  调试方式：python soc_monitor.py --sim --web
#  ----------------------------------------------------------------------------
#  用法：
#     python soc_monitor.py --port COM3                 终端实时显示
#     python soc_monitor.py --port COM3 --web           终端 + 网页看板
#     python soc_monitor.py --sim --web                 无硬件仿真，先看效果
#     python soc_monitor.py --port COM3 --csv run.csv   边看边存 CSV
#     python soc_monitor.py --sim --plain               纯文本一行一条（可重定向）
# ==============================================================================

import argparse
import csv
import json
import math
import os
import queue
import random
import sys
import threading
import time
from collections import deque
from datetime import datetime

# ---------------------------------------------------------------- 常量定义 ---

FRAME_HEAD = "$BMS,"                 # 固件数据帧头
HISTORY_MAX = 1800                   # 保留最近 1800 个样本（1Hz 约 30 分钟）
WEB_DEFAULT_PORT = 8765

# 故障码 → 中文名（与固件 bms_protect.c 的 Bms_Fault_t 顺序一致）
FAULT_NAMES = ["正常", "电芯过压", "电芯欠压", "放电过流", "放电短路",
               "充电过流", "过温", "低温禁充", "AFE 故障", "已锁定"]


# ---------------------------------------------------------------- 数据解析 ---

def parse_frame(line):
    """
    解析固件推送的一帧数据。

    格式：$BMS,时间ms,组端mV,节1,节2,节3,节4,电流mA,温度℃,SOC×10,剩余mAh,容量mAh,CHG,DSG,均衡,故障*XOR
    例   ：$BMS,123456,12840,3210,3205,3212,3213,-1520,25,785,7846,10000,1,1,0,0*3F

    :param line: 串口收到的一整行字符串
    :return: 解析成功返回字典；不是本协议或校验失败返回 None
    """
    line = line.strip()
    if not line.startswith(FRAME_HEAD):
        return None

    body = line[len("$"):]                       # 去掉开头的 $
    chk = None
    if "*" in body:
        body, _, hexsum = body.rpartition("*")
        try:
            chk = int(hexsum.strip(), 16)
        except ValueError:
            chk = None

    # 异或校验：$ 与 * 之间的所有字符逐字节异或
    if chk is not None:
        x = 0
        for ch in body:
            x ^= ord(ch)
        if x != chk:
            return None

    parts = body.split(",")
    if len(parts) < 16 or parts[0] != "BMS":
        return None

    try:
        d = {
            "ms":     int(parts[1]),
            "pack":   int(parts[2]),
            "cells":  [int(parts[3]), int(parts[4]), int(parts[5]), int(parts[6])],
            "cur":    int(parts[7]),                  # mA，充电为正
            "temp":   int(parts[8]),
            "soc":    int(parts[9]) / 10.0,           # %
            "remain": int(parts[10]),                 # mAh
            "cap":    int(parts[11]),                 # mAh
            "chg":    int(parts[12]),
            "dsg":    int(parts[13]),
            "bal":    int(parts[14]),
            "fault":  int(parts[15]),
        }
    except (ValueError, IndexError):
        return None

    now = time.time()
    d["wall"] = now
    d["clock"] = datetime.fromtimestamp(now).strftime("%H:%M:%S")
    d["delta"] = max(d["cells"]) - min(d["cells"])          # 最大压差 mV
    d["power"] = d["pack"] * d["cur"] / 1e6                 # 功率 W
    return d


# ---------------------------------------------------------------- 数据源 ---

class SimSource:
    """
    仿真数据源：没有硬件时用它演示界面。

    内部按库仑计积分推进 SOC，电芯电压用 LiFePO4 的 OCV 表 + 内阻压降算出来，
    充放电循环往复，所以界面上的"剩余容量"会真的随时间变化。
    """

    OCV_TABLE = [                       # (单体 mV, SOC%)
        (3400, 100), (3360, 97), (3340, 90), (3325, 80), (3315, 70),
        (3308, 60), (3300, 50), (3292, 40), (3285, 30), (3275, 20),
        (3262, 12), (3240, 7), (3180, 3), (3000, 0),
    ]

    def __init__(self, capacity_ah=10.0, start_soc=62.0, speed=10.0):
        """
        :param capacity_ah: 模拟电池容量
        :param start_soc:   起始 SOC%
        :param speed:       时间加速倍数。仿真每 1 秒推进 speed 秒的物理时间，
                            默认 10 是为了让容量变化肉眼可见；想看真实速度就设 1
        """
        self.cap_mah = capacity_ah * 1000.0
        self.soc = start_soc
        self.temp = 24.0
        self.speed = max(0.1, speed)
        self.t0 = time.time()
        self.next_t = time.time()              # 下一帧的发送时刻（节流用，模拟 1Hz）
        self.cell_off = [0, -3, +5, +2]        # 制造一点电芯不一致，方便看压差
        self.phase = "discharge"               # 先放电

    def _ocv_mv(self, soc):
        tbl = self.OCV_TABLE
        if soc >= tbl[0][1]:
            return tbl[0][0]
        for i in range(1, len(tbl)):
            if soc >= tbl[i][1]:
                v_hi, s_hi = tbl[i - 1]
                v_lo, s_lo = tbl[i]
                k = (soc - s_lo) / (s_hi - s_lo)
                return int(v_lo + k * (v_hi - v_lo))
        return tbl[-1][0]

    def read(self):
        """
        产生一帧数据；不到 1 秒返回 None（模拟真实设备的 1Hz 节奏，避免刷屏）。
        返回值格式与串口解析结果一致。
        """
        now = time.time()
        if now < self.next_t:
            return None
        self.next_t = now + 1.0

        # 按相位给出电流：放电 -8A，充电 +5A，接近边界时切相位
        if self.phase == "discharge":
            cur_a = -8.0 + random.uniform(-0.1, 0.1)
            if self.soc <= 8.0:
                self.phase = "charge"
        else:
            cur_a = +5.0 + random.uniform(-0.1, 0.1)
            if self.soc >= 99.0:
                self.phase = "discharge"

        # 库仑计积分：按加速倍数推进（一次推进 speed 秒）
        self.soc += (cur_a * 1000.0 * self.speed / 3600.0) / self.cap_mah * 100.0
        self.soc = min(100.0, max(0.0, self.soc))

        # 温度随大电流缓慢变化
        self.temp += ((26.0 if abs(cur_a) > 4 else 24.0) - self.temp) * 0.02

        # 端电压 = OCV + 电流 × 内阻（放电时电流为负，端电压自然低于 OCV）
        ocv = self._ocv_mv(self.soc)
        r_int = 0.025                                    # 单节等效内阻 Ω
        cells = [int(ocv + self.cell_off[i] + cur_a * r_int * 1000.0) for i in range(4)]
        cells = [min(4000, max(2500, c)) for c in cells]

        return {
            "ms":     int((time.time() - self.t0) * 1000),
            "pack":   sum(cells),
            "cells":  cells,
            "cur":    int(cur_a * 1000),
            "temp":   int(round(self.temp)),
            "soc":    round(self.soc, 1),
            "remain": int(self.cap_mah * self.soc / 100.0),
            "cap":    int(self.cap_mah),
            "chg":    1,
            "dsg":    1,
            "bal":    0,
            "fault":  0,
            "wall":   time.time(),
            "clock":  datetime.now().strftime("%H:%M:%S"),
            "delta":  max(cells) - min(cells),
            "power":  sum(cells) * cur_a / 1000.0,
            "src":    "sim",
        }


class SerialSource:
    """
    串口数据源：读取固件每秒推送的 $BMS 帧。

    连上后会自动发一条 "MON 1"，让固件开始 1Hz 推送（已经开着也无所谓）。
    同时提供 send() 供看板上的命令输入框使用。
    """

    def __init__(self, port, baud, auto_mon=True):
        try:
            import serial                                     # pyserial
        except ImportError:
            print("错误：串口模式需要 pyserial，请先执行：\n    pip install pyserial\n"
                  "或者先用仿真模式看效果：python soc_monitor.py --sim --web",
                  file=sys.stderr)
            raise SystemExit(2)

        self.ser = serial.Serial(port, baud, timeout=1)
        self.q = queue.Queue()
        self.alive = True
        self.auto_mon = auto_mon
        self.thread = threading.Thread(target=self._reader, daemon=True)
        self.thread.start()

    def _reader(self):
        """后台线程：逐行读串口，把解析好的数据塞进队列"""
        if self.auto_mon:
            self.send("MON 1")
        buf = b""
        while self.alive:
            try:
                chunk = self.ser.read(256)
            except Exception:
                time.sleep(0.2)
                continue
            if not chunk:
                continue
            buf += chunk
            while b"\n" in buf:
                raw, _, buf = buf.partition(b"\n")
                text = raw.decode("ascii", "ignore")
                if not text.strip().startswith("$BMS"):
                    continue
                d = parse_frame(text)
                if d:
                    d["src"] = "serial"
                    self.q.put(d)

    def read(self):
        """非阻塞取一帧，没有新数据返回 None"""
        try:
            return self.q.get_nowait()
        except queue.Empty:
            return None

    def send(self, cmd):
        """向固件发送一条文本命令（自动补回车换行）"""
        try:
            self.ser.write((cmd.strip() + "\r\n").encode("ascii", "ignore"))
            return True
        except Exception:
            return False


# ---------------------------------------------------------------- 终端显示 ---

def _bar(percent, width=28, full="█", empty="░"):
    """画一个百分比进度条"""
    percent = max(0.0, min(100.0, percent))
    n = int(round(percent / 100.0 * width))
    return full * n + empty * (width - n)


def _led_txt(soc):
    """用字符模拟板上 5 颗 LED 的电量条（每 20% 一颗）"""
    n = 0 if soc <= 0 else max(1, min(5, int(soc / 20.0)))
    return "".join("●" if i < n else "○" for i in range(5))


def render_terminal(d):
    """把一帧数据渲染成终端字符界面（每次清屏重画）"""
    soc = d["soc"]
    cur_a = d["cur"] / 1000.0
    dir_txt = "充电" if cur_a > 0.02 else ("放电" if cur_a < -0.02 else "静置")
    color = "\033[31m" if cur_a > 0.02 else ("\033[32m" if cur_a < -0.02 else "\033[0m")

    out = ["\033[2J\033[H"]                                   # 清屏 + 光标归位
    out.append("=" * 64)
    out.append("        BMS 电池容量实时监视    %s    [%s]" %
               (d["clock"], "仿真" if d.get("src") == "sim" else "串口"))
    out.append("=" * 64)

    # 容量主体
    out.append("")
    out.append("   剩余容量 : %8.3f Ah   ( %5.1f %% )  %s" %
               (d["remain"] / 1000.0, soc, _led_txt(soc)))
    out.append("   [%s]" % _bar(soc, 40))
    out.append("   总容量   : %8.3f Ah       已放出/充入核算基准" % (d["cap"] / 1000.0))
    out.append("")

    # 电压电流
    out.append("   组端电压 : %8.3f V     电流 : %s%+7.3f A\033[0m (%s, %+.1f W)" %
               (d["pack"] / 1000.0, color, cur_a, dir_txt, d["power"]))
    out.append("   温度     : %5d ℃         压差 : %4d mV" % (d["temp"], d["delta"]))
    out.append("")

    # 电芯
    out.append("   电芯电压：")
    for i, mv in enumerate(d["cells"]):
        out.append("     [%d] %5d mV  %s" % (i + 1, mv, _bar((mv - 2500) / 11.5, 20)))
    out.append("")

    # 状态
    out.append("   MOS      : CHG %s   DSG %s      均衡掩码 0x%02X" %
               ("开" if d["chg"] else "关", "开" if d["dsg"] else "关", d["bal"]))
    fault = d["fault"]
    ftxt = FAULT_NAMES[fault] if 0 <= fault < len(FAULT_NAMES) else str(fault)
    if fault:
        out.append("   \033[31m故障     : %s\033[0m" % ftxt)
    else:
        out.append("   故障     : %s" % ftxt)
    out.append("")
    out.append("-" * 64)
    out.append("   Ctrl+C 退出        （加 --web 可同时打开网页看板）")
    return "\n".join(out)


def render_plain(d):
    """一行一条的纯文本输出（方便重定向到文件或喂给别的工具）"""
    return ("%s  剩余 %7.3fAh  SOC %5.1f%%  组端 %6.3fV  电流 %+7.3fA  "
            "温度 %3d℃  压差 %3dmV  故障 %s" % (
                d["clock"], d["remain"] / 1000.0, d["soc"], d["pack"] / 1000.0,
                d["cur"] / 1000.0, d["temp"], d["delta"],
                FAULT_NAMES[d["fault"]] if 0 <= d["fault"] < len(FAULT_NAMES) else d["fault"]))


# ---------------------------------------------------------------- 网页看板 ---

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>BMS 电池容量实时监视</title>
<style>
:root{--bg:#f6f8fa;--fg:#1f2328;--mut:#57606a;--line:#d8dee4;--card:#fff;
--a:#0969da;--g:#1a7f37;--r:#cf222e;--o:#bc4c00;--p:#8250df}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
 font:14px/1.6 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:20px}
header{display:flex;align-items:baseline;gap:14px;margin-bottom:14px}
h1{font-size:19px;margin:0}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--mut);margin-right:6px}
.dot.on{background:var(--g);box-shadow:0 0 0 3px #1a7f3722}
.mut{color:var(--mut);font-size:12.5px}
.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.card h2{font-size:13px;margin:0 0 8px;color:var(--mut);font-weight:600}
.big{grid-column:span 5;text-align:center}
.big .v{font-size:56px;font-weight:700;line-height:1.1;color:var(--a)}
.big .u{font-size:22px;color:var(--mut)}
.half{grid-column:span 3}
.third{grid-column:span 2}
.bar{height:12px;background:#eaeef2;border-radius:6px;overflow:hidden;margin:8px 0 4px}
.bar i{display:block;height:100%;background:linear-gradient(90deg,#54aeff,#0969da)}
.leds{display:flex;gap:8px;justify-content:center;margin-top:10px}
.leds i{width:16px;height:16px;border-radius:50%;background:#eaeef2;border:1px solid var(--line)}
.leds i.on{background:#2da44e;border-color:#1a7f37}
.leds i.on.red{background:var(--r);border-color:var(--r)}
.kv{display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px dashed #eaeef2}
.kv:last-child{border:0}
.kv b{font-weight:600}
.cell{display:flex;align-items:center;gap:8px;margin:5px 0;font-size:12.5px}
.cell span:first-child{width:26px;color:var(--mut)}
.cell .cb{flex:1;height:9px;background:#eaeef2;border-radius:5px;overflow:hidden}
.cell .cb i{display:block;height:100%;background:#2da44e}
.cell span:last-child{width:64px;text-align:right;font-variant-numeric:tabular-nums}
#cv{width:100%;height:220px;display:block}
.cmd{display:flex;gap:8px;margin-top:6px}
.cmd input{flex:1;padding:7px 10px;border:1px solid var(--line);border-radius:6px;font-size:13px}
.cmd button{padding:7px 14px;border:0;border-radius:6px;background:var(--a);color:#fff;font-size:13px;cursor:pointer}
.tag{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12px;border:1px solid var(--line)}
.tag.on{color:var(--g);border-color:#2da44e55;background:#2da44e14}
.tag.off{color:var(--r);border-color:#cf222e55;background:#cf222e14}
</style></head><body><div class="wrap">
<header>
  <h1>BMS 电池容量实时监视</h1>
  <span class="mut"><span class="dot" id="dot"></span><span id="st">等待数据…</span></span>
  <span class="mut" id="meta"></span>
</header>

<div class="grid">
  <div class="card big">
    <h2>电池容量 / SOC</h2>
    <div class="v"><span id="soc">--</span><span class="u">%</span></div>
    <div class="bar"><i id="socbar" style="width:0%"></i></div>
    <div class="mut"><b id="remain">--</b> Ah 剩余 / <span id="cap">--</span> Ah 总额定</div>
    <div class="leds" id="leds">
      <i></i><i></i><i></i><i></i><i class="red"></i>
    </div>
    <div class="mut" style="margin-top:6px">（对应板上 5 颗 LED：每颗 20%）</div>
  </div>

  <div class="card half">
    <h2>电流 / 功率</h2>
    <div class="kv"><span>电流</span><b id="cur">--</b></div>
    <div class="kv"><span>状态</span><b id="dir">--</b></div>
    <div class="kv"><span>功率</span><b id="pw">--</b></div>
  </div>

  <div class="card half">
    <h2>组端 / 温度</h2>
    <div class="kv"><span>组端电压</span><b id="pack">--</b></div>
    <div class="kv"><span>温度</span><b id="temp">--</b></div>
    <div class="kv"><span>最大压差</span><b id="delta">--</b></div>
  </div>

  <div class="card half">
    <h2>电芯电压</h2>
    <div id="cells"></div>
  </div>

  <div class="card half">
    <h2>保护状态</h2>
    <div class="kv"><span>充电管 CHG</span><span id="chg" class="tag">--</span></div>
    <div class="kv"><span>放电管 DSG</span><span id="dsg" class="tag">--</span></div>
    <div class="kv"><span>均衡掩码</span><b id="bal">--</b></div>
    <div class="kv"><span>故障</span><span id="fault" class="tag">--</span></div>
  </div>

  <div class="card" style="grid-column:span 12">
    <h2>SOC / 电流 / 组端电压 实时曲线（最近 30 分钟）</h2>
    <canvas id="cv"></canvas>
  </div>

  <div class="card" style="grid-column:span 8">
    <h2>下发命令（等同串口直接输入）</h2>
    <div class="cmd">
      <input id="cin" placeholder="例如：SET CHG 15   /   ?   /   MON 1   /   CLR   /   CAP 10" autocomplete="off">
      <button onclick="sendCmd()">发送</button>
    </div>
    <div class="mut" style="margin-top:6px" id="cmsg">仿真模式下命令不会真正下发给硬件。</div>
  </div>

  <div class="card" style="grid-column:span 4">
    <h2>数据</h2>
    <div class="kv"><span>样本数</span><b id="cnt">0</b></div>
    <div class="kv"><span>最近更新</span><b id="last">--</b></div>
    <div class="kv"><span>CSV 记录</span><a href="/csv" download="bms_soc.csv">下载</a></div>
  </div>
</div>
</div>

<script>
const $ = id => document.getElementById(id);
const hist = {t:[], soc:[], cur:[], pack:[]};
let lastWall = 0, cnt = 0, t0 = 0;

function setTag(el, on, onTxt, offTxt){
  el.textContent = on ? onTxt : offTxt;
  el.className = 'tag ' + (on ? 'on' : 'off');
}

function update(d){
  if (t0 === 0) t0 = d.wall;
  cnt++;
  $('soc').textContent  = d.soc.toFixed(1);
  $('socbar').style.width = Math.max(0, Math.min(100, d.soc)) + '%';
  $('remain').textContent = (d.remain/1000).toFixed(3);
  $('cap').textContent    = (d.cap/1000).toFixed(3);

  const cur = d.cur/1000;
  $('cur').textContent = (cur>0?'+':'') + cur.toFixed(3) + ' A';
  $('cur').style.color = cur>0.02 ? 'var(--r)' : (cur<-0.02 ? 'var(--g)' : 'var(--fg)');
  $('dir').textContent = cur>0.02 ? '充电' : (cur<-0.02 ? '放电' : '静置');
  $('pw').textContent  = d.power.toFixed(2) + ' W';
  $('pack').textContent = (d.pack/1000).toFixed(3) + ' V';
  $('temp').textContent = d.temp + ' ℃';
  $('delta').textContent = d.delta + ' mV';

  // 5 颗 LED（第 5 颗是红的，电量 >=100% 时才亮）
  let n = d.soc <= 0 ? 0 : Math.max(1, Math.min(5, Math.floor(d.soc/20)));
  [...$('leds').children].forEach((el,i)=>el.classList.toggle('on', i<n));

  // 电芯电压条（2.5V~3.65V 映射到 0~100%）
  $('cells').innerHTML = d.cells.map((mv,i)=>{
    const p = Math.max(0, Math.min(100, (mv-2500)/11.5));
    return `<div class="cell"><span>${i+1}</span><div class="cb"><i style="width:${p}%"></i></div><span>${mv} mV</span></div>`;
  }).join('');

  setTag($('chg'), d.chg, '开启', '关闭');
  setTag($('dsg'), d.dsg, '开启', '关闭');
  $('bal').textContent = '0x' + d.bal.toString(16).padStart(2,'0').toUpperCase();
  const fn = ['正常','电芯过压','电芯欠压','放电过流','放电短路','充电过流','过温','低温禁充','AFE 故障','已锁定'];
  const ftxt = fn[d.fault] ?? d.fault;
  const f = $('fault'); f.textContent = ftxt;
  f.className = 'tag ' + (d.fault ? 'off' : 'on');

  $('cnt').textContent = cnt;
  $('last').textContent = d.clock;
  $('dot').classList.add('on');
  $('st').textContent = (d.src==='sim' ? '仿真数据' : '串口在线') + ' · 1 Hz';
  $('meta').textContent = '已运行 ' + Math.round(d.wall - t0) + ' s';

  hist.t.push(d.wall); hist.soc.push(d.soc); hist.cur.push(cur); hist.pack.push(d.pack/1000);
  if (hist.t.length > 1800){ hist.t.shift(); hist.soc.shift(); hist.cur.shift(); hist.pack.shift(); }
  draw();
}

// ---- 曲线：SOC（蓝，左轴 0~100%）+ 电流（红/绿，右轴自适应）+ 组端电压（灰虚线）----
function draw(){
  const cv = $('cv'), r = cv.getBoundingClientRect();
  const W = cv.width = r.width * devicePixelRatio;
  const H = cv.height = 220 * devicePixelRatio;
  const g = cv.getContext('2d');
  g.clearRect(0,0,W,H);
  const L=48*devicePixelRatio, R=W-56*devicePixelRatio, T=12*devicePixelRatio, B=H-22*devicePixelRatio;
  const n = hist.t.length; if (n < 2) return;

  const amax = Math.max(1, ...hist.cur.map(Math.abs)) * 1.15;
  const vmin = Math.min(...hist.pack) - 0.05, vmax = Math.max(...hist.pack) + 0.05;
  const X = i => L + (R-L) * i/(n-1);
  const Ys = v => B - (B-T) * v/100;                                  // SOC 轴 0~100
  const Yi = v => (T+B)/2 - (B-T)/2 * v/amax;                          // 电流轴 对称
  const Yv = v => B - (B-T) * (v-vmin)/Math.max(0.01, vmax-vmin);      // 电压轴自适应

  // 网格 + 刻度
  g.strokeStyle='#d8dee4'; g.lineWidth=1*devicePixelRatio; g.font=(11*devicePixelRatio)+'px sans-serif';
  g.fillStyle='#57606a'; g.textAlign='right';
  for (let k=0;k<=4;k++){
    const y = T + (B-T)*k/4;
    g.beginPath(); g.moveTo(L,y); g.lineTo(R,y); g.stroke();
    g.fillText(Math.round(100*(1-k/4))+'%', L-6*devicePixelRatio, y+4*devicePixelRatio);
  }
  g.textAlign='left';
  g.fillText('+'+amax.toFixed(1)+'A', R+6*devicePixelRatio, T+10*devicePixelRatio);
  g.fillText('0A', R+6*devicePixelRatio, (T+B)/2+4*devicePixelRatio);
  g.fillText('-'+amax.toFixed(1)+'A', R+6*devicePixelRatio, B);
  g.textAlign='center'; g.fillText('← 时间（最近 '+Math.round((hist.t[n-1]-hist.t[0]))+' 秒）', (L+R)/2, H-5*devicePixelRatio);

  // 电流（零轴为基准的填充）
  g.fillStyle='rgba(207,34,46,.16)';
  for (let i=0;i<n;i++){
    const x=X(i), y0=Yi(0), y1=Yi(hist.cur[i]);
    g.fillRect(x-1*devicePixelRatio, Math.min(y0,y1), 2*devicePixelRatio, Math.abs(y1-y0));
  }
  // 组端电压
  g.strokeStyle='#8250df'; g.setLineDash([4*devicePixelRatio,3*devicePixelRatio]);
  g.beginPath(); hist.pack.forEach((v,i)=> i? g.lineTo(X(i),Yv(v)) : g.moveTo(X(i),Yv(v))); g.stroke();
  g.setLineDash([]);
  // SOC 主线
  g.strokeStyle='#0969da'; g.lineWidth=2.4*devicePixelRatio;
  g.beginPath(); hist.soc.forEach((v,i)=> i? g.lineTo(X(i),Ys(v)) : g.moveTo(X(i),Ys(v))); g.stroke();
}

async function sendCmd(){
  const v = $('cin').value.trim(); if (!v) return;
  $('cin').value='';
  try{
    const r = await fetch('/cmd', {method:'POST', body:v});
    const t = await r.text();
    $('cmsg').textContent = '已发送：' + v + (t ? ('  → ' + t) : '');
  }catch(e){ $('cmsg').textContent = '发送失败：' + e; }
}
$('cin').addEventListener('keydown', e=>{ if(e.key==='Enter') sendCmd(); });

const es = new EventSource('/events');
es.onmessage = ev => { try{ update(JSON.parse(ev.data)); }catch(e){} };
es.onerror = () => { $('dot').classList.remove('on'); $('st').textContent='连接断开，重试中…'; };
window.addEventListener('resize', draw);
</script></body></html>
"""


class WebServer:
    """
    网页看板服务：只用标准库。

      /        → 看板页面
      /events  → SSE 实时数据流（每收到一帧就推一条 JSON）
      /cmd     → POST 命令文本，转发给固件
      /csv     → 下载本次记录的 CSV
    """

    def __init__(self, state, port, source, csv_path):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        import urllib.parse

        self.state = state
        self.source = source
        self.csv_path = csv_path
        outer = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args):        # 关掉逐条访问日志，避免刷屏
                pass

            def do_GET(self):
                path = urllib.parse.urlparse(self.path).path
                if path == "/":
                    body = DASHBOARD_HTML.encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                elif path == "/events":
                    self.send_response(200)
                    self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                    self.send_header("Cache-Control", "no-cache")
                    self.send_header("Connection", "keep-alive")
                    self.end_headers()
                    last_n = -1
                    while True:
                        d = outer.state.latest
                        n = outer.state.count
                        if d and n != last_n:
                            last_n = n
                            try:
                                self.wfile.write(("data: " + json.dumps(d, ensure_ascii=False) +
                                                  "\n\n").encode("utf-8"))
                                self.wfile.flush()
                            except (BrokenPipeError, ConnectionResetError):
                                return
                        time.sleep(0.2)
                elif path == "/csv":
                    if os.path.exists(outer.csv_path):
                        data = open(outer.csv_path, "rb").read()
                        self.send_response(200)
                        self.send_header("Content-Type", "text/csv; charset=utf-8")
                        self.send_header("Content-Disposition", "attachment; filename=bms_soc.csv")
                        self.send_header("Content-Length", str(len(data)))
                        self.end_headers()
                        self.wfile.write(data)
                    else:
                        hdr = ("日期时间,时间戳ms,组端mV,节1mV,节2mV,节3mV,节4mV,电流mA,"
                               "温度C,SOC%,剩余mAh,容量mAh,CHG,DSG,均衡,故障码\n").encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "text/csv; charset=utf-8")
                        self.send_header("Content-Disposition", "attachment; filename=bms_soc.csv")
                        self.send_header("Content-Length", str(len(hdr)))
                        self.end_headers()
                        self.wfile.write(hdr)
                else:
                    self._text(404, "not found")

            def do_POST(self):
                length = int(self.headers.get("Content-Length") or 0)
                cmd = self.rfile.read(length).decode("utf-8", "ignore").strip()
                ok = outer.source.send(cmd) if hasattr(outer.source, "send") else False
                self._text(200, "已转发" if ok else "未连接硬件（仿真模式）")

            def _text(self, code, msg):
                b = msg.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.port = port

    def start(self):
        t = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        t.start()
        return self.port


# ---------------------------------------------------------------- 主程序 ---

def main():
    ap = argparse.ArgumentParser(description="BMS 电池容量实时监视程序")
    ap.add_argument("--port", help="串口号，如 COM3（与固件 115200 通信）")
    ap.add_argument("--baud", type=int, default=115200, help="波特率，默认 115200")
    ap.add_argument("--sim", action="store_true", help="仿真模式：不需要硬件")
    ap.add_argument("--sim-speed", type=float, default=10.0,
                    help="仿真时间加速倍数，默认 10（设 1 就是真实速度）")
    ap.add_argument("--web", action="store_true", help="同时启动网页看板")
    ap.add_argument("--http-port", type=int, default=WEB_DEFAULT_PORT, help="网页端口，默认 8765")
    ap.add_argument("--csv", default="bms_soc.csv", help="CSV 记录文件名（默认 bms_soc.csv）")
    ap.add_argument("--plain", action="store_true", help="纯文本输出，不清屏（适合重定向）")
    ap.add_argument("--no-csv", action="store_true", help="不写 CSV")
    args = ap.parse_args()

    if not args.sim and not args.port:
        ap.error("请指定 --port COMx 或使用 --sim 仿真模式")

    # ---------------- 数据源 ----------------
    source = SimSource(speed=args.sim_speed) if args.sim else SerialSource(args.port, args.baud)
    if args.sim:
        print("仿真模式：正在生成 4S LiFePO4 充放电数据（8A 放电 / 5A 充电循环，"
              "时间加速 %g 倍）" % args.sim_speed)

    # ---------------- CSV ----------------
    csv_file = csv_writer = None
    if not args.no_csv:
        new_file = not os.path.exists(args.csv)
        csv_file = open(args.csv, "a", newline="", encoding="utf-8")
        csv_writer = csv.writer(csv_file)
        if new_file:
            csv_writer.writerow(["日期时间", "时间戳ms", "组端mV", "节1mV", "节2mV", "节3mV", "节4mV",
                                 "电流mA", "温度C", "SOC%", "剩余mAh", "容量mAh",
                                 "CHG", "DSG", "均衡", "故障码"])
        print("数据同时记录到：%s" % os.path.abspath(args.csv))

    state = type("S", (), {"latest": None, "count": 0})()

    # ---------------- 网页看板 ----------------
    if args.web:
        srv = WebServer(state, args.http_port, source, args.csv)
        srv.start()
        print("网页看板已启动：http://127.0.0.1:%d" % args.http_port)

    if not args.plain and not args.web:
        print("终端实时显示中（Ctrl+C 退出）…")

    last_render = 0.0
    try:
        while True:
            d = source.read()
            if d is not None:
                state.latest = d
                state.count += 1
                if csv_writer:
                    csv_writer.writerow([
                        datetime.fromtimestamp(d["wall"]).strftime("%Y-%m-%d %H:%M:%S"),
                        d["ms"], d["pack"], d["cells"][0], d["cells"][1], d["cells"][2], d["cells"][3],
                        d["cur"], d["temp"], "%.1f" % d["soc"], d["remain"], d["cap"],
                        d["chg"], d["dsg"], d["bal"], d["fault"]])
                    csv_file.flush()

                if args.plain:
                    print(render_plain(d), flush=True)
                elif not args.web and time.time() - last_render > 0.9:
                    print(render_terminal(d), flush=True)
                    last_render = time.time()
                elif args.web:
                    # 网页模式：终端只每秒打一行简讯，方便看后台是否活着
                    if time.time() - last_render > 4.0:
                        print("[%s] %s" % (d["clock"], render_plain(d)), flush=True)
                        last_render = time.time()
            else:
                if args.sim:
                    time.sleep(1.0)          # 仿真按 1Hz 产生
                else:
                    time.sleep(0.05)
    except KeyboardInterrupt:
        print("\n已退出。")
    finally:
        if csv_file:
            csv_file.close()


if __name__ == "__main__":
    main()
