function make_model()
%MAKE_MODEL  一键生成并打开 BMS 仿真模型（在 MATLAB 桌面里跑）
%
%   用法：在 MATLAB 命令行敲
%       cd('C:\Users\admin\WorkBuddy\2026-09-14-22-07-51\sim')
%       make_model
%
%   它会：
%     1) 读固件阈值（bms_config.h）+ 电池参数
%     2) 生成模型 BMS_C33_2P4S.slx（含四个块、代码注入、端口尺寸、连线）
%     3) 用 Simulink 打开它，让你直接看到画布
%     4) 顺手导出一张模型结构图到 sim/BMS_model_view.png
%
%   ★ 为什么必须在这个函数里做，而不能在命令行 -batch 模式下做：
%     无界面模式下 Simulink 首次初始化会无限期挂住（本机实测 15 分钟无响应），
%     但**在桌面里跑只要几十秒**。所以这个函数要你在 MATLAB 窗口里执行。

here = fileparts(mfilename('fullpath'));
cd(here); addpath(here);

fprintf('\n===== 生成 BMS 仿真模型 =====\n');
t0 = tic;

fprintf('[1/4] 读固件阈值与电池参数...\n');
cfg = load_bms_config();
P   = c33_2p4s_params(cfg);

fprintf('\n[2/4] 生成模型（第一次会比较慢，Simulink 要加载库）...\n');
build_bms_model(cfg, P);

fprintf('\n[3/4] 编译检查（验证端口尺寸推断）...\n');
try
    load_system('BMS_C33_2P4S');
    set_param('BMS_C33_2P4S', 'SimulationCommand', 'update');
    fprintf('      ✓ 整机编译通过\n');
catch e
    fprintf(2, '      ✗ 编译未通过：%s\n', e.message);
    fprintf(2, '        把这段报错发我，我来定位\n');
end

fprintf('\n[4/4] 打开模型 + 导出结构图...\n');
open_system('BMS_C33_2P4S');
try
    png = fullfile(here, 'BMS_model_view.png');
    print('-sBMS_C33_2P4S', '-dpng', '-r150', png);
    fprintf('      结构图已导出：%s\n', png);
catch
    fprintf('      （结构图导出跳过，不影响使用）\n');
end

fprintf('\n===== 完成，用了 %.1f 秒 =====\n', toc(t0));
fprintf('模型画布已打开，直接看即可。\n');
fprintf('想跑一个场景：\n');
fprintf('    quickstart(1)        %% 纯 MATLAB 路线，快\n');
fprintf('    或双击模型里的 Scope 看波形\n\n');
end
