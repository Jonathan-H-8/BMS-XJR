function [i_cmd, scen_name] = bms_profile_model(scen, v_pack, t)
%%#codegen
%BMS_PROFILE_MODEL  工况生成：静置 / 恒流充放电 / CC-CV 充电 / 过流 / 短路脉冲 / 长时循环
%
%   相当于「负载 + 充电机」的集合。CC-CV 用上一拍的组端电压做判定，
%   所以外部要用一个 Memory 块喂 v_pack（同时也避免代数环）。
%
%   输入：
%     scen    工况编号（见下面表格）
%     v_pack  上一拍的组端真实电压 mV
%     t       时间 s
%   输出：
%     i_cmd     要求的电流 A（+ 充电 / − 放电）
%     scen_name 工况名（1×1 编码，仅用于日志：与下面的编号一致）
%
%   工况表：
%     1   静置（0A）                          —— 基线：验证采样/SOC 不漂
%     2   恒流放电 1C（−30A）                  —— 放电到空，看 SOC/低压保护
%     3   CC-CV 充电 1C→限压 3550mV/单体        —— 满充判定 + 容量学习 + 过压
%     4   过流放电 60A                         —— 超 50A 限值：软件二级 + AFE OCD
%     5   过流充电 35A                         —— 超 30A 限值：纯软件保护
%     6   快循环（放 20A 300s→静 60s→充 20A 300s→静 60s） 720s/周期
%     7   短路脉冲 150A 50ms（每 30s 一次）     —— AFE 的 SCD 硬件短路保护
%     8   低温充电（环境由 SCEN 给）            —— 低温禁充
%     9   高温放电（环境由 SCEN 给）            —— 过温禁放
%    10   慢循环深度放电（放 15A→静 5min→充 15A→静 5min） 5400s/周期
%         —— 长时间 SOC 往复，看库仑计长期漂移与均衡是否持续动
%    11   恒流放电到空 + 静置恢复（续航型工况，配合长 T 看 SOC 长期稳定性）
%    12   每日光伏式浅循环（充 12A 4h + 放 6A 5h + 静置 15h）86400s/周期
%         —— ★ 最接近储能真实用法，可连续跑多天看累积误差
%    13   FSAE 大学生方程式耐力赛（启动 30A → 常态巡航 2A）1800s
%         —— 看大电流冲击下的压降/压差、SOC 精度、保护是否误动
%    14   FSAE 耐力赛 + 多圈脉冲（启动 30A 后进"加速-滑行"方波）1800s
%         —— 更接近真实赛道：电流在 2A 附近大幅脉动，考库仑计与压差
%    15   上电静置 + FSAE 起步（静置 60s → 30A 3s → 2A）300s
%         —— 专门验证"上电快速 OCV 对齐"：车还没启动那 60s 用来对齐 SOC
%
%   说明：所有工况都是「时间 t 的纯函数」，因此把 T 拉长到任何值都不会
%         出现工况本身失效的问题（这是能长时间跑的前提）。

CV_MV_PER_CELL = 3550;      % CV 限压（比 OV 跳闸 3650 低 100mV，留余量）
CV_MV   = CV_MV_PER_CELL * 4;
CC_A    = 30;               % 1C
CV_KNEE = 600;              % CV 段线性回落的电压区间 mV

i_cmd = 0;
scen_name = scen;

if scen == 1
    i_cmd = 0;
elseif scen == 2
    i_cmd = -30;
elseif scen == 3
    if v_pack < CV_MV
        i_cmd = CC_A;
    else
        % 简化 CV：进入限压后电流线性回落
        i_cmd = CC_A * max(0, (CV_MV + CV_KNEE - v_pack)) / CV_KNEE;
    end
elseif scen == 4
    i_cmd = -60;
elseif scen == 5
    i_cmd = 35;
elseif scen == 6
    ph = mod(t, 720);
    if ph < 300
        i_cmd = -20;
    elseif ph < 360
        i_cmd = 0;
    elseif ph < 660
        i_cmd = 20;
    else
        i_cmd = 0;
    end
elseif scen == 7
    ph = mod(t, 30);
    if ph < 0.05
        i_cmd = -150;       % 50ms 短路脉冲
    else
        i_cmd = 0;
    end
elseif scen == 8
    i_cmd = 20;             % 低温充电：20A（低于 30A 限值），环境由 SCEN 给
elseif scen == 9
    i_cmd = -40;            % 高温放电（环境温度由 SCEN 给）
elseif scen == 10
    % ---- 慢循环深度放电：放 15A 45min(2700s) → 静 300s → 充 15A 45min → 静 300s ----
    % 15A 属于 0.5C，放电深度约 37.5%，一个周期 5400s = 1.5h
    ph = mod(t, 5400);
    if ph < 2700
        i_cmd = -15;
    elseif ph < 3000
        i_cmd = 0;
    elseif ph < 5700
        i_cmd = 15;
    else
        i_cmd = 0;
    end
elseif scen == 11
    % ---- 恒流放电到空 + 静置：与 S02 相同量级，但用在很长的 T 下 ----
    i_cmd = -30;
elseif scen == 12
    % ---- 每日光伏式浅循环（无光照静置 → 白天充电 → 傍晚放电）----
    % 一个周期 86400s = 24h：
    %   0~4h    充电 12A（模拟日照，4h × 12A = 48Ah 但受满充判定截断）
    %   4~9h    放电 6A （5h × 6A = 30Ah，约 1 个满循环的 50%）
    %   9~24h   静置（15h）
    ph = mod(t, 86400);
    if ph < 14400
        i_cmd = 12;
    elseif ph < 32400
        i_cmd = -6;
    else
        i_cmd = 0;
    end
elseif scen == 13
    % ---- FSAE 大学生方程式耐力赛 ----
    % 现实背景：FSAE 电车耐力赛约 22 km，跑 20~30 分钟，中途换车手。
    % 全程电流并不大（0.07C 量级），但**起步瞬间**有几十安培的冲击：
    %   ① 启动电机（带转冷却泵/风扇，或主接触器预充后合闸瞬间）约 30A
    %   ② 其余时间电机控制器待机 + 仪表 + 风扇，合计约 2A
    % ★ 注意 30A 是**放电**（负号），与 30A 的充电限值无关。
    %   真正要盯的是它落在 50A 放电限值以内，但造成的电压跌落有多大。
    % 时序：
    %   0 ~ T_START(3s)   启动电机 30A
    %   T_START ~ T       常态巡航 2A
    T_START = 3;
    if t < T_START
        i_cmd = -30;
    else
        i_cmd = -2;
    end
elseif scen == 14
    % ---- FSAE 耐力赛（多圈脉动版）：启动后进入"加速-滑行"方波 ----
    % 真实赛道上油门/刹车交替，母线电流是脉动的，而不是恒定的 2A。
    % 这里用 30A 加速 4s + 2A 滑行 26s 的方波（30s/圈），
    % 平均电流 ≈ (30×4 + 2×26)/30 = 5.73A，与耐力赛平均功耗同量级。
    % 用途：考固件在**电流频繁阶跃**时的库仑计读数与 250ms 周期相位。
    T_START = 3;
    if t < T_START
        i_cmd = -30;                 % 起步：启动电机
    else
        ph = mod(t - T_START, 30);   % 每圈 30s
        if ph < 4
            i_cmd = -30;             % 加速段
        else
            i_cmd = -2;              % 巡航/滑行段
        end
    end
elseif scen == 15
    % ---- 上电静置 + FSAE 起步：专门用来验证"上电快速 OCV 对齐" ----
    % 现实对应：车队把车推到发车区、接上电池、打开 BMS 开关，
    %   此时车还没启动（电流 0），BMS 正好借这段时间把 SOC 对齐到真实值。
    % 时序：
    %   0 ~ 60s    静置 0A（等 OCV 对齐；判据要求 15s 起，留足裕量）
    %   60 ~ 63s   启动电机 30A
    %   63s ~      常态 2A
    if t < 60
        i_cmd = 0;
    elseif t < 63
        i_cmd = -30;
    else
        i_cmd = -2;
    end
else
    i_cmd = 0;
end

end
