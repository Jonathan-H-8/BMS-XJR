% run_offline_suite.m —— 用纯 MATLAB 回路跑一遍固件逻辑回归（不依赖 Simulink）
here = fileparts(mfilename('fullpath')); cd(here); addpath(here);
fprintf('\n================ 固件逻辑回归（offline 模式）================\n');

names = {'S01_静置','S02_放电到空','S04_放电过流','S05_充电过流', ...
         'S07_短路脉冲','S08_低温充电','S09_高温放电','S10_NTC开路','S11_采样线开路', ...
         'S12_均衡与压差'};

R = cell(numel(names),1);
for k = 1:numel(names)
    fprintf('\n---------- %s ----------\n', names{k});
    R{k} = run_bms_offline(names{k});
    m = metrics(R{k});
    show(names{k}, m);
end

fprintf('\n================ 汇总表 ================\n');
fprintf('%-16s %8s %8s %12s %12s %8s  %s\n', ...
        '场景','末SOC%','初始偏差','算法误差%','自放电多掉%','CHG关断','DSG关断');
for k = 1:numel(names)
    m = metrics(R{k});
    fprintf('%-16s %8.2f %+8.2f %+12.4f %12.4f %8s %8s\n', ...
        names{k}, m.soc_end, m.soc_off0, m.soc_track, abs(m.soc_drift), ...
        m.chg_off, m.dsg_off);
end
fprintf('\n【口径说明】\n');
fprintf('  · 「算法误差%%」= 固件 dSOC − 电流真实积分折算的 dSOC。这是固件库仑计的判据。\n');
fprintf('  · 「自放电多掉%%」= 真值 dSOC − 电流折算 dSOC = 自放电（2.5%%/月）。\n');
fprintf('    这股电流不流过采样电阻，BMS 物理上看不到，**不是固件误差**。\n');
fprintf('    ★ 早期版本拿"真值 SOC 变化"当基准，把这一项算进了固件误差\n');
fprintf('      （例如 S02 曾报 0.199%%，实际算法误差只有 %.3f%% 量级）。\n', 0.03);
fprintf('  · 起点取"首次 SOC 对齐成功"那一拍：上电对齐是一次性修正，不是积分误差。\n');

save(fullfile(here,'offline_results.mat'), 'R', 'names');
fprintf('\n结果已存 sim/offline_results.mat\n');

% ---- 出图 ----
FIG = fullfile(here,'figs'); if ~isfolder(FIG), mkdir(FIG); end
for k = 1:numel(names)
    plot_one(R{k}, names{k}, FIG);
end
fprintf('图已存 sim/figs/\n');

%% =====================
function m = metrics(r)
m.soc_end  = r.soc(end);
m.soc_err  = r.soc(end) - mean(r.soc_true(end,:));            % 含上电初值偏差
% ★ 初始偏差要按"第 1 个**有效**记录点"算，不能用 r.soc(1)：
%   未对齐期间 r.soc 是 NaN（固件用哨兵值表示"电量未知"），直接参与运算会
%   让整条链都变成 NaN。所以先找第一个非 NaN 的点。
iv = find(~isnan(r.soc), 1);
if isempty(iv), iv = 1; end
m.soc_off0 = r.soc(iv) - mean(r.soc_true(iv,:));              % 初始偏差
% ★ 跟踪误差的起点必须排除"对齐跳变"：
%   固件上电后会在静置稳定时用 OCV 把 SOC 一次性拉到真实值（约 15s），
%   这一步是**修正**而不是积分误差。若从第 1 拍算起，这个跳变（可达几十 %）
%   会全部被算进"跟踪误差"，得出完全错误的结论。
%   所以从"首次对齐成功"那一拍开始比。
i0 = find(r.aligned > 0, 1);
if isempty(i0), i0 = 1; end

% ★★ 基准必须用「电流的真实积分」，不能用「真值 SOC 变化」：
%   真值 SOC 里含自放电（本模型 2.5%/月），那股电流**不流过采样电阻**，
%   任何 BMS 的库仑计都物理上看不到。拿真值当基准，会把自放电
%   （半小时约 0.17%）整个算成固件的积分误差 —— 那是误判。
%   所以拆成两项：
%     soc_track —— 纯算法误差（固件 dSOC vs 电流折算 dSOC）：真正判据
%     soc_drift —— 物理漂移（真值 dSOC vs 电流折算 dSOC）：自放电，BMS 无解
q_after = trapz(r.t(i0:end), r.i_pack(i0:end))/3600;    % Ah，放电为负
dsoc_cur = q_after / 30.0 * 100;                        % 电流折算的 SOC 变化 %
m.soc_track= (r.soc(end)-r.soc(i0)) - dsoc_cur;         % ★ 真正的积分跟踪误差
m.soc_drift= (mean(r.soc_true(end,:)) - mean(r.soc_true(i0,:))) - dsoc_cur;

% 上电 SOC 对齐情况（固件新增行为：EEPROM 恢复 / 快速 OCV 对齐）
if (i0 > 1) || (r.aligned(1) > 0)
    m.aligned_at = r.t(i0);
    m.boot_err   = r.soc(i0) - mean(r.soc_true(i0,:));
else
    m.aligned_at = NaN;                                 % 全程未对齐
    m.boot_err   = NaN;
end
m.i_end    = r.i_pack(end);
m.vmin     = min(r.v_meas(:));
m.vmax     = max(r.v_meas(:));
m.tmin     = min(r.temp);  m.tmax = max(r.temp);
m.faults   = mat2str(unique(r.fault(r.fault>0))');
m.chg_off  = first_off(r.t, r.chg);
m.dsg_off  = first_off(r.t, r.dsg);
m.bal_frac = mean(r.bal>0)*100;
m.sys_any  = any(r.sys_stat>0);
m.wire_ok  = min(r.dbg(:,10));
m.zone     = unique(r.dbg(:,8))';
m.sens     = unique(r.dbg(:,9))';
m.note     = '';
end

function s = first_off(t, sig)
i = find(sig==0, 1);
if isempty(i), s = '——'; else, s = sprintf('%.2fs', t(i)); end
end

function show(nm, m)
if isnan(m.aligned_at)
    fprintf('  上电 SOC：全程未对齐（未满足"静置 + 电压稳定"条件）\n');
else
    fprintf('  上电 SOC：%.1f s 时对齐，偏差 %+.2f%%\n', m.aligned_at, m.boot_err);
end
fprintf('  SOC %.2f%%（真值 %.2f%%）初始偏差 %+.2f%%\n', ...
        m.soc_end, m.soc_end-m.soc_err, m.soc_off0);
fprintf('  算法误差 %+.4f%%   自放电多掉（非缺陷）%.4f%%\n', ...
        m.soc_track, abs(m.soc_drift));
fprintf('  末电流 %.2f A   单节 %.0f~%.0f mV   温度 %.1f~%.1f℃\n', m.i_end, m.vmin, m.vmax, m.tmin, m.tmax);
fprintf('  CHG 首次关断 %s   DSG 首次关断 %s\n', m.chg_off, m.dsg_off);
fprintf('  故障码 %s   AFE 状态位有置位? %d   采样异常? %d\n', m.faults, m.sys_any, 1-m.wire_ok);
fprintf('  均衡占空比 %.2f%%   温度分区 %s   传感器状态 %s\n', m.bal_frac, mat2str(m.zone), mat2str(m.sens));
end

function plot_one(r, nm, FIG)
f = figure('Visible','off','Position',[80 80 1200 800]);
subplot(4,1,1);
plot(r.t, r.i_cmd,'--', r.t, r.i_pack, 'LineWidth',1); grid on;
legend('要求电流','实际电流'); ylabel('电流 A'); title(nm,'Interpreter','none');
subplot(4,1,2);
plot(r.t, r.v_true, r.t, r.v_meas,'--'); grid on; ylabel('单体 mV');
legend('组1真','组2真','组3真','组4真','组1测','组2测','组3测','组4测','Location','best');
subplot(4,1,3);
plot(r.t, r.soc, r.t, mean(r.soc_true,2),'--'); grid on; ylabel('SOC %');
legend('BMS','真值','Location','best');
subplot(4,1,4);
plot(r.t, r.chg, r.t, r.dsg, r.t, r.bal/16, r.t, r.fault/12); grid on;
xlabel('时间 s'); ylabel('状态');
legend('CHG','DSG','均衡(归一)','故障(归一)','Location','best');
exportgraphics(f, fullfile(FIG, [nm '.png']), 'Resolution', 110);
close(f);
end
