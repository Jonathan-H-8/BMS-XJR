function R = run_bms_offline(scName, opts)
%RUN_BMS_OFFLINE  不开 Simulink，直接用 MATLAB 调用三个模型函数跑固件逻辑回归
%
%   与 Simulink 模型 BMS_C33_2P4S 完全等价的执行顺序（含两处"一拍延迟"）：
%       ① Profile 用上一拍的 v_pack 算电流（对应 Simulink 里的 Mem_vpack）
%       ② Plant   用上一拍的 chg/dsg/bal 算电压电流（对应 Mem_ctl）
%       ③ AFE     用上一拍的 bal/cc_read/clr 算寄存器读数（对应 Mem_afein）
%       ④ BMS     用本拍的寄存器读数算输出，存起来给下一拍用
%
%   用途：
%     · Simulink 模型编译/求解器出问题时的"退路"，保证固件逻辑随时可测
%     · 需要跑很久的工况（纯 MATLAB 循环比 Simulink 快很多）
%
%   用法：
%       R = run_bms_offline('S02_放电到空');      % 按名字跑内置场景
%       R = run_bms_offline('LL3_光伏浅循环7天');  % 长跑场景（见 run_offline_suite）
%       R = run_bms_offline(opt)                  % 传结构体自定义
%
%   opts 字段（不填用默认）：
%       scen(2 放电) / T(1800) / dt(0.1) / t_amb(25) / soc0([60 60 57 60])
%       chg_lim(30) / dsg_lim(50) / inj_cell([0 0 0 0]) / inj_ntc(0)
%       age_en(1)   老化开关：1 = 电池随累计吞吐衰减（长跑用来考容量学习）
%       decim(10)   记录抽稀间隔（10 = 每 1s 存一点）。★长跑必须抽稀，
%                   否则 T=7 天 × dt=0.1s = 605 万点，内存与出图都会崩。
%
%   ★ 关于步长：dt 的物理意义是"固件主循环周期"，模型里要求 10ms。
%     但纯逻辑回归不关心 10ms 的时序细节时，可以把 dt 放宽——本函数默认
%     已按 0.1s 跑长跑；要复现保护动作的毫秒级时序，请显式给 dt = 0.01。

if nargin < 1, scName = 'S02_放电到空'; end

opt = struct('scen',2,'T',1800,'dt',0.1,'t_amb',25,'soc0',[60 60 57 60], ...
             'chg_lim',30,'dsg_lim',50,'inj_cell',[0 0 0 0],'inj_ntc',0, ...
             'age_en',1,'decim',10,'name','自定义','boot_soc',-1, ...
             'cold_boot',0);
if isstruct(scName)
    f = fieldnames(scName);
    for k = 1:numel(f), opt.(f{k}) = scName.(f{k}); end
else
    opt = preset(scName, opt);
end

here = fileparts(mfilename('fullpath'));
cd(here); addpath(here);

N  = round(opt.T/opt.dt);
tv = (0:N-1)' * opt.dt;
D  = max(1, round(opt.decim));          % 抽稀间隔（步）
M  = floor((N-1)/D) + 1;                % 记录点数

% 记录数组（已抽稀）
i_cmd = zeros(M,1); i_pack = zeros(M,1); v_pack = zeros(M,1);
v_true = zeros(M,4); v_meas = zeros(M,4); t_cell = zeros(M,1);
soc_true = zeros(M,4); soc_bms = zeros(M,1); remain = zeros(M,1); cap = zeros(M,1);
chg = zeros(M,1); dsg = zeros(M,1); bal = zeros(M,1); fault = zeros(M,1);
led = zeros(M,1); temp = zeros(M,1); cc = zeros(M,1); sstat = zeros(M,1);
dbg = zeros(M,15); bdrop = zeros(M,1); age = ones(M,2); tr = zeros(M,1);
aligned = zeros(M,1);
soc_state = zeros(M,1);   % SOC 可信度来源：0=UNKNOWN 1=EEPROM恢复 2=OCV对齐

% 上一拍的控制输出（Memory 的初值 = 默认允许）
chg_p = 1; dsg_p = 1; bal_p = 0; ccr_p = 0; clr_p = 0; vp_p = 12800;
m = 0;                                   % 记录指针

fprintf('[offline] %s：%d 步 × %.0f ms = %.0f s（%.2f h）%s\n', ...
        opt.name, N, opt.dt*1000, opt.T, opt.T/3600, ...
        ternary(opt.age_en>0, ' [老化开]', ' [老化关]'));
% ★ 步长告警：见 bms_afe_model.m 里关于"250ms 窗口只取末拍瞬时电流"的说明。
%   dt 越大，窗口内采样点越少，库仑计读数的离散化偏差越大。
%   dt = 10ms（正式仿真）时窗口内 25 点，偏差可忽略；
%   dt 放宽后 SOC 的**绝对值**不再可信，只能看趋势。
if opt.dt > 0.011
    fprintf(['[offline] ⚠ 步长 %.0f ms > 10 ms：库仑计每个 250ms 窗口内只有 %d 个采样点，\n' ...
             '          SOC 的绝对精度不能用于判据，只看长期趋势（漂移方向/故障/容量学习）。\n' ...
             '          要精确测 SOC 精度请用 dt = 0.01。\n'], ...
             opt.dt*1000, max(1, round(250/(opt.dt*1000))));
end
t0 = tic;
for k = 1:N
    t   = tv(k);
    rst = double(t < 2*opt.dt);          % 前两拍给复位脉冲

    % ① 工况/充电机（用上一拍的端电压）
    i_c = bms_profile_model(opt.scen, vp_p, t);

    % ② 电池组（用上一拍的 MOS 与均衡状态）
    [ip, vt, vpt, tc, st, ~, af] = bms_plant_model(i_c, chg_p, dsg_p, bal_p, ...
                                    opt.t_amb, t, rst, opt.soc0, opt.age_en);

    % ③ AFE（用上一拍的均衡/读走/清位）
    %    注：AFE 块的输出打包成了 1×10 向量（原因见 bms_afe_model.m 末尾），
    %        这里按下标解包：1=cc_raw 3=sys_stat 4..7=v_meas 8=v_pack 9=ts1 10=bal_drop
    ya = bms_afe_model(ip, vt, tc, bal_p, ccr_p, clr_p, ...
                       opt.inj_cell, opt.inj_ntc, t, rst);
    ccr = ya(1); ss = ya(3); vm = ya(4:7); vpm = ya(8); ts = ya(9); bd = ya(10);

    % ④ 固件
    %    cmd 第 4 项 = 上电 SOC 初值（模拟 EEPROM 里存的掉电电量）：
    %    ≥0 直接恢复；<0 走"上电快速 OCV 对齐"。见 bms_ctrl_model.m 的说明。
    %    cmd 第 6 项 = 冷启动标志（待测电芯判定），用于标注 SOC 来源。
    yy = bms_ctrl_model(ccr, ss, vm, vpm, ts, ...
                        [opt.chg_lim opt.dsg_lim 0 opt.boot_soc 0 opt.cold_boot], t, rst);
    ce = yy(1); de = yy(2); bm = yy(3); cr = yy(4); cm = yy(5);
    socp = yy(6); rem = yy(7); cp = yy(8); fl = yy(9); lm = yy(10); tmp = yy(11);
    dg = yy(12:26); aln = yy(27); sstate = yy(28);

    % ★ 未对齐时 y(6) 是哨兵值（65535），不是真实百分比 —— 立刻转成 NaN，
    %   这样画图和算误差时它自然表现为"无数据"，不会被当成 65535% 的荒谬值。
    if ~aln, socp = NaN; end

    % 记录（抽稀：只存 1/D 的点，但每拍都算）
    if mod(k-1, D) == 0
        m = m + 1;
        i_cmd(m)=i_c; i_pack(m)=ip; v_pack(m)=vpt; v_true(m,:)=vt; v_meas(m,:)=vm;
        t_cell(m)=tc; soc_true(m,:)=st; soc_bms(m)=socp; remain(m)=rem; cap(m)=cp;
        chg(m)=ce; dsg(m)=de; bal(m)=bm; fault(m)=fl; led(m)=lm; temp(m)=tmp;
        cc(m)=ccr; sstat(m)=ss; dbg(m,:)=dg; bdrop(m)=bd; age(m,:)=af; tr(m)=t;
        aligned(m)=aln; soc_state(m)=sstate;
    end

    % 下一拍的"上一拍"
    chg_p=ce; dsg_p=de; bal_p=bm; ccr_p=cr; clr_p=cm; vp_p=vpt;

    % 长跑进度提示（每 10% 打一次，避免几小时静默）
    if mod(k, max(1,floor(N/10))) == 0
        fprintf('   ... %3.0f%%  t=%8.0f s  SOC=%5.1f%%  已用 %.0f s\n', ...
                k/N*100, t, socp, toc(t0));
    end
end
el = toc(t0);
fprintf('[offline] 完成，耗时 %.1f s（%.0f 步/秒）\n', el, N/el);

% 抽稀后补上真正的 t 向量
R = struct('opt',opt,'t',tr(1:m),'i_cmd',i_cmd(1:m),'i_pack',i_pack(1:m), ...
           'v_pack',v_pack(1:m),'v_true',v_true(1:m,:),'v_meas',v_meas(1:m,:), ...
           't_cell',t_cell(1:m),'soc_true',soc_true(1:m,:),'soc',soc_bms(1:m), ...
           'remain',remain(1:m),'cap',cap(1:m),'chg',chg(1:m),'dsg',dsg(1:m), ...
           'bal',bal(1:m),'fault',fault(1:m),'led',led(1:m),'temp',temp(1:m), ...
           'cc',cc(1:m),'sys_stat',sstat(1:m),'dbg',dbg(1:m,:), ...
           'bal_drop',bdrop(1:m),'age',age(1:m,:),'elapsed',el,'nstep',N, ...
           'aligned',aligned(1:m),'soc_state',soc_state(1:m));
end

function s = ternary(c,a,b)
if c, s = a; else, s = b; end
end

%% ================= 内置场景 =================
% 前缀说明：S** = 短时功能场景（秒~分钟级，验保护动作）
%           LL** = 长跑场景（小时~天级，验长期漂移/累积误差/容量学习）
%
% ★★ 步长口径（重要）★★
%   短场景（S**）**必须用 dt = 0.01**。这些场景的结论（跟踪误差 0.025%、
%   各类关断时间）都建立在"每个 250ms 库仑计窗口内有 25 个采样点"之上，
%   放宽步长会让这些数字失去意义（见 AFE 模型里的说明）。
%   长跑场景（LL**）才按"能跑得动"为原则放宽步长。
function opt = preset(name, opt)
opt.name = name;
switch name
    %% ---------- 短时功能场景（★ dt 必须 0.01，与旧报告口径一致）----------
    case 'S01_静置'
        opt.scen = 1;  opt.T = 300;   opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 10;
    case 'S02_放电到空'
        opt.scen = 2;  opt.T = 1800;  opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 10;
    case 'S03_CCCV充电'
        opt.scen = 3;  opt.T = 3600;  opt.soc0 = [10 10 7 10];
        opt.dt = 0.01; opt.decim = 10;
    case 'S04_放电过流'
        opt.scen = 4;  opt.T = 60;    opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 1;      % 看毫秒级关断，不抽稀
    case 'S05_充电过流'
        opt.scen = 5;  opt.T = 60;    opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 1;
    case 'S06_循环工况'
        opt.scen = 6;  opt.T = 1440;  opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 10;
    case 'S07_短路脉冲'
        opt.scen = 7;  opt.T = 90;    opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 1;      % 短路看 50ms 脉冲，不抽稀
    case 'S08_低温充电'
        opt.scen = 8;  opt.T = 600;   opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 10; opt.t_amb = -10;
    case 'S09_高温放电'
        opt.scen = 9;  opt.T = 900;   opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 10; opt.t_amb = 65;
    case 'S10_NTC开路'
        opt.scen = 1;  opt.T = 120;   opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 10; opt.inj_ntc = 6;
    case 'S11_采样线开路'
        opt.scen = 1;  opt.T = 120;   opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 10; opt.inj_cell = [0 0 3 0];
    case 'S12_均衡与压差'
        opt.scen = 1;  opt.T = 900;   opt.soc0 = [100 55 50 55];  % 最高节 ≥3.40V 才启动均衡
        opt.dt = 0.01; opt.decim = 10;

    %% ---------- 应用工况（大学生方程式耐力赛）----------
    % ★ 关于 boot_soc（上电 SOC 初值）：
    %   固件原来的 Soc_Init() 写死按 50% 起步，要静置 30min 才由 OCV 修正 ——
    %   结果满电待发时仪表显示 50%，车手会误判续航。
    %   现在改成 EEPROM 掉电记忆为主、上电快速 OCV 对齐为辅：
    %     ① boot_soc ≥ 0 → EEPROM 里有掉电记录，直接恢复（最准，不受极化影响）
    %     ② boot_soc < 0 → 无记录，等"静置 + 电压稳定"后由 OCV 对齐
    %     ③ 两条都不成立 → 保持 UNKNOWN，对外不报数字（不再有 50% 占位值）
    %   下面这两个 FSAE 场景模拟"上一轮跑完后正常掉电" → EEPROM 里存着真实电量，
    %   所以上电第一拍就是真值，不再有 -50% 的起始偏差。
    case 'FSAE_耐力赛30分钟'
        % 用户原始工况：启动电机 30A → 常态 2A，共 30 分钟，满电起步
        opt.scen = 13; opt.T = 1800;  opt.soc0 = [100 100 100 100];
        opt.dt = 0.01; opt.decim = 10;      % 18 万步，10ms 保证 250ms 窗口内有 25 点
        opt.boot_soc = 100;                 % ★ EEPROM 记录：上电即 100%
        opt.cold_boot = 0;                  %   热重启（系统一直在电）
    case 'FSAE_耐力赛多圈'
        % 同上，但电流在 30A/2A 之间按 30s 周期脉动，模拟真实的加速-滑行
        opt.scen = 14; opt.T = 1800;  opt.soc0 = [100 100 100 100];
        opt.dt = 0.01; opt.decim = 10;
        opt.boot_soc = 100;                 % ★ 同上
        opt.cold_boot = 0;
    case 'FSAE_上电无记录对照'
        % 对照组：故意不给 boot_soc（EEPROM 无记录），且起步就是 30A 大电流 ——
        % 此时"静置 + 电压稳定"判据永远不满足，固件没有任何信息可用，
        % 于是如实输出 UNKNOWN（而不是给一个会误导人的 50%）。
        % 用途：说明"没有历史记录又不想静置时，SOC 确实无法确定"这一物理边界。
        opt.scen = 13; opt.T = 1800;  opt.soc0 = [100 100 100 100];
        opt.dt = 0.01; opt.decim = 10;
        opt.boot_soc = -1;                  % ★ 无记录
        opt.cold_boot = 1;                  % ★ 待测电芯判定为冷启动
    case 'FSAE_静置对齐验证'
        % 验证"上电快速 OCV 对齐"这条路：先静置 60s（电流 0，电压稳定），
        % 再按 FSAE 工况跑。看固件能否在 ~15~21s 内把 SOC 对齐到真值。
        opt.scen = 15; opt.T = 300;   opt.soc0 = [100 100 100 100];
        opt.dt = 0.01; opt.decim = 10;
        opt.boot_soc = -1;                  % ★ 无记录，靠 OCV 对齐
        opt.cold_boot = 1;                  % ★ 冷启动（换电池/首次上电的典型情形）

    %% ---------- 长跑场景 ----------
    % ★ 步长取舍（实测速度约 2.5 万步/秒）：
    %   实测 4h@dt0.1 只要 5s，速度远超预期，所以长跑也可以放心用 10ms——
    %   只有"30 天"级别的场景才需要放宽（否则单场景上千万步、几分钟起）。
    %   为保证 SOC 精度，除 30 天档外全部使用 dt = 0.01。
    case 'LL1_快循环4小时'      % 720s/周期 × 20 轮 = 4h
        opt.scen = 6;  opt.T = 14400;  opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 1;       % 全保真：144 万步
    case 'LL2_快循环12小时'     % 720s/周期 × 60 轮 = 12h
        opt.scen = 6;  opt.T = 43200;  opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 3;       % 432 万步，记录每 30ms 点
    case 'LL3_慢循环深充放12h'  % 5400s/周期 × 8 轮 = 12h
        opt.scen = 10; opt.T = 43200;  opt.soc0 = [60 60 57 60];
        opt.dt = 0.01; opt.decim = 3;
    case 'LL4_光伏浅循环3天'    % 86400s/周期 × 3 = 72h
        opt.scen = 12; opt.T = 259200; opt.soc0 = [50 50 47 50];
        opt.dt = 0.01; opt.decim = 25;      % 2592 万步（★唯一需要放宽的档位之一）
    case 'LL5_光伏浅循环7天'    % 86400s/周期 × 7 = 168h
        opt.scen = 12; opt.T = 604800; opt.soc0 = [50 50 47 50];
        opt.dt = 0.05; opt.decim = 6;       % 1210 万步，窗口内 5 点
    case 'LL6_浅循环30天'       % 86400s/周期 × 30 = 720h（约 1 个月）
        opt.scen = 12; opt.T = 2592000; opt.soc0 = [50 50 47 50];
        opt.dt = 0.1;  opt.decim = 25;      % 2592 万步，窗口内 2 点
    case 'LL7_深度循环30天'     % 5400s/周期 × 480 轮 = 720h（加速老化）
        opt.scen = 10; opt.T = 2592000; opt.soc0 = [60 60 57 60];
        opt.dt = 0.1;  opt.decim = 25;
    otherwise
        error('run_bms_offline:未知场景 %s', name);
end
end
