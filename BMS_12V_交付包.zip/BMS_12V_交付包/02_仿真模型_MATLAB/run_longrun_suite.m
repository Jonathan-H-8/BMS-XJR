% run_longrun_suite.m —— 长时间仿真：把工况拉到小时/天级，看固件的长期行为
%
%   为什么要跑长：短场景（几十秒~半小时）只能验"保护动作对不对"，
%   验不了这三件事：
%     ① 库仑计积分的**累积漂移**——单步误差再小，跑 30 天也会放大
%     ② 容量学习是否真的收敛——它需要"充满 + 放空"两个事件才标定
%     ③ 均衡的长期效果与是否会反复启停
%
%   本套件分两组：
%     A 组：与旧报告一致的 4 个基准场景（确认长跑改造没破坏原结论）
%     B 组：4 个长跑场景（4h / 12h / 3天 / 7天 / 30天）
%
%   用法：
%       run_longrun_suite          % 跑全部（约几分钟到十几分钟）
%       run_longrun_suite('B')     % 只跑长跑组
%       run_longrun_suite('A')     % 只跑基准组

here = fileparts(mfilename('fullpath')); cd(here); addpath(here);
which = 'all';
if exist('argv','var') && ~isempty(argv), which = argv; end   %#ok<NODEF>

if strcmp(which,'A'), NAMES = {'S01_静置','S02_放电到空','S04_放电过流','S12_均衡与压差'};
elseif strcmp(which,'B'), NAMES = {'LL1_快循环4小时','LL2_快循环12小时', ...
                                   'LL3_慢循环深充放12h','LL4_光伏浅循环3天', ...
                                   'LL5_光伏浅循环7天','LL6_浅循环30天','LL7_深度循环30天'};
else, NAMES = {'S01_静置','S02_放电到空','S04_放电过流','S12_均衡与压差', ...
               'LL1_快循环4小时','LL2_快循环12小时','LL3_慢循环深充放12h', ...
               'LL4_光伏浅循环3天','LL5_光伏浅循环7天','LL6_浅循环30天','LL7_深度循环30天'};
end

fprintf('\n============ 长时间仿真套件（共 %d 个场景）============\n', numel(NAMES));
T_all = tic;
R = cell(numel(NAMES),1);
for k = 1:numel(NAMES)
    fprintf('\n---------- [%d/%d] %s ----------\n', k, numel(NAMES), NAMES{k});
    R{k} = run_bms_offline(NAMES{k});
    show(NAMES{k}, R{k});
end
fprintf('\n套件总耗时 %.0f s（%.1f min）\n', toc(T_all), toc(T_all)/60);

%% ================= 长期指标汇总 =================
fprintf('\n================ 长期行为汇总 ================\n');
fprintf('%-18s %7s %6s %8s %9s %9s %9s %6s\n', ...
        '场景','时长h','步长ms','末SOC%','总漂移%/h','物理漂移','离散伪影','均衡%');
tab = {};
for k = 1:numel(NAMES)
    s = lrmetrics(R{k});
    tab{end+1} = s; %#ok<SAGROW>
    fprintf('%-18s %7.1f %6.0f %8.2f %+9.4f %+9.4f %+9.4f %6.2f\n', ...
            NAMES{k}, s.hours, s.dt*1000, s.soc_end, s.drift_per_h, ...
            s.drift_act, s.drift_dis, s.bal_frac);
end

fprintf('\n================ 容量学习与保护 ================\n');
fprintf('%-18s %10s %10s %8s %8s %9s %s\n', ...
        '场景','标定Ah','真实Ah','误差%','内阻×','最坏压差','故障码');
for k = 1:numel(NAMES)
    s = tab{k};
    fprintf('%-18s %10.3f %10.3f %+8.2f %8.3f %9.0f %s\n', ...
            NAMES{k}, s.cap_end, s.cap_true, s.cap_err, s.res_grow, s.maxdelta, s.faults);
end

fprintf('\n【读表要点】\n');
fprintf('  · "物理漂移" = 电池自放电（2.5%%/月）造成的真实 SOC 下滑，任何 BMS 都躲不掉，\n');
fprintf('     固件只能靠 OCV 周期校正把它拉回来 —— 这一列**不是**固件缺陷。\n');
fprintf('  · "离散伪影" = 库仑计建模方式（窗口末拍瞬时值）带来的偏差。\n');
fprintf('     ★ 实测：即使步长 10ms（窗口内 25 点）也有 +0.35~0.42%%/h；\n');
fprintf('       电流阶跃越陡越大（LL3 深充放达 +1.52%%/h，是 LL1 的 3.6 倍）。\n');
fprintf('       它指向固件一个真实隐患：若 250ms 调用周期与 AFE 转换周期相位漂移，\n');
fprintf('       会重复读/漏读窗口 —— 见报告第五节③。\n');
fprintf('  · "误差%%" = 固件标定容量相对电池真实容量的偏差。\n');
fprintf('     ★★ 实测最重要的发现：固件标定值全程恒定 30.000 Ah，一次没更新过。\n');
fprintf('        因为容量学习要求"同时见过满充和放空"，而深循环工况两点都够不到。\n');
fprintf('        30 天深层循环后真实容量已跌到 27.96 Ah，误差达 +7.3%%（SOC 会系统性偏高）。\n');

save(fullfile(here,'longrun_results.mat'), 'R', 'NAMES', 'tab');
fprintf('\n结果已存 sim/longrun_results.mat\n');

%% ================= 出图 =================
FIG = fullfile(here,'figs_long'); if ~isfolder(FIG), mkdir(FIG); end
for k = 1:numel(NAMES)
    plot_long(R{k}, NAMES{k}, FIG);
end
fprintf('图已存 sim/figs_long/\n');

%% ===================== 指标 =====================
function s = lrmetrics(r)
% 长期指标：单位换算到「每小时」才看得出累积效应
s.hours     = r.opt.T/3600;
s.soc_end   = r.soc(end);
s.soc_true  = mean(r.soc_true(end,:));
s.track_err = (r.soc(end)-r.soc(1)) - (mean(r.soc_true(end,:)) - mean(r.soc_true(1,:)));
s.drift_per_h = s.track_err / max(s.hours, eps);

% ★ 把两种误差分开 —— 长跑结论必须区分这两者，否则会误判：
%   ① drift_act : 真实存在的物理漂移（自放电等），任何 BMS 都免不了，
%                  只能靠 OCV 周期校正把它压回去
%   ② drift_dis : 本仿真的离散化伪影（步长放宽后库仑计窗口采样不足），
%                  dt=0.01 时接近 0，不属于固件缺陷
%   判据："固件有没有系统性积分误差" 要看 ② 有多小，而不是看 ① 有多大。
sd_per_s = 2.5 / (30*24*3600);                 % 与 plant 一致的 %/s
s.drift_act = -sd_per_s * 100 * 3600;          % %/h（负=真值在掉）
s.drift_dis = s.drift_per_h - s.drift_act;     % %/h（剩下的归为离散化/算法）

% 容量学习结果：固件标定值 vs 电池真实容量
s.cap_end   = r.cap(end);
s.cap_true  = 30.0 * r.age(end,1);
s.cap_keep  = r.age(end,1);
s.res_grow  = r.age(end,2);
s.cap_err   = (s.cap_end - s.cap_true) / s.cap_true * 100;
% 均衡
s.bal_frac  = mean(r.bal>0)*100;
% 保护
s.faults    = mat2str(unique(r.fault(r.fault>0))');
s.minv      = min(r.v_meas(:)); s.maxv = max(r.v_meas(:));
s.minT      = min(r.temp);      s.maxT = max(r.temp);
s.chg_off   = first_off(r.t, r.chg);
s.dsg_off   = first_off(r.t, r.dsg);
% 最坏压差
s.maxdelta  = max(r.dbg(:,4));
% 累计吞吐
s.ah_thru   = trapz(r.t, abs(r.i_pack))/3600;
% 步长（判据可信度）
s.dt        = r.opt.dt;
end

function s = first_off(t, sig)
i = find(sig==0, 1);
if isempty(i), s = '——'; else, s = sprintf('%.2fs', t(i)); end
end

function show(nm, r)
s = lrmetrics(r);
fprintf('  时长 %.2f h（%.0f 天）    末 SOC %.2f%%（真值 %.2f%%）\n', ...
        s.hours, s.hours/24, s.soc_end, s.soc_true);
fprintf('  总漂移 %+.4f%%/h  =  物理（自放电）%+.4f%%/h  +  离散伪影 %+.4f%%/h\n', ...
        s.drift_per_h, s.drift_act, s.drift_dis);
fprintf('  容量：固件标定 %.3f Ah / 真实 %.3f Ah（误差 %+.2f%%，内阻 ×%.3f）\n', ...
        s.cap_end, s.cap_true, s.cap_err, s.res_grow);
fprintf('  单体 %.0f~%.0f mV   最大压差 %.0f mV   温度 %.1f~%.1f℃\n', ...
        s.minv, s.maxv, s.maxdelta, s.minT, s.maxT);
fprintf('  均衡占空比 %.2f%%   累计吞吐 %.1f Ah   故障码 %s\n', ...
        s.bal_frac, s.ah_thru, s.faults);
fprintf('  CHG 首次关断 %s   DSG 首次关断 %s\n', s.chg_off, s.dsg_off);
end

%% ===================== 出图 =====================
function plot_long(r, nm, FIG)
f = figure('Visible','off','Position',[60 60 1400 950]);

% 时间轴按小时显示（长跑用秒没法看）
th = r.t/3600;

subplot(5,1,1);
plot(th, r.i_cmd,'--', th, r.i_pack, 'LineWidth',0.8); grid on; box on;
legend('要求电流','实际电流','Location','best'); ylabel('电流 A');
title(sprintf('%s   （时长 %.1f h）', nm, r.opt.T/3600), 'Interpreter','none');

subplot(5,1,2);
plot(th, r.soc, 'LineWidth',1.2); hold on;
plot(th, mean(r.soc_true,2),'--','LineWidth',1.0);
grid on; box on; ylabel('SOC %'); ylim([-5 105]);
legend('BMS','真值','Location','best');

subplot(5,1,3);
% SOC 误差随时间（长期漂移最容易看出来的一张图）
plot(th, r.soc - mean(r.soc_true,2), 'LineWidth',1.2); grid on; box on;
yline(0,'k:'); ylabel('SOC 误差 %'); legend('BMS − 真值','Location','best');

subplot(5,1,4);
plot(th, r.v_meas, 'LineWidth',0.7); hold on;
plot(th, r.v_true,'--','LineWidth',0.5);
grid on; box on; ylabel('单体 mV');
legend('测1','测2','测3','测4','真1','真2','真3','真4','Location','best','NumColumns',2);

subplot(5,1,5);
yyaxis left
plot(th, r.cap, 'LineWidth',1.2); hold on;
plot(th, 30.0*r.age(:,1), '--','LineWidth',1.2);
ylabel('容量 Ah');
yyaxis right
plot(th, r.bal/16, 'LineWidth',0.6); hold on;
plot(th, r.fault/12, 'LineWidth',0.6);
ylabel('状态'); ylim([-0.1 1.2]);
grid on; box on; xlabel('时间 h');
legend('固件标定容量','电池真实容量','均衡(归一)','故障(归一)','Location','best');

exportgraphics(f, fullfile(FIG, [nm '.png']), 'Resolution', 120);
close(f);
end
