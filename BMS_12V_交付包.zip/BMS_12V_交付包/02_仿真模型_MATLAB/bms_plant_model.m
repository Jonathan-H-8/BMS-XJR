function [i_pack, v_true, v_pack_true, t_cell, soc_true, p_loss, age_fac] = ...
    bms_plant_model(i_cmd, chg_en, dsg_en, bal_mask, t_amb, t, rst, soc0, age_en)
%%#codegen
%BMS_PLANT_MODEL  亿纬 C33 2P4S 电池组等效电路模型（作为 Simulink MATLAB Function 块）
%
%   4 组串联，每组 = 2 只 C33 并联的等效电芯：
%       容量  30 Ah（15Ah × 2P）
%       内阻  4 mΩ（8mΩ ÷ 2P），拆成 R0 = 3mΩ（欧姆）+ R1 = 1mΩ（极化，τ=30s）
%       OCV   与固件 bms_soc.c 的 s_ocv 表完全一致（否则 SOC 对不上就没法测固件）
%       热    每组 0.534 kg，Cp 900 J/(kg·K)，hA 0.9 W/K，环境 25℃
%
%   ★ 建模口径：BMS 只能测到并联组的电压，测不到两只并联单体之间的差异，
%     所以把 2P 组等效成一只电芯——端子特性等价，且正好是 BMS 能观测的量。
%     要看并联单体间的环流/温差，需要建完整 8 电芯模型（见 README 的说明）。
%
%   输入：
%     i_cmd    负载/电源要求的电流 A（+ 充电 / − 放电，来自工况曲线）
%     chg_en   充电管允许（由 BMS 控制）        dsg_en 放电管允许
%     bal_mask 均衡掩码（AFE 槽位 bit0..bit4），决定哪一组在泄放
%     t_amb    环境温度 ℃（用来做低温/高温工况）
%     t        时间 s
%     rst      复位脉冲（每个仿真开头给 1，把 SOC/温度状态清回初值）
%     soc0     1×4 复位后的初始 SOC %（只在 rst 有效时用）
%     age_en   老化开关（0 = 不老化，1 = 按等效循环次数衰减）。用来做长跑测试：
%              长跑时若电池本身在衰减，才看得出"库仑计+容量学习"是否跟得上。
%
%   输出：
%     i_pack       实际电流 A（受 MOS 门控）
%     v_true       1×4 每组真实电压 mV
%     v_pack_true  组端真实电压 mV
%     t_cell       温度 ℃（取四组平均，代表 NTC 感受到的温度）
%     soc_true     1×4 每组真实 SOC %
%     p_loss       总发热功率 W
%     age_fac      [容量保持率, 内阻增长倍数]（1.0 = 全新）
%
%   ★ 老化模型（age_en = 1 时启用）：
%     容量保持率 = 1 − k_cyc × (等效循环数)      ，k_cyc = 4e-4 / 循环
%     内阻倍数   = 1 + 0.8 × (等效循环数) × k_cyc
%     等效循环数 = 累计吞吐 Ah / (2 × 30Ah)
%     依据：C33 官方 ≥2500 次 @25℃/DOD75%，对应约 20% 容量衰减，
%           即 k_cyc ≈ 0.2/2500/2 ≈ 4e-5/循环；这里取 10 倍（4e-4）
%           **刻意放大**，让"长跑几小时"也能看出趋势——
%           真实电池跑 4 小时是看不出衰减的，本项只为验证算法跟得上。
%     只看趋势，不要拿它当寿命预测结果。

%% ---------- 参数（与 c33_2p4s_params.m 保持一致）----------
P_S        = 4;              % 4S
CAP_GROUP  = 30.0;           % Ah（2P）
R0_GROUP   = 3e-3;           % Ω 欧姆内阻（等效 2P 组）
R1_GROUP   = 1e-3;           % Ω 极化内阻
TAU1       = 30;             % s
C1_GROUP   = TAU1 / R1_GROUP;
MASS_G     = 0.534;          % kg 每组（2 × 267g）
CP         = 900;            % J/(kg·K)
HA         = 0.9;            % W/K 每组散热
R_BLEED    = 2000;           % Ω 均衡泄放回路（1kΩ 采样电阻 ×2），≈1.6mA@3.2V

% ---- 老化系数（age_en = 1 时启用，见函数头说明）----
K_CYC      = 4e-4;           % 每等效循环的容量衰减（★刻意放大 10 倍，见说明）
AH_PER_CYC = 2 * CAP_GROUP;  % 1 个等效循环的吞吐量 = 2×容量

% ---- 自放电（★长跑必须建模，否则看不出"静置段"的 SOC 漂移）----
%   依据：LFP 圆柱电芯自放电典型 2~3 %/月 → 取 2.5%/月 折算成连续速率。
%   ★ 关键：这股电流**不流过采样电阻**，BMS 完全看不到它。
%     长跑时它会持续把真实 SOC 往下拉，而固件的库仑计无感 ——
%     这就是"库仑计必须靠 OCV 周期校正"的根本原因，也是长期漂移的主因。
%     短场景（几十分钟）里这项只贡献 0.05% 量级，可以忽略；
%     跑 30 天就是 2.5%，是长跑结论里必须计入的一项。
SD_PER_MONTH = 2.5;          % %/月
SD_PER_S     = SD_PER_MONTH / (30*24*3600);   % %/s

% OCV 表（与固件同源）
OCV_SOC = [  0    3    7   12   20   30   40   50   60   70   80   90   97  100];
OCV_MV  = [3000 3180 3240 3262 3275 3285 3292 3300 3308 3315 3325 3340 3360 3400];

SLOTBIT = [1 2 4 16];

%% ---------- 持久状态 ----------
% ★ MATLAB Function 块的 persistent 状态在同一个 MATLAB 会话里跨多次 sim
%   是不会自动清零的，所以必须用 rst 输入显式复位。
persistent soc vrc temp tprev ah_thru
if isempty(soc)
    % 默认初始 SOC：做得不一致一点（组3偏低 3%），用来触发均衡/压差逻辑
    soc   = [60.0 60.0 57.0 60.0];
    vrc   = zeros(1,4);
    temp  = 25 * ones(1,4);
    tprev = -1;
    ah_thru = 0;            % 累计吞吐安时（老化用）
end
if tprev < 0 || rst > 0
    % 逐元素赋值（不用 soc = soc0）：把整个输入数组赋给 persistent，
    % 会让 Simulink 在推断 persistent 尺寸时与输入端口尺寸互相牵扯
    for g = 1:4
        soc(g)  = soc0(g);
        vrc(g)  = 0;
        temp(g) = t_amb;    % 复位时温度 = 环境温度（否则高温/低温场景冷启动是错的）
    end
    tprev = t;
    ah_thru = 0;
end
if tprev < 0
    DT = 0.01;
else
    DT = t - tprev;
    if DT <= 0 || DT > 100
        DT = 0.01;
    end
end
tprev = t;

%% ---------- 1) MOS 门控：充放电管决定电流能不能流过 ----------
if i_cmd >= 0
    i_pack = i_cmd * double(chg_en);
else
    i_pack = i_cmd * double(dsg_en);
end

%% ---------- 1b) 老化：按累计吞吐算容量保持率与内阻倍数 ----------
% ★ 注意与"容量学习"的配合：电池真实容量在缩，固件若不能靠满充/放空
%   重新标定 S_cap，SOC 就会越跑越偏——这正是长跑测试要看的东西。
if age_en > 0
    ah_thru = ah_thru + abs(i_pack) * DT / 3600;
end
cyc      = ah_thru / AH_PER_CYC;                % 等效循环数
cap_keep = 1 - K_CYC * cyc;                     % 容量保持率
if cap_keep < 0.7, cap_keep = 0.7; end          % 下限 70%（EOL 之后不再衰减）
res_grow = 1 + 0.8 * K_CYC * cyc;               % 内阻增长倍数
age_fac  = [cap_keep, res_grow];

CAP_USE  = CAP_GROUP * cap_keep;                % 当前实际可用容量
R0_USE   = R0_GROUP * res_grow;
R1_USE   = R1_GROUP * res_grow;

%% ---------- 2) 各组 SOC 积分（库仑 + 均衡泄放 + 自放电）----------
for g = 1:P_S
    % 主回路电流（充电为正 → SOC 上升）
    soc(g) = soc(g) + (i_pack / 3600 / CAP_USE) * 100 * DT;
    % 均衡泄放：只让被选中那一组的 SOC 下降
    if bitand(uint8(bal_mask), uint8(SLOTBIT(g))) ~= 0
        i_bleed = 3.2 / R_BLEED;                       % A，约 1.6mA
        soc(g) = soc(g) - (i_bleed / 3600 / CAP_USE) * 100 * DT;
    end
    % 自放电：不经过采样电阻，BMS 看不到（见上面 SD_PER_S 的说明）
    soc(g) = soc(g) - SD_PER_S * 100 * DT;
    soc(g) = max(-5, min(105, soc(g)));                 % 允许略微过充/过放，便于测试保护
end

%% ---------- 3) 端电压：OCV + 欧姆压降 + 极化（RC）----------
v_true = zeros(1,4);
for g = 1:P_S
    % OCV 查表（SOC→mV，线性插值）
    s = max(OCV_SOC(1), min(OCV_SOC(end), soc(g)));
    ocv = OCV_MV(end);
    for i = 2:numel(OCV_SOC)
        if s <= OCV_SOC(i)
            sh = OCV_SOC(i-1); sl = OCV_SOC(i);
            vh = OCV_MV(i-1);  vl = OCV_MV(i);
            ocv = vl + (vh - vl) * (s - sl) / (sh - sl);
            break;
        end
    end
    % 极化电压
    dvrc = (i_pack / C1_GROUP) - vrc(g) / (R1_USE * C1_GROUP);
    vrc(g) = vrc(g) + dvrc * DT;
    % 端电压（充电 i>0 → 抬升；放电 i<0 → 跌落）
    vg = ocv + i_pack * R0_USE * 1000 + vrc(g) * 1000;
    v_true(g) = max(1, vg);
end
v_pack_true = sum(v_true);

%% ---------- 4) 热模型：每组 i²R 发热、对流散热 ----------
p_loss = 0;
for g = 1:P_S
    p_g = i_pack^2 * (R0_USE + R1_USE);
    p_loss = p_loss + p_g;
    dT = (p_g - HA * (temp(g) - t_amb)) / (MASS_G * CP);
    temp(g) = temp(g) + dT * DT;
end
t_cell = sum(temp) / P_S;

soc_true = soc;

end
