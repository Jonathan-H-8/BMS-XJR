function y = bms_afe_model(i_pack, v_true, t_cell, bal_mask, cc_read, clr_mask, inj_cell, inj_ntc, t, rst)
%%#codegen
%BMS_AFE_MODEL  BQ76920 寄存器级行为仿真（作为 Simulink MATLAB Function 块使用）
%
%   把「芯片」和"固件"分开：本块模拟 BQ76920 真正会让固件看到的东西，
%   固件逻辑在 bms_ctrl_model 里，两边只通过「寄存器读数」交互，
%   这样测到的才是固件本身，而不是被理想化模型糊过去的逻辑。
%
%   模拟的芯片行为：
%     1) 电芯电压：每 250ms 转换一次（= ADC 更新周期），按 380µV/LSB 量化；
%     2) 均衡干扰：被均衡那一节的读数会被压低（均衡电流流过 R22~R25 的 1kΩ），
%        压降大小由本块内 balDrop 给出——这正是需要用 CELLDIAG 实测的那个量；
%     3) 库仑计：每 250ms 把该窗口电流积分成整数，1 LSB = 8.44mA（@1mΩ），
%        读走即复位（固件用 CC_READY 判断能否读）；
%     4) 硬件保护：过压 1s / 欠压 4s / 放电过流 320ms@50A / 短路 @111A，
%        置位后锁存，只有固件写 SYS_STAT 清位才复位（与真芯片一致）；
%     5) TS1 温度通道：NTC 分压 → 382µV/LSB 量化，可注入开路/短路；
%     6) 可注入单体采样线开路/接反。
%
%   输入：
%     i_pack   电池组电流 A（+ 充电 / − 放电）
%     v_true   4 组真实电压 mV（1×4）
%     t_cell   电芯温度 ℃（送给 NTC）
%     bal_mask 固件下发的均衡掩码（AFE 槽位 bit0..bit4）
%     cc_read  固件读走库仑计（脉冲 ==1）
%     clr_mask 固件写 SYS_STAT 的清除掩码（对应位 =1 表示清除）
%     inj_cell 1×4 单体故障注入：0 正常 / 3 采样线开路 / 4 采样线接反
%     inj_ntc  NTC 故障注入：0 正常 / 5 短路到地 / 6 开路
%     t        仿真时间 s（用于算步长，块不假设固定步长）
%     rst      复位脉冲（每个仿真开头给 1，清库仑计与保护锁存）
%
%   输出：
%     y        1×10 打包向量（★ 为什么打包见文件末尾"输出打包"一节）
%              y(1)      cc_raw       库仑计整数读数（读走后归零）
%              y(2)      cc_ready     CC_READY 位（每 250ms 置一次）
%              y(3)      sys_stat     SYS_STAT 状态字节（已转 double）
%              y(4..7)   v_meas       4 组「芯片测到的」电压 mV
%              y(8)      v_pack_meas  组端电压（BAT 寄存器）mV
%              y(9)      ts1_adc      TS1 通道 ADC 码
%              y(10)     bal_drop     本次因均衡被压低的量 mV（诊断用）
%
%   单独调用（不开 Simulink）时这样解包：
%       y = bms_afe_model(...);
%       cc_raw = y(1); cc_ready = y(2); sys_stat = y(3);
%       v_meas = y(4:7); v_pack_meas = y(8); ts1_adc = y(9); bal_drop = y(10);

%% ---------- 芯片常量（与数据手册 / bms_config.h 一致）----------
OV_MV       = 3650;     % OV_TRIP
UV_MV       = 2500;     % UV_TRIP
OV_DELAY_S  = 1.0;      % PROTECT3[5:4] = 0 → 1s
UV_DELAY_S  = 4.0;      % PROTECT3[7:6] = 1 → 4s
OCD_A       = 50;       % PROTECT2 = 0x06 → 50mV @1mΩ
OCD_DELAY_S = 0.32;     % PROTECT2[6:4] = 0x05
SCD_A       = 111;      % PROTECT1[2:0] = 0x3 → 111mV @1mΩ
LSB_UV      = 380;      % ADC 增益 µV/LSB（从 OTP 读到的典型值）
CC_LSB_A    = 8.44e-3;  % 库仑计 1 LSB 对应电流 A（8.44µV ÷ 1mΩ）
TS_LSB_UV   = 382;      % TS1 通道 1 LSB
NTC_R0 = 10000; NTC_B = 3435; PULLUP = 10000; VREF = 3.3;

% ★ 均衡对读数的压低量（mV）：本板需用 CELLDIAG 实测，这里给最坏估计值
balDrop = 1500;

% 电芯组号 → CELLBAL1 的 bit（本板 4S：组1..4 → 槽1,2,3,5 → bit0,1,2,4）
SLOTBIT = [1 2 4 16];

%% ---------- 持久状态 ----------
persistent tick t_prev cc_acc cc_reg cc_rdy acc_ms ov_ms uv_ms ocd_ms ...
           ov_bit uv_bit ocd_bit scd_bit v_hold adc_ms
% ★ ADC_MS 必须先定义：下面初始化里 adc_ms = ADC_MS 会用到它
ADC_MS = 250;         % 电芯电压/库仑计的转换周期（= bms_config.h 的 BMS_TASK_CELL_MS）

if isempty(tick)
    tick = 0; t_prev = -1; cc_acc = 0; cc_reg = 0; cc_rdy = 0;
    acc_ms = 0; ov_ms = 0; uv_ms = 0; ocd_ms = 0;
    ov_bit = 0; uv_bit = 0; ocd_bit = 0; scd_bit = 0;
    % ★ v_hold 初值是全 0，而 adc_ms 预置成 ADC_MS 表示"这一拍就该转换"，
    %   于是第一拍立刻填上真值（单点延迟，而不是零保持 250ms）。
    %   零保持那 250ms 会让固件的合理性判据 v<1200mV 把 4 节全判成
    %   "采样线开路"，误报 CELL_WIRE 故障。真芯片上电后第一次转换
    %   也是很快就好（~1ms 量级），不会输出 0。
    v_hold = zeros(1,4); adc_ms = ADC_MS;
end
if rst > 0
    tick = 0; t_prev = -1; cc_acc = 0; cc_reg = 0; cc_rdy = 0;
    acc_ms = 0; ov_ms = 0; uv_ms = 0; ocd_ms = 0;
    ov_bit = 0; uv_bit = 0; ocd_bit = 0; scd_bit = 0;
    v_hold = zeros(1,4); adc_ms = ADC_MS;
end

% 用时间差算步长，不假设固定步长
if t_prev < 0
    DT = 0.01;
else
    DT = t - t_prev;
    if DT <= 0
        DT = 0.01;
    end
end
t_prev = t;
tick = tick + 1;

%% ---------- 1) 故障注入 + 均衡压降（芯片实际看到的电压）----------
v_adc = v_true;
bal_drop = 0;
for g = 1:4
    if inj_cell(g) == 3
        v_adc(g) = 300;                 % 采样线开路：读数接近 0
    elseif inj_cell(g) == 4
        v_adc(g) = v_true(g) * 2;       % 采样线接错：读数虚高
    end
end
for g = 1:4
    if bitand(uint8(bal_mask), uint8(SLOTBIT(g))) ~= 0
        v_adc(g) = max(0, v_adc(g) - balDrop);
        bal_drop = bal_drop + balDrop;
    end
end

%% ---------- 2) 每 250ms 转换一次并量化（ADC 更新周期）----------
% ★ 用整数毫秒累加，别直接 DT*1000。
%   原因：DT 是 t - t_prev 算出来的浮点数（如 0.009999999999999998），
%   乘 1000 后是 9.999999999999998，累加 25 次只有 249.99999999999994 < 250，
%   于是窗口变成 26 拍。实测 60s 里 25 拍占 177 次、26 拍占 59 次 —— 窗口长度
%   不均匀，而 cc_reg = cc_acc/(LSB*0.25) 是按"整 250ms"折算的。
%   真芯片的 250ms 来自硬件定时器，严格均匀，所以这里必须 round() 成整数毫秒
%   才能与硬件一致。（这是模型精度问题，不是固件缺陷。）
adc_ms = adc_ms + round(DT * 1000);
if adc_ms >= ADC_MS
    adc_ms = adc_ms - ADC_MS;
    for g = 1:4
        adc = round(v_adc(g) * 1000 / LSB_UV);
        v = adc * LSB_UV / 1000;
        if v < 0
            v = 0;
        end
        v_hold(g) = v;
    end
    % 注意：不要用 v_hold = max(0, v_hold) 这种「标量 + 向量」的隐式扩展写法，
    % 代码生成器会推不出输出尺寸（正是 Simulink 报「无法确定模块输出大小」的原因）
end
v_meas = v_hold;
v_pack_meas = sum(v_hold);

%% ---------- 3) 库仑计：每 250ms 积分一次，读走复位 ----------
% ★ 这里必须积分「这一拍的真实电流 i_pack」，不能用 v_adc（那是被均衡/故障
%   注入污染过的电压）。早期版本写成 `cc_acc = cc_acc + i_pack * DT` 是对的；
%   但如果为了"省事"改成用上一拍采样值，粗步长下会引入巨大误差。
%
% ★ 还有一个真实存在的离散化效应（不是 bug，是物理限制）：
%   本模型里 cc_reg 存的是「窗口末那一拍的瞬时电流折算的 LSB 数」，
%   而真实 BQ76920 是在 250ms 窗口内连续积分再量化。
%   所以当步长 dt > 0 时，只要窗口内电流有变化（含 MOS 刚关断那一拍），
%   读数就会偏离窗口平均值。结论：
%     · 正式仿真请用 dt = 0.01 s（10ms），此时窗口内 25 个采样点，
%       偏差 < 0.5%，与真芯片一致；
%     · 长跑允许放宽到 dt ≤ 0.1 s，此时 2~3 个采样点，偏差可达 30% 量级，
%       **SOC 的绝对精度不作为判据**，只看长期趋势（漂移方向、故障、容量学习）。
%       run_bms_offline 会在 dt > 0.01 时自动告警，避免误读结果。
cc_acc = cc_acc + i_pack * DT;                       % A·s
acc_ms = acc_ms + round(DT * 1000);                  % ★ 整数毫秒（理由见上面 adc_ms 注释）
cc_rdy = 0;
if acc_ms >= ADC_MS
    cc_reg = round(cc_acc / (CC_LSB_A * 0.25));      % 该 250ms 窗口内的 LSB 数
    cc_reg = max(-32768, min(32767, cc_reg));
    cc_acc = 0;
    acc_ms = 0;
    cc_rdy = 1;                                      % CC_READY
end
if cc_read > 0
    cc_reg = 0;                                      % 读走即复位
end
cc_raw = cc_reg;
cc_ready = cc_rdy;

%% ---------- 4) 硬件保护（独立于固件，锁存到固件清位）----------
vmax = max(v_adc); vmin = min(v_adc);
if vmax >= OV_MV, ov_ms = ov_ms + DT*1000; else, ov_ms = 0; end
if ov_ms >= OV_DELAY_S*1000, ov_bit = 1; end
if vmin <= UV_MV, uv_ms = uv_ms + DT*1000; else, uv_ms = 0; end
if uv_ms >= UV_DELAY_S*1000, uv_bit = 1; end
if -i_pack >= OCD_A, ocd_ms = ocd_ms + DT*1000; else, ocd_ms = 0; end
if ocd_ms >= OCD_DELAY_S*1000, ocd_bit = 1; end
if -i_pack >= SCD_A, scd_bit = 1; end

if bitand(uint8(clr_mask), uint8(4))  ~= 0, ov_bit  = 0; end   % OV  = 0x04
if bitand(uint8(clr_mask), uint8(8))  ~= 0, uv_bit  = 0; end   % UV  = 0x08
if bitand(uint8(clr_mask), uint8(1))  ~= 0, ocd_bit = 0; end   % OCD = 0x01
if bitand(uint8(clr_mask), uint8(2))  ~= 0, scd_bit = 0; end   % SCD = 0x02

sys_stat = uint8(cc_rdy)*uint8(128) + uint8(ov_bit)*uint8(4) + uint8(uv_bit)*uint8(8) + ...
           uint8(ocd_bit)*uint8(1) + uint8(scd_bit)*uint8(2);

%% ---------- 5) TS1 温度通道 ----------
r_ntc = NTC_R0 * exp(NTC_B * (1/(t_cell + 273.15) - 1/298.15));
v_ts1 = VREF * r_ntc / (PULLUP + r_ntc);
if inj_ntc == 5
    v_ts1 = 0;          % NTC 短路到地 → 会假象「极高温」
elseif inj_ntc == 6
    v_ts1 = VREF;       % NTC 开路 → 会假象「极低温」
end
ts1_adc = round(v_ts1 / (TS_LSB_UV*1e-6));

%% ---------- 6) 输出打包：★ 关键，别改回多输出 ----------
% 为什么把 7 个输出打包成一个 1×10 向量：
%   Simulink 的 MATLAB Function 块（Stateflow 内核）在给本块这种规模做
%   「输出大小/类型推断」时会失败，报：
%       「Simulink 无法确定模块 'BMS_C33_2P4S/AFE_BQ76920' 的输出大小和/或类型」
%   即使 fillMFcn 已经把每个端口的尺寸/类型都显式指定了，仍然报。
%   原因是输出端口多、且类型混着 uint8 与 double，推断器会卡住。
%
%   BMS_Firmware 块当初报的是同一个错，改成单一向量输出后立刻通过 ——
%   本块照做，外部用 Demux 拆开即可（接线见 build_bms_model.m）。
%
%   代价：可读性差一点，以及 sys_stat 的 uint8 要转成 double 再打包
%   （下游固件块内部会再按位运算处理，不依赖 uint8 类型）。
y = zeros(1, 10);
y(1) = cc_raw;
y(2) = double(cc_ready);
y(3) = double(sys_stat);
for g = 1:4
    y(3+g) = v_meas(g);        % y(4)..y(7)
end
y(8)  = v_pack_meas;
y(9)  = ts1_adc;
y(10) = bal_drop;

end
