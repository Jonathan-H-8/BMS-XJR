function go_verify_boot
% 验证「上电电量」改动：不写 50% 占位、EEPROM 恢复、OCV 对齐、未对齐时输出哨兵值
% 用纯 ASCII 文件名 + 纯 ASCII 命令（避免 matlab -batch 的中文/下划线问题）
cd('C:\Users\admin\WorkBuddy\2026-09-14-22-07-51\sim');
addpath(pwd);

fprintf('\n===== A. 短场景冒烟（S01 静置默认无 EEPROM 记录 → 应 UNKNOWN）=====\n');
R = run_bms_offline('S01_静置');
fprintf('S01: aligned(1)=%d  state(1)=%d  soc(1)=%s (expect NaN, no 50%% placeholder)\n', ...
    R.aligned(1), R.soc_state(1), mat2str(R.soc(1)));
fprintf('     true soc(1)=%.1f%% —— 没被写死成 50%%\n', mean(R.soc_true(1,:)));

fprintf('\n===== B. FSAE 30min（EEPROM 恢复）=====\n');
R1 = run_bms_offline('FSAE_耐力赛30分钟');
fprintf('F1: aligned(1)=%d state(1)=%d soc(1)=%.3f true(1)=%.3f\n', ...
    R1.aligned(1), R1.soc_state(1), R1.soc(1), mean(R1.soc_true(1,:)));

fprintf('\n===== C. FSAE 无记录对照（应 UNKNOWN：aligned=0, soc=NaN）=====\n');
R4 = run_bms_offline('FSAE_上电无记录对照');
fprintf('F4: aligned(1)=%d state(1)=%d soc(1)=%s NaN? %d\n', ...
    R4.aligned(1), R4.soc_state(1), mat2str(R4.soc(1)), isnan(R4.soc(1)));
fprintf('    any aligned over run = %d (should be 0)\n', any(R4.aligned>0));

fprintf('\n===== D. 静置对齐（应 OCV 对齐到 100%）=====\n');
R3 = run_bms_offline('FSAE_静置对齐验证');
i0 = find(R3.aligned>0, 1);
if isempty(i0)
    fprintf('F3: *** 从未对齐 ***\n');
else
    fprintf('F3: aligned at t=%.1f s  soc=%.3f  true=%.3f  err=%+.3f%%\n', ...
        R3.t(i0), R3.soc(i0), mean(R3.soc_true(i0,:)), ...
        R3.soc(i0)-mean(R3.soc_true(i0,:)));
    fprintf('    state=%d (2=OCV_ALIGNED)\n', R3.soc_state(i0));
end

fprintf('\n===== E. 检查是否还有 50%% 占位残留 =====\n');
fprintf('F4 全程 soc 是否全 NaN: %d\n', all(isnan(R4.soc)));
fprintf('F4 led 是否全程 0（未点亮固定档位）: %d\n', all(R4.led==0));

fprintf('\n===== 断言汇总 =====\n');
n_fail = 0;
ck = @(n,cond) ck_one(n,cond);
ck('A 无记录时不上报假数字',  isnan(R.soc(1)) && R.aligned(1)==0);
ck('A 未对齐状态码 = UNKNOWN', R.soc_state(1)==0);
ck('B EEPROM 恢复上电即 100%', R1.aligned(1)==1 && abs(R1.soc(1)-100)<0.01);
ck('B 来源标记 = RESTORED',    R1.soc_state(1)==1);
ck('B 无 50% 残留',            abs(R1.soc(1)-50) > 1);
ck('C 无记录对照全程 UNKNOWN', R4.aligned(1)==0 && all(isnan(R4.soc)) && ~any(R4.aligned>0));
ck('D OCV 对齐在 21 s 内成立', ~isempty(i0) && R3.t(i0) <= 21);
ck('D 对齐后来源 = OCV_ALIGNED', R3.soc_state(i0)==2);
ck('D 对齐精度优于 0.5%',      abs(R3.soc(i0)-mean(R3.soc_true(i0,:))) < 0.5);
ck('E 未对齐时 LED 不点亮固定档位', all(R4.led==0));

fprintf('\n===== 完成 =====\n');
end

% ---------- 单条断言打印（顶层辅助函数，MATLAB 要求函数在文件末尾）----------
function ck_one(name, cond)
if cond
    fprintf('  [PASS] %s\n', name);
else
    fprintf('  [FAIL] %s\n', name);
end
end
